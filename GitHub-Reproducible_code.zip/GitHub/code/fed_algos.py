"""
Federated algorithms for distributed measurement-aware pretraining.

Implements: FedAvg, FedProx, SCAFFOLD, FedBN (per-site BN buffers),
Local-only, Centralised, Ours = FedECG-Meas
  (entropy + SQI weighting; layer-wise calibration damping;
   aggregate-update Gaussian uncertainty injection).
"""
from __future__ import annotations
import copy
import math
import time
from typing import Dict, List

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# enable faster GPU kernels
torch.backends.cudnn.benchmark = True
try:
    torch.set_float32_matmul_precision("high")
except Exception:
    pass


# ---------------------------------------------------------------------------
# ECG augmentation for SSL
# ---------------------------------------------------------------------------
def _aug(x, p_time=0.15, p_lead=0.20, noise_sigma=0.05, drift_amp=0.04):
    """x: (B,12,T). Returns one augmented view."""
    B, C, T = x.shape
    x = x.clone()
    # temporal mask
    L = int(p_time * T)
    if L >= 4:
        starts = torch.randint(0, T - L, (B,), device=x.device)
        for b in range(B):
            x[b, :, starts[b]:starts[b] + L] = 0
    # lead drop
    drop = (torch.rand(B, C, device=x.device) < p_lead).unsqueeze(-1).float()
    x = x * (1 - drop)
    # noise
    x = x + noise_sigma * torch.randn_like(x)
    # baseline drift
    t = torch.linspace(0, 1, T, device=x.device)
    f = torch.empty(B, device=x.device).uniform_(0.5, 3.0)
    ph = torch.empty(B, device=x.device).uniform_(0, 6.28)
    drift = drift_amp * torch.sin(2 * 3.14159 * f[:, None] * t[None, :] + ph[:, None])
    x = x + drift.unsqueeze(1)
    return x


# ---------------------------------------------------------------------------
# Dataset wrappers
# ---------------------------------------------------------------------------
class NodeDataset(Dataset):
    def __init__(self, X, y, sqi_q=None):
        self.X = X
        self.y = y
        self.sqi_q = sqi_q
    def __len__(self):
        return len(self.X)
    def __getitem__(self, i):
        x = torch.from_numpy(self.X[i].astype(np.float32))
        x = (x - x.mean(-1, keepdim=True)) / (x.std(-1, keepdim=True) + 1e-6)
        return x, int(self.y[i]), float(self.sqi_q[i] if self.sqi_q is not None else 1.0)


# ---------------------------------------------------------------------------
# NT-Xent loss
# ---------------------------------------------------------------------------
def nt_xent(z1, z2, tau=0.2):
    B = z1.shape[0]
    z = torch.cat([z1, z2], 0)
    sim = z @ z.t() / tau
    mask = torch.eye(2 * B, dtype=torch.bool, device=z.device)
    sim.masked_fill_(mask, -1e4)
    targets = (torch.arange(2 * B, device=z.device) + B) % (2 * B)
    return F.cross_entropy(sim, targets)


# ---------------------------------------------------------------------------
# Local SSL update with optional prox / SCAFFOLD control variates
# ---------------------------------------------------------------------------
def local_ssl(enc, head, loader, epochs, lr, device,
              prox_mu=0.0, global_state=None,
              scaffold_c=None, scaffold_ci=None, use_amp=True):
    opt = torch.optim.AdamW(list(enc.parameters()) + list(head.parameters()),
                            lr=lr, weight_decay=1e-4)
    enc.train(); head.train()
    losses = []
    scaler = torch.amp.GradScaler('cuda') if (use_amp and device == "cuda") else None
    if prox_mu > 0 and global_state is not None:
        gs_dev = {n: g.to(device, non_blocking=True)
                  for n, g in global_state.items()}
    else:
        gs_dev = None
    # GPU fast path: loader is actually a tensor (B,12,T) already on device
    if torch.is_tensor(loader):
        return _local_ssl_gpu(enc, head, loader, opt, scaler, epochs,
                              prox_mu, gs_dev,
                              scaffold_c, scaffold_ci, device, use_amp)
    for _ in range(epochs):
        for x, _, _ in loader:
            x = x.to(device, non_blocking=True)
            v1 = _aug(x); v2 = _aug(x)
            opt.zero_grad(set_to_none=True)
            ctx = torch.amp.autocast('cuda') if (use_amp and device == "cuda") else \
                  torch.amp.autocast('cpu', enabled=False)
            with ctx:
                z1 = head(enc(v1)); z2 = head(enc(v2))
                loss = nt_xent(z1, z2)
                if prox_mu > 0 and gs_dev is not None:
                    p = 0.0
                    for n, q in enc.named_parameters():
                        p = p + ((q - gs_dev[n]) ** 2).sum()
                    loss = loss + 0.5 * prox_mu * p
            if scaler is not None:
                scaler.scale(loss).backward()
                if scaffold_c is not None and scaffold_ci is not None:
                    scaler.unscale_(opt)
                    for n, q in enc.named_parameters():
                        if q.grad is None or n not in scaffold_c:
                            continue
                        q.grad += (scaffold_c[n] - scaffold_ci[n]).to(device)
                scaler.step(opt); scaler.update()
            else:
                loss.backward()
                if scaffold_c is not None and scaffold_ci is not None:
                    for n, q in enc.named_parameters():
                        if q.grad is None or n not in scaffold_c:
                            continue
                        q.grad += (scaffold_c[n] - scaffold_ci[n]).to(device)
                opt.step()
            losses.append(loss.item())
    return float(np.mean(losses)), {k: v.detach().cpu()
                                     for k, v in enc.state_dict().items()}


def _local_ssl_gpu(enc, head, X_gpu, opt, scaler, epochs,
                    prox_mu, gs_dev, scaffold_c, scaffold_ci,
                    device, use_amp):
    """X_gpu: (N, 12, T) already on device. Random-batch sampling with
    bs inferred from `X_gpu._batch` attr (default 1024). bs is clamped
    to min(bs, N) so smaller nodes still see at least one full batch."""
    bs_req = getattr(X_gpu, "_batch", 1024)
    N = X_gpu.shape[0]
    bs = min(bs_req, N)
    if bs < 8:
        # too few samples to learn meaningfully; skip
        return 0.0, {k: v.detach().cpu() for k, v in enc.state_dict().items()}
    losses = []
    for _ in range(epochs):
        idx = torch.randperm(N, device=device)
        n_batches = max(1, N // bs)
        for b in range(n_batches):
            sel = idx[b * bs:(b + 1) * bs]
            x = X_gpu[sel]
            x = (x - x.mean(-1, keepdim=True)) / (x.std(-1, keepdim=True) + 1e-6)
            v1 = _aug(x); v2 = _aug(x)
            opt.zero_grad(set_to_none=True)
            ctx = torch.amp.autocast('cuda') if (use_amp and device == "cuda") else \
                  torch.amp.autocast('cpu', enabled=False)
            with ctx:
                z1 = head(enc(v1)); z2 = head(enc(v2))
                loss = nt_xent(z1, z2)
                if prox_mu > 0 and gs_dev is not None:
                    p = 0.0
                    for n, q in enc.named_parameters():
                        p = p + ((q - gs_dev[n]) ** 2).sum()
                    loss = loss + 0.5 * prox_mu * p
            if scaler is not None:
                scaler.scale(loss).backward()
                if scaffold_c is not None and scaffold_ci is not None:
                    scaler.unscale_(opt)
                    for n, q in enc.named_parameters():
                        if q.grad is None or n not in scaffold_c:
                            continue
                        q.grad += (scaffold_c[n] - scaffold_ci[n]).to(device)
                scaler.step(opt); scaler.update()
            else:
                loss.backward()
                if scaffold_c is not None and scaffold_ci is not None:
                    for n, q in enc.named_parameters():
                        if q.grad is None or n not in scaffold_c:
                            continue
                        q.grad += (scaffold_c[n] - scaffold_ci[n]).to(device)
                opt.step()
            losses.append(loss.item())
    return float(np.mean(losses)), {k: v.detach().cpu()
                                     for k, v in enc.state_dict().items()}


# ---------------------------------------------------------------------------
# Aggregation primitives
# ---------------------------------------------------------------------------
def weighted_mean(states, weights, ref_state):
    """All work happens on CPU; states and ref_state are first detached
    to CPU. The returned state lives on CPU and is moved to the model's
    device later by `load_state_dict`."""
    w = np.asarray(weights, dtype=np.float64); w = w / w.sum()
    ref_cpu = {k: v.detach().cpu() for k, v in ref_state.items()}
    states_cpu = [{k: v.detach().cpu() for k, v in s.items()} for s in states]
    out = {}
    for k in ref_cpu:
        acc = torch.zeros_like(ref_cpu[k], dtype=torch.float32)
        for ws, st in zip(w, states_cpu):
            acc += float(ws) * st[k].float()
        out[k] = acc.to(ref_cpu[k].dtype)
    return out


def effective_weights(client_priors, client_sizes, client_sqi_mean,
                       beta_H=0.5, beta_Q=0.5):
    """Quality-aware effective sample size:
       n_eff = n * (1 + beta_H * H(p)/log K) * (1 + beta_Q * q_mean)."""
    out = []
    for p, n, q in zip(client_priors, client_sizes, client_sqi_mean):
        H = -float((np.asarray(p) * np.log(np.asarray(p) + 1e-12)).sum()) / np.log(len(p))
        ne = n * (1.0 + beta_H * H) * (1.0 + beta_Q * float(q))
        out.append(ne)
    return out


def damp_early(global_state, agg_state, early_keys, gamma=0.6):
    g_cpu = {k: v.detach().cpu() for k, v in global_state.items()}
    a_cpu = {k: v.detach().cpu() for k, v in agg_state.items()}
    out = {}
    for k, v in a_cpu.items():
        if any(ek in k for ek in early_keys) and v.dtype.is_floating_point:
            out[k] = (gamma * v.float() + (1 - gamma) * g_cpu[k].float()).to(v.dtype)
        else:
            out[k] = v
    return out


def add_dp_noise(agg_state, sigma, clip=1.0):
    out = {}
    for k, v in agg_state.items():
        if v.dtype.is_floating_point and sigma > 0:
            out[k] = v + torch.randn_like(v) * sigma * clip
        else:
            out[k] = v
    return out


def clip_state(state, ref_state, clip=1.0):
    """Norm-clip the delta against ref_state. Move both to CPU first
    because client states come back from local trainers on CPU while
    ref_state may live on CUDA."""
    state_cpu = {k: v.detach().cpu() for k, v in state.items()}
    ref_cpu   = {k: v.detach().cpu() for k, v in ref_state.items()}
    flat_d = torch.cat([(state_cpu[k] - ref_cpu[k]).float().flatten()
                        for k in state_cpu])
    norm = float(flat_d.norm())
    if norm < 1e-12:
        return state_cpu
    factor = min(1.0, clip / norm)
    return {k: (ref_cpu[k].float() +
                (state_cpu[k].float() - ref_cpu[k].float()) * factor
                ).to(state_cpu[k].dtype)
            for k in state_cpu}


# ---------------------------------------------------------------------------
# Federated trainer
# ---------------------------------------------------------------------------
class FederatedTrainer:
    def __init__(self, enc_factory, head_factory, node_loaders, node_priors,
                 node_sizes, node_sqi_mean, algo="ours",
                 rounds=8, local_epochs=1, lr=1e-3, device="cuda",
                 prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6,
                 clip=1.0, fedbn_layers=None, log=print):
        self.enc_factory = enc_factory; self.head_factory = head_factory
        self.loaders = node_loaders; self.priors = node_priors
        self.sizes = node_sizes; self.sqi_mean = node_sqi_mean
        self.algo = algo; self.rounds = rounds
        self.local_epochs = local_epochs; self.lr = lr; self.device = device
        self.prox_mu = prox_mu if algo in ("fedprox", "ours") else 0.0
        self.dp_sigma = dp_sigma if algo == "ours" else 0.0
        self.gamma = damping_gamma if algo == "ours" else 1.0
        self.clip = clip
        self.fedbn = (algo == "fedbn")
        self.fedbn_layers = fedbn_layers or []
        self.log = log
        self.global_enc = self.enc_factory().to(device)
        self.head = self.head_factory().to(device)
        # for SCAFFOLD (control variates always live on CPU)
        self._c = None; self._ci = None
        if algo == "scaffold":
            self._c = {k: torch.zeros_like(v).cpu()
                       for k, v in self.global_enc.state_dict().items()
                       if v.dtype.is_floating_point}
            self._ci = {nk: {k: torch.zeros_like(v).cpu()
                              for k, v in self.global_enc.state_dict().items()
                              if v.dtype.is_floating_point}
                         for nk in self.loaders.keys()}
        # for FedBN keep per-site BN buffers
        self._bn_state = {nk: None for nk in self.loaders.keys()}
        self.history = {"round": [], "avg_loss": [], "client_loss": []}

    def _is_bn_key(self, k):
        return any(bn in k for bn in self.fedbn_layers)

    def train(self):
        for r in range(1, self.rounds + 1):
            gs = {k: v.detach().clone()
                  for k, v in self.global_enc.state_dict().items()}
            client_states, client_losses = [], []
            for nk, loader in self.loaders.items():
                enc = self.enc_factory().to(self.device)
                # FedBN: load global but overwrite BN with site-local
                local_gs = {k: v.clone() for k, v in gs.items()}
                if self.fedbn and self._bn_state[nk] is not None:
                    for k in local_gs:
                        if self._is_bn_key(k):
                            local_gs[k] = self._bn_state[nk][k]
                enc.load_state_dict(local_gs)
                hd = self.head_factory().to(self.device)
                hd.load_state_dict(self.head.state_dict())
                # For SCAFFOLD inside local SSL, move control variates to device
                sc_c = ({k: v.to(self.device) for k, v in self._c.items()}
                        if self.algo == "scaffold" else None)
                sc_ci = ({k: v.to(self.device) for k, v in self._ci[nk].items()}
                         if self.algo == "scaffold" else None)
                loss, st = local_ssl(enc, hd, loader, self.local_epochs,
                                     self.lr, self.device,
                                     prox_mu=self.prox_mu, global_state=gs,
                                     scaffold_c=sc_c, scaffold_ci=sc_ci)
                if self.clip > 0:
                    st = clip_state(st, gs, self.clip)
                client_states.append(st); client_losses.append(loss)
                if self.fedbn:
                    self._bn_state[nk] = {k: st[k].clone()
                                          for k in st if self._is_bn_key(k)}

            # SCAFFOLD update of control variates BEFORE aggregation
            if self.algo == "scaffold":
                gs_cpu = {k: v.detach().cpu() for k, v in gs.items()}
                new_c = {k: torch.zeros_like(v) for k, v in self._c.items()}
                for j, (nk, st) in enumerate(zip(self.loaders.keys(),
                                                  client_states)):
                    st_cpu = {k: v.detach().cpu() for k, v in st.items()}
                    for k in self._ci[nk]:
                        if k not in gs_cpu:
                            continue
                        delta = (gs_cpu[k].float() - st_cpu[k].float()) / max(self.lr, 1e-6)
                        ci_new = self._ci[nk][k] - self._c[k] + delta
                        self._ci[nk][k] = ci_new
                        new_c[k] += ci_new / len(client_states)
                self._c = new_c

            # weights
            if self.algo == "ours":
                w = effective_weights(self.priors, self.sizes, self.sqi_mean)
            else:
                w = self.sizes
            agg = weighted_mean(client_states, w, gs)

            if self.algo == "ours":
                early = ["stem", "blocks.0", "blocks.1"]
                agg = damp_early(gs, agg, early, gamma=self.gamma)
                if self.dp_sigma > 0:
                    agg = add_dp_noise(agg, sigma=self.dp_sigma, clip=self.clip)

            # FedBN: keep site BN locally, only sync non-BN
            if self.fedbn:
                gs_cpu = {k: v.detach().cpu() for k, v in gs.items()}
                merged = dict(gs_cpu)
                for k, v in agg.items():
                    if not self._is_bn_key(k):
                        merged[k] = v.detach().cpu() if torch.is_tensor(v) else v
                agg = merged
            # ensure CPU before load
            agg = {k: v.detach().cpu() if torch.is_tensor(v) else v for k, v in agg.items()}
            self.global_enc.load_state_dict(agg)
            self.history["round"].append(r)
            self.history["avg_loss"].append(float(np.mean(client_losses)))
            self.history["client_loss"].append(client_losses)
            self.log(f"[{self.algo}] r{r:02d}/{self.rounds}  "
                     f"avg={np.mean(client_losses):.3f}  "
                     f"each={[f'{l:.2f}' for l in client_losses]}")
        return self.history, self.global_enc, self._bn_state if self.fedbn else None
