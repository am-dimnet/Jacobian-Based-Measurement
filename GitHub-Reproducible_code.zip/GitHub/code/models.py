"""
Lightweight ECG encoder + heads, with optional FedBN-compatible BatchNorm
that keeps per-site running statistics (Li et al. ICLR-2021).
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(self, c, r=8):
        super().__init__()
        h = max(c // r, 4)
        self.fc1 = nn.Linear(c, h); self.fc2 = nn.Linear(h, c)
    def forward(self, x):
        s = x.mean(-1)
        s = torch.sigmoid(self.fc2(F.silu(self.fc1(s)))).unsqueeze(-1)
        return x * s


class ConvBlock(nn.Module):
    def __init__(self, c_in, c_out, k=15, stride=2):
        super().__init__()
        self.dw = nn.Conv1d(c_in, c_in, k, stride, k // 2, groups=c_in)
        self.pw = nn.Conv1d(c_in, c_out, 1)
        self.bn = nn.BatchNorm1d(c_out)
        self.se = SEBlock(c_out)
        self.proj = (nn.Conv1d(c_in, c_out, 1, stride)
                     if (c_in != c_out or stride != 1) else nn.Identity())
    def forward(self, x):
        y = F.silu(self.bn(self.pw(self.dw(x))))
        y = self.se(y)
        return y + self.proj(x)[:, :, :y.shape[-1]]


class ECGEncoder(nn.Module):
    """0.33 M-param convolution-transformer hybrid that maps
    (B, 12, 1000) -> (B, 128). Lead-mask applied at input."""
    def __init__(self, d=128, n_tf=2, nhead=4, in_ch=12):
        super().__init__()
        self.in_ch = in_ch
        self.stem = nn.Sequential(
            nn.Conv1d(in_ch, 32, 25, 2, 12), nn.BatchNorm1d(32), nn.SiLU())
        self.blocks = nn.Sequential(
            ConvBlock(32, 48, 15, 2),
            ConvBlock(48, 64, 11, 2),
            ConvBlock(64, 96, 9, 2),
            ConvBlock(96, d, 7, 2),
        )
        layer = nn.TransformerEncoderLayer(
            d_model=d, nhead=nhead, dim_feedforward=256,
            batch_first=True, dropout=0.1, activation="gelu")
        self.tf = nn.TransformerEncoder(layer, n_tf)
        self.norm = nn.LayerNorm(d)
        self.d = d

    def forward(self, x, lead_mask=None):
        # x: (B, 12, T); lead_mask: (B, 12) or None
        if lead_mask is not None:
            x = x * lead_mask.unsqueeze(-1)
        h = self.stem(x)
        h = self.blocks(h)
        h = h.transpose(1, 2)
        h = self.tf(h)
        h = self.norm(h)
        return h.mean(1)


class ProjHead(nn.Module):
    def __init__(self, d_in=128, d_out=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d_in, d_in), nn.SiLU(),
                                 nn.Linear(d_in, d_out))
    def forward(self, z):
        return F.normalize(self.net(z), dim=-1)


class ClsHead(nn.Module):
    def __init__(self, d=128, K=5):
        super().__init__()
        self.fc = nn.Linear(d, K)
    def forward(self, z):
        return self.fc(z)
