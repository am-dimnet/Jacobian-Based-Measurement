"""Instrumentation/Measurement metrics for cross-node ECG evaluation."""
from __future__ import annotations
import numpy as np
from sklearn.metrics import (f1_score, roc_auc_score, accuracy_score,
                              cohen_kappa_score, confusion_matrix)


def cls_metrics(y_true, y_pred, proba=None, K=5):
    acc = float(accuracy_score(y_true, y_pred))
    f1 = float(f1_score(y_true, y_pred, average="macro", zero_division=0))
    auc = float("nan")
    if proba is not None:
        try:
            oh = np.zeros((len(y_true), K))
            oh[np.arange(len(y_true)), y_true] = 1
            auc = float(roc_auc_score(oh, proba, average="macro",
                                       multi_class="ovr"))
        except Exception:
            pass
    kappa = float(cohen_kappa_score(y_true, y_pred))
    return {"acc": acc, "f1": f1, "auc": auc, "kappa": kappa}


def icc_3_1(measurements):
    """Two-way mixed effects, absolute agreement, single measurement.
    measurements: (n_subjects, n_raters)."""
    M = np.asarray(measurements, dtype=np.float64)
    n, k = M.shape
    mean_per_subj = M.mean(1)
    mean_per_rater = M.mean(0)
    grand = M.mean()
    SSR = k * ((mean_per_subj - grand) ** 2).sum()
    SSC = n * ((mean_per_rater - grand) ** 2).sum()
    SST = ((M - grand) ** 2).sum()
    SSE = SST - SSR - SSC
    MSR = SSR / (n - 1); MSE = SSE / ((n - 1) * (k - 1))
    MSC = SSC / (k - 1)
    denom = MSR + (k - 1) * MSE + k * (MSC - MSE) / n
    if denom <= 0:
        return float("nan")
    return float((MSR - MSE) / denom)


def bland_altman(a, b):
    """Returns (bias, sd_diff, 95% LoA lower/upper)."""
    a = np.asarray(a, dtype=np.float64); b = np.asarray(b, dtype=np.float64)
    d = a - b
    bias = float(d.mean()); sd = float(d.std(ddof=1))
    return {"bias": bias, "sd": sd,
            "loa_lo": bias - 1.96 * sd, "loa_hi": bias + 1.96 * sd}


def coefficient_of_variation(values):
    v = np.asarray(values, dtype=np.float64)
    return float(v.std(ddof=1) / max(abs(v.mean()), 1e-6))


def paired_t(a, b):
    from scipy import stats
    t, p = stats.ttest_rel(a, b)
    return {"t": float(t), "p": float(p)}


def cliffs_delta(a, b):
    a = np.asarray(a); b = np.asarray(b)
    n1, n2 = len(a), len(b)
    if n1 == 0 or n2 == 0: return 0.0
    A = np.tile(a[:, None], (1, n2))
    B = np.tile(b[None, :], (n1, 1))
    return float((np.sign(A - B)).mean())


def wilcoxon(a, b):
    from scipy import stats
    s, p = stats.wilcoxon(a, b, zero_method="wilcox")
    return {"stat": float(s), "p": float(p)}


def mean_ci(values, alpha=0.05):
    from scipy import stats
    v = np.asarray(values, dtype=np.float64)
    m = float(v.mean()); s = float(v.std(ddof=1)) if len(v) > 1 else 0.0
    if len(v) <= 1:
        return {"mean": m, "sd": 0.0, "ci_lo": m, "ci_hi": m}
    t = stats.t.ppf(1 - alpha / 2, len(v) - 1)
    h = t * s / np.sqrt(len(v))
    return {"mean": m, "sd": s, "ci_lo": m - h, "ci_hi": m + h}
