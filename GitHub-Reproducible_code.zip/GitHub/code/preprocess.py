"""Preprocess PTB-XL + Chapman-Shaoxing into the .npz format consumed by
data_real.py. Runs on the server after raw data is unzipped.

Outputs:
  data/legacy_cache/Dataset1/ptbxl_proc.npz
  data/legacy_cache/Dataset1/ptbxl_sqi.npz
  data/legacy_cache/Dataset1/ptbxl_labels.json
  data/legacy_cache/Dataset1/chapman_proc.npz
  data/legacy_cache/Dataset1/chapman_sqi.npz
  data/legacy_cache/Dataset1/chapman_labels.json
  data/legacy_cache/meta/scp_statements.csv (copy)
"""
from __future__ import annotations
import os, json, ast, shutil, time
import numpy as np
import pandas as pd
import wfdb
from scipy.signal import resample_poly

PTBXL_ROOT = "/root/autodl-tmp/ptbxl_raw"
CHAPMAN_ROOT = "/root/autodl-tmp/chapman_raw"
OUT_DIR = "data/legacy_cache/Dataset1"
META_DIR = "data/legacy_cache/meta"

T = 1000  # 10 s at 100 Hz
N_LEADS = 12
SUPER = ["NORM", "MI", "STTC", "CD", "HYP"]
SUPER_IDX = {k: i for i, k in enumerate(SUPER)}

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(META_DIR, exist_ok=True)


def _zscore(x):
    m = x.mean(axis=-1, keepdims=True)
    s = x.std(axis=-1, keepdims=True) + 1e-6
    return (x - m) / s


def _sqi_features(x):
    """Return 6 SQI features per record: spectral peak, kurtosis,
    line-noise leakage, baseline drift, R-peak detectability, range."""
    feats = []
    x2 = x.astype(np.float64)
    # 1. variance ratio (in-band 1-40 Hz vs total)
    F = np.fft.rfft(x2, axis=-1)
    P = (np.abs(F) ** 2).mean(0)
    fs = 100.0
    fr = np.fft.rfftfreq(x2.shape[-1], 1.0 / fs)
    in_band = P[(fr >= 1) & (fr <= 40)].sum()
    total = P.sum() + 1e-12
    feats.append(min(1.0, in_band / total))
    # 2. line-noise (50 Hz) leakage — small near 100 Hz Nyquist (we use 45-49)
    line = P[(fr >= 45) & (fr <= 49.9)].sum() / total
    feats.append(max(0.0, 1.0 - 20 * line))
    # 3. baseline drift power below 0.5 Hz
    drift = P[fr < 0.5].sum() / total
    feats.append(max(0.0, 1.0 - 5 * drift))
    # 4. kurtosis avg across leads, mapped to [0,1]
    k = ((x2 - x2.mean(-1, keepdims=True)) ** 4).mean(-1)
    sigma4 = (x2.std(-1) ** 4) + 1e-9
    kurt = (k / sigma4).mean()  # ~3 for Gaussian
    feats.append(float(np.clip(kurt / 8.0, 0.0, 1.0)))
    # 5. amplitude range plausibility (median per-lead pk-pk)
    pk = (x2.max(-1) - x2.min(-1))
    rng = np.median(pk)
    feats.append(float(np.clip(np.exp(-((rng - 1.5) ** 2) / 2.0), 0.0, 1.0)))
    # 6. lead-II detectability proxy: relative power above mean
    if x2.shape[0] >= 2:
        lead2 = x2[1]
        d = lead2 - lead2.mean()
        feats.append(float(np.clip((np.abs(d) > 0.1).mean() * 2.0, 0.0, 1.0)))
    else:
        feats.append(0.5)
    return np.array(feats, dtype=np.float32)


# ---------------------------------------------------------------------------
def process_ptbxl():
    csv = pd.read_csv(os.path.join(PTBXL_ROOT, "ptbxl_database.csv"))
    scp = pd.read_csv(os.path.join(PTBXL_ROOT, "scp_statements.csv"), index_col=0)
    shutil.copy(os.path.join(PTBXL_ROOT, "scp_statements.csv"),
                os.path.join(META_DIR, "scp_statements.csv"))

    # Map SCP code -> superclass
    code2super = {}
    for code, row in scp.iterrows():
        s = str(row.get("diagnostic_class", ""))
        if s in SUPER:
            code2super[code] = s

    X_list, y_list, pid, fold, site, dev, ecg_id = [], [], [], [], [], [], []
    sqi_list, prim_scp = [], []
    N = len(csv)
    t0 = time.time()
    for i, row in csv.iterrows():
        codes = ast.literal_eval(row["scp_codes"])
        sup_scores = {}
        for c, lik in codes.items():
            s = code2super.get(c)
            if s is not None:
                sup_scores[s] = sup_scores.get(s, 0) + (lik or 100.0)
        if not sup_scores:
            continue
        y = SUPER_IDX[max(sup_scores, key=sup_scores.get)]
        # load 100-Hz signal
        rec_path = os.path.join(PTBXL_ROOT, row["filename_lr"])
        try:
            sig, meta = wfdb.rdsamp(rec_path)
        except Exception:
            continue
        x = sig.T.astype(np.float32)            # (12, T)
        if x.shape[1] != T:
            if x.shape[1] > T:
                x = x[:, :T]
            else:
                pad = np.zeros((x.shape[0], T - x.shape[1]), dtype=np.float32)
                x = np.concatenate([x, pad], axis=-1)
        if x.shape[0] != N_LEADS:
            # pad/truncate leads
            if x.shape[0] > N_LEADS:
                x = x[:N_LEADS]
            else:
                pad = np.zeros((N_LEADS - x.shape[0], T), dtype=np.float32)
                x = np.concatenate([x, pad], axis=0)
        sqi = _sqi_features(x)
        Xz = _zscore(x).astype(np.float16)
        def _safe_int(v, d=0):
            try:
                if v is None or (isinstance(v, float) and np.isnan(v)):
                    return d
                return int(v)
            except Exception:
                return d
        X_list.append(Xz); y_list.append(y)
        pid.append(_safe_int(row.get("patient_id"), -1))
        fold.append(_safe_int(row.get("strat_fold"), 0))
        site.append(_safe_int(row.get("site"), 0))
        dev_v = row.get("device")
        dev.append(str(dev_v) if dev_v is not None and not (isinstance(dev_v, float) and np.isnan(dev_v)) else "unknown")
        ecg_id.append(_safe_int(row.get("ecg_id"), 0))
        sqi_list.append(sqi)
        prim_scp.append(max(sup_scores, key=sup_scores.get))
        if (i + 1) % 2000 == 0:
            print(f"PTB-XL {i+1}/{N}  elapsed {time.time()-t0:.0f}s")

    X = np.stack(X_list).astype(np.float16)
    y = np.array(y_list, dtype=np.int8)
    sqi_feats = np.stack(sqi_list).astype(np.float32)
    sqi_q = sqi_feats.mean(axis=1).astype(np.float32)
    N = len(X)
    np.savez_compressed(os.path.join(OUT_DIR, "ptbxl_proc.npz"),
                        X=X, y=y,
                        patient=np.array(pid),
                        fold=np.array(fold),
                        site=np.array(site, dtype=np.float32),
                        device=np.array(dev),
                        age=np.zeros(N, dtype=np.float32),
                        sex=np.zeros(N, dtype=np.int8),
                        ecg_id=np.array(ecg_id))
    np.savez_compressed(os.path.join(OUT_DIR, "ptbxl_sqi.npz"),
                        feats=sqi_feats, q=sqi_q)
    with open(os.path.join(OUT_DIR, "ptbxl_labels.json"), "w") as f:
        json.dump({"names": SUPER, "primary_scp": prim_scp}, f)
    print(f"PTB-XL: {len(X)} records, classes {np.bincount(y, minlength=5).tolist()}")


# ---------------------------------------------------------------------------
def _chapman_label_map():
    """Map Chapman acronym -> PTB-XL superclass."""
    return {
        # Normal sinus
        "SR": "NORM", "SB": "NORM", "ST": "NORM", "SA": "NORM",
        # Conduction disturbances
        "1AVB": "CD", "2AVB": "CD", "2AVB1": "CD", "2AVB2": "CD", "3AVB": "CD",
        "AVB": "CD", "AVNRT": "CD", "AVRT": "CD",
        "AF": "CD", "AFIB": "CD", "AT": "CD", "PAT": "CD",
        "LBBB": "CD", "RBBB": "CD", "ILBBB": "CD", "IRBBB": "CD", "CLBBB": "CD",
        "CRBBB": "CD", "LBBBB": "CD",
        "LAFB": "CD", "LPFB": "CD", "LFBBB": "CD",
        "WPW": "CD", "IDC": "CD",
        "PAC": "CD", "PJC": "CD", "PVC": "CD", "APB": "CD", "VPB": "CD",
        "SVT": "CD", "PSVT": "CD", "VT": "CD", "VFL": "CD", "VF": "CD",
        # ST/T changes
        "STD": "STTC", "STDD": "STTC", "STE": "STTC", "STTC": "STTC",
        "STTU": "STTC", "TWO": "STTC", "TWI": "STTC", "TInv": "STTC",
        "ABI": "STTC", "AHB": "STTC", "QAB": "STTC", "QTIE": "STTC",
        # MI
        "MI": "MI", "AMI": "MI", "IMI": "MI", "LMI": "MI", "PMI": "MI",
        "ALMI": "MI", "ASMI": "MI", "ILMI": "MI", "IPLMI": "MI", "IPMI": "MI",
        # Hypertrophy
        "LVH": "HYP", "RVH": "HYP", "LAE": "HYP", "RAE": "HYP",
        "BVH": "HYP", "VH": "HYP", "AH": "HYP", "LAH": "HYP", "RAH": "HYP",
    }


def _parse_chapman_hea(hea_path):
    """Extract SNOMED-CT diagnostic codes from a Chapman-Shaoxing .hea file.
    The codes appear on a line like:  '# Dx: 426783006,164890007,...'."""
    codes = []
    try:
        with open(hea_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("#Dx:") or line.startswith("# Dx:"):
                    rhs = line.split(":", 1)[1]
                    for c in rhs.split(","):
                        c = c.strip()
                        if c.isdigit():
                            codes.append(int(c))
                    break
    except Exception:
        return []
    return codes


def process_chapman():
    csv = pd.read_csv(os.path.join(CHAPMAN_ROOT,
                       "ConditionNames_SNOMED-CT.csv"))
    csv.columns = [c.lstrip("﻿").strip() for c in csv.columns]
    snomed2name = {int(r["Snomed_CT"]): str(r["Acronym Name"])
                   for _, r in csv.iterrows() if not pd.isna(r["Snomed_CT"])}
    name2super = _chapman_label_map()

    records_dir = os.path.join(CHAPMAN_ROOT, "WFDBRecords")
    X_list, y_list, ecg_id, sqi_list, prim = [], [], [], [], []
    t0 = time.time()
    cnt = 0
    # iterate over all .hea files
    hea_files = []
    for grp in sorted(os.listdir(records_dir)):
        grp_path = os.path.join(records_dir, grp)
        if not os.path.isdir(grp_path): continue
        for sub in sorted(os.listdir(grp_path)):
            sub_path = os.path.join(grp_path, sub)
            if not os.path.isdir(sub_path): continue
            for fn in sorted(os.listdir(sub_path)):
                if fn.endswith(".hea"):
                    hea_files.append(os.path.join(sub_path, fn))
    print(f"Chapman: scanning {len(hea_files)} .hea files", flush=True)
    MAX_KEEP = int(os.environ.get("CHAPMAN_MAX", "8000"))
    for hp in hea_files:
        if cnt >= MAX_KEEP:
            break
        codes = _parse_chapman_hea(hp)
        if not codes:
            continue
        sups = {}
        for c in codes:
            nm = snomed2name.get(c)
            if nm in name2super:
                s = name2super[nm]
                sups[s] = sups.get(s, 0) + 1
        if not sups:
            continue
        s_top = max(sups, key=sups.get)
        found_path = hp[:-4]  # strip .hea
        rid = os.path.basename(found_path)
        try:
            sig, _ = wfdb.rdsamp(found_path)
        except Exception:
            continue
        x = sig.T.astype(np.float32)
        # Chapman native is 500 Hz, 12-lead, 10 s -> 5000 samples. Resample to 100 Hz.
        if x.shape[1] != T:
            x = resample_poly(x, up=T, down=x.shape[1], axis=-1).astype(np.float32)
            if x.shape[1] > T:
                x = x[:, :T]
            elif x.shape[1] < T:
                pad = np.zeros((x.shape[0], T - x.shape[1]), dtype=np.float32)
                x = np.concatenate([x, pad], axis=-1)
        if x.shape[0] != N_LEADS:
            x = x[:N_LEADS] if x.shape[0] > N_LEADS else np.concatenate(
                [x, np.zeros((N_LEADS - x.shape[0], T), dtype=np.float32)], 0)
        sqi = _sqi_features(x)
        Xz = _zscore(x).astype(np.float16)
        X_list.append(Xz); y_list.append(SUPER_IDX[s_top])
        ecg_id.append(rid); sqi_list.append(sqi); prim.append(s_top)
        cnt += 1
        if cnt % 500 == 0:
            print(f"Chapman {cnt}  elapsed {time.time()-t0:.0f}s", flush=True)

    X = np.stack(X_list).astype(np.float16)
    y = np.array(y_list, dtype=np.int8)
    sqi_feats = np.stack(sqi_list).astype(np.float32)
    sqi_q = sqi_feats.mean(axis=1).astype(np.float32)
    np.savez_compressed(os.path.join(OUT_DIR, "chapman_proc.npz"),
                        X=X, y=y, ecg_id=np.array(ecg_id),
                        patient=np.array(ecg_id))  # 1 record == 1 patient
    np.savez_compressed(os.path.join(OUT_DIR, "chapman_sqi.npz"),
                        feats=sqi_feats, q=sqi_q)
    with open(os.path.join(OUT_DIR, "chapman_labels.json"), "w") as f:
        json.dump({"names": SUPER, "primary": prim}, f)
    print(f"Chapman: {len(X)} records, classes {np.bincount(y, minlength=5).tolist()}")


if __name__ == "__main__":
    import sys
    if "ptbxl" in sys.argv or len(sys.argv) == 1:
        print(">> Processing PTB-XL")
        process_ptbxl()
    if "chapman" in sys.argv or len(sys.argv) == 1:
        print(">> Processing Chapman-Shaoxing")
        process_chapman()
    print("done.")
