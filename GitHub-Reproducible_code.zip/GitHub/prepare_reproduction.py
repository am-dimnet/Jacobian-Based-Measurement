"""Create a separate reproduction workspace without starting any computation."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import shutil
import sys


def copy_file(source, destination):
    # APFS clones are independent copy-on-write files, not symbolic or hard links.
    if sys.platform == 'darwin':
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.clonefile(os.fsencode(source), os.fsencode(destination), 0) == 0:
            shutil.copystat(source, destination)
            return destination
    return shutil.copy2(source, destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--mode', choices=['analysis', 'training'], default='analysis')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    target = args.destination.expanduser().resolve()
    if target.exists() or target == source or source in target.parents:
        parser.error('Choose a new directory outside this preserved package.')
    target.mkdir(parents=True)
    folders = ['code', 'revision/server', 'data', 'manuscript_tools', 'manuscript',
               'schematics', 'legacy', 'validation', 'scripts', 'environment',
               'supplement_round2/scripts']
    if args.mode == 'analysis':
        folders = [v for v in folders if v != 'supplement_round2/scripts']
        folders += ['analysis', 'measurements', 'runs', 'supplement_round2']
    for relative in folders:
        shutil.copytree(source / relative, target / relative, copy_function=copy_file,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    if args.mode == 'analysis':
        for p in (source / 'revision').glob('*.json'):
            copy_file(p, target / 'revision' / p.name)
    else:
        for name in ['normalization_input.npz', 'interference_input.npz',
                     'interference_nonflat_input.npz', 'protocol.json']:
            copy_file(source / 'supplement_round2' / name, target / 'supplement_round2' / name)
    for name in ['README.md', 'REPRODUCIBILITY.md', 'requirements.txt',
                 'requirements-cuda.txt', 'environment.yml']:
        copy_file(source / name, target / name)
    (target / 'logs').mkdir(exist_ok=True)
    (target / 'WORKSPACE.json').write_text(json.dumps({
        'mode': args.mode, 'experiments_started': False,
        'source_package': str(source), 'workspace': str(target),
        'raw_archive': 'Retained in the source package; not duplicated into this workspace.'
    }, indent=2))
    print('Prepared workspace:', target)
    print('No training, model evaluation, or analysis was started.')


if __name__ == '__main__':
    main()
