"""Read retained physical signals; predeclare additional evaluation inputs and scales."""
import sys,json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from scipy.signal import resample_poly
import wfdb
r=Path(sys.argv[1]);out=Path(sys.argv[2]) if len(sys.argv)>2 else r/'supplement_round2';out.mkdir(exist_ok=True);rawroot=Path(sys.argv[3]) if len(sys.argv)>3 else r/'data/raw'
m=json.load(open(r/'data/revision_v2/manifest.json'));rows={v['row']['record_id']:v for v in m['records']};manifest=json.load(open(r/'runs/native_composite_s20260921/manifest.json'))
leadnames=['I','II','III','aVR','aVL','aVF','V1','V2','V3','V4','V5','V6']
def read(rid):
 v=rows[rid];rec=wfdb.rdrecord(str(rawroot/v['row']['path'].split('/data/raw/',1)[1]),physical=True);ix=[[v.upper() for v in rec.sig_name].index(s.upper()) for s in leadnames];conv={'V':1.,'mV':.001,'uV':1e-6};raw=rec.p_signal[:,ix].T*np.array([conv[rec.units[i]] for i in ix])[:,None];assert np.isfinite(raw).all();return raw,rec.fs
ref=np.load(r/'runs/native_composite_s20260921/reference.npz');ids=ref['record_id'];raw=[]
for rid in ids:
 v,fs=read(rid);assert fs==100;raw.append(v)
raw=np.stack(raw);check=((raw-raw.mean(-1,keepdims=True))/(raw.std(-1,keepdims=True,ddof=1)+1e-9)).astype('float32');assert np.allclose(check,ref['X'],rtol=2e-6,atol=2e-6)
z=np.load(r/'data/revision_v2/native.npz');lookup={rid:i for i,rid in enumerate(z['record_id'])};train=np.array([lookup[rid] for rid in manifest['train_record_ids']]);fixed=np.sqrt(np.mean(z['scale_V'][train]**2,axis=0));global_s=float(np.sqrt(np.mean(fixed**2)))
np.savez_compressed(out/'normalization_input.npz',physical_V=raw.astype('float32'),X=ref['X'],record_id=ids,patient_id=ref['patient_id'],scale_V=ref['scale_V'],fixed_lead_V=fixed,fixed_global_V=global_s)
# The additional 500-Hz reference is held out by record in the fourth source cohort.
candidates=[rid for rid in manifest['test_record_ids'] if rid.startswith('chap:') and rows[rid]['fs']==500];rng=np.random.default_rng(260922);ids=np.array(candidates)[rng.permutation(len(candidates))[:128]];assert len(ids)==128
with ProcessPoolExecutor(max_workers=8) as pool:values=list(pool.map(read,ids))
raw=np.stack([v for v,fs in values]);assert raw.shape==(128,12,5000)
low=resample_poly(raw,1,5,axis=-1);normal=((low-low.mean(-1,keepdims=True))/(low.std(-1,keepdims=True,ddof=1)+1e-9)).astype('float32')
assert np.allclose(normal,z['X'][[lookup[rid] for rid in ids]],atol=2e-6,rtol=2e-6)
np.savez_compressed(out/'interference_input.npz',physical_500_V=raw.astype('float32'),physical_V=low.astype('float32'),X=normal,record_id=ids,patient_id=np.array([rows[rid]['row']['patient_id'] for rid in ids]),scale_V=low.std(-1),fixed_lead_V=fixed,fixed_global_V=global_s)
plan={'reference_normalization':'same 256 held-out PTB records as primary analysis; three frozen-network preprocessing schemes','fixed_scales':'sqrt mean centered temporal variance from training records only; per lead or pooled across leads; centering remains per record','schemes':['record_lead','fixed_lead','fixed_global'],'normalization_repeats':20,'normalization_K':8,'interference_N':128,'interference_cohort':'ECG-arrhythmia v1.0.0; 500 Hz; held-out records, no verified patient identity','interference_types':['white500','power50','power60','morph_local'],'resampling':'scipy.signal.resample_poly up=1 down=5 default zero-phase FIR; nominal input voltage amplitude defined before filtering','morph_local':'waveform-dependent localized amplitude modulation: Gaussian window width 0.1 s, center uniform in [2,8] s; independent per-lead signs; direction normalized to unit RMS over leads and time of each record, before resampling; not a clinically validated pathology model','noise_directions':256,'probe_repeats':20,'K':8,'interference_MC_sigmas':[.0001,.0003,.001],'normalization_MC_sigmas':[.0001,.001],'MC_draws':256,'bootstrap':2000,'MC_amplitude_grid_V':[1e-8,.01,25],'MC_refinement_cap':12,'MC_relative_root_tolerance':.001,'MC_drift_residual_tolerance':.01,'uncertainty_scope':'record bootstrap for fourth-cohort data; direction/probe resampling; fixed checkpoint; no calibration-chain uncertainty','no_training':True}
(out/'protocol.json').write_text(json.dumps(plan,indent=2));print('INPUTS VERIFIED',len(raw),flush=True)
