"""Reproduce 15 additional evaluations and 3 matching-only bracket follow-ups from retained checkpoints; writes a fresh directory."""
import argparse,json,os,subprocess,sys,threading,queue,time,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--gpus',default='0,1');p.add_argument('--workers-per-gpu',type=int,default=2);p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:raise SystemExit('Prepared only; pass --execute to evaluate stored models.')
r=a.repo.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False);(out/'logs').mkdir()
for name in ['normalization_input.npz','interference_input.npz','interference_nonflat_input.npz','protocol.json']:shutil.copy2(r/'supplement_round2'/name,out/name)
base=[sys.executable,'-u'];jobs=[]
for seed in [20260922,20260923]:
 common=['--execute','--repo',str(r),'--checkpoint',str(r/f'runs/native_composite_s{seed}/round_030.pt'),'--reference',str(r/'runs/native_composite_s20260921/reference.npz')]
 for mode,script,options in [('MC','joint_mc.py',[]),('HXV','evaluate.py',['hxv','--n','256','--Ks','8','--repeats','20'])]:
  name=f's{seed}_{mode}';jobs.append((name,base+[str(r/'revision/server'/script)]+options+common+['--out',str(out/name)]))
for scheme in ['record_lead','fixed_lead','fixed_global']:
 name='norm_'+scheme;jobs.append((name,base+[str(r/'supplement_round2/scripts/physical_eval.py'),'--repo',str(r),'--mode','normalization','--scheme',scheme,'--out',str(out/name)]))
for kind in ['white500','power50','power60','morph_local']:
 name='noise_'+kind;jobs.append((name,base+[str(r/'supplement_round2/scripts/physical_eval.py'),'--repo',str(r),'--mode','interference','--kind',kind,'--out',str(out/name)]))
for kind in ['white500','power50','power60','morph_local']:
 name='nonflat_'+kind;jobs.append((name,base+[str(r/'supplement_round2/scripts/physical_eval.py'),'--repo',str(r),'--mode','interference','--kind',kind,'--reference',str(out/'interference_nonflat_input.npz'),'--n','125','--out',str(out/name)]))
q=queue.Queue();[q.put(v) for v in jobs];status={n:dict(state='queued',command=c) for n,c in jobs};lock=threading.Lock();(out/'commands.json').write_text(json.dumps(jobs,indent=2))
def save():
 tmp=out/'status.tmp';tmp.write_text(json.dumps(status,indent=2));tmp.replace(out/'status.json')
def worker(gpu):
 while True:
  try:name,cmd=q.get_nowait()
  except queue.Empty:return
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
  with lock:status[name].update(state='running',start=time.time(),gpu=gpu);save()
  with (out/'logs'/f'{name}.log').open('w') as f:code=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  with lock:status[name].update(state='complete' if code==0 else 'failed',exitcode=code,end=time.time());save()
  q.task_done()
workers=[threading.Thread(target=worker,args=(int(g),)) for g in a.gpus.split(',') for _ in range(a.workers_per_gpu)]
for t in workers:t.start()
for t in workers:t.join()
if any(v['state']!='complete' for v in status.values()):raise SystemExit('Incomplete evaluation; inspect logs before analysis.')
# Bracket expansion is a follow-up, preserving all initial 128-record results.
for kind in ['white500','power50','power60']:
 name='expanded_'+kind;cmd=base+[str(r/'supplement_round2/scripts/physical_eval.py'),'--repo',str(r),'--mode','interference','--kind',kind,'--lower','1e-12','--reuse-energies',str(out/('noise_'+kind)),'--out',str(out/name)];q.put((name,cmd));status[name]=dict(state='queued',command=cmd)
workers=[threading.Thread(target=worker,args=(int(g),)) for g in a.gpus.split(',') for _ in range(a.workers_per_gpu)]
for t in workers:t.start()
for t in workers:t.join()
if any(v['state']!='complete' for v in status.values()):raise SystemExit('Incomplete follow-up; inspect logs.')
subprocess.run(base+[str(r/'supplement_round2/scripts/analyse_supplement.py'),str(r),str(out)],check=True)
