"""Regenerate Figure 9 from retained numerical outputs; never edit manuscript text."""
from pathlib import Path
import json,os,tempfile
import numpy as np
pack=Path(__file__).resolve().parents[1];paper=pack/'manuscript'
data=json.loads((pack/'supplement_round2/additional_results.json').read_text())
old=json.loads((pack/'analysis/new_results.json').read_text())
fmt=lambda x:'--' if x is None else f'{x:.4g}'
row001=lambda d:next(v for v in d['MC'] if v['sigma']==.001)
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'paper20_mpl'))
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'text.color':'blue','axes.labelcolor':'blue','xtick.color':'blue','ytick.color':'blue','font.family':'serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axs=plt.subplots(2,2,figsize=(7.2,5.7),constrained_layout=True);colors=['#0072B2','#D55E00','#009E73']
for idx,seed in enumerate([20260921,20260922,20260923]):
 dd=old if seed==20260921 else data[f'seed{seed}'];xx=np.array([v['sigma'] for v in dd['MC']]);yy=np.array([v['signed_deviation']*100 for v in dd['MC']]);cc=np.array([v['signed_deviation_ci95'] for v in dd['MC']])*100;axs[0,0].plot(xx,yy,marker=['o','s','^'][idx],markersize=3,lw=.9,color=colors[idx],label=str(seed));axs[0,0].vlines(xx,cc[:,0],cc[:,1],color=colors[idx],lw=.7)
axs[0,0].set_xscale('log');axs[0,0].set_xlabel('Parameter multiplier σ');axs[0,0].set_ylabel('Signed deviation [%]');axs[0,0].set_title('(a) Three trained states',fontsize=10);axs[0,0].legend(fontsize=7);axs[0,0].axhline(10,color='gray',ls='--',lw=.7)
for ax,keys,labels,title in [(axs[0,1],['norm_record_lead','norm_fixed_lead','norm_fixed_global'],['Record/lead','Fixed lead','Fixed global'],'(b) Physical-input normalization'),(axs[1,0],['nonflat_white500','nonflat_power50','nonflat_power60','nonflat_morph_local'],['White','50 Hz','60 Hz','Local shape'],'(c) Nonflat stratum, before filter')]:
 for idx,key in enumerate(keys):
  v=row001(data[key])
  for label,point,interval,shift,color,marker in [('Local',v['local_amplitude'],v['local_ci95'],-.12,colors[0],'o'),('MC',v['root'],v['ci95'],.12,colors[1],'s')]:
   if point is None or interval is None:continue
   ax.plot(idx+shift,point*1e6,marker=marker,color=color,label=label if idx==0 else None);ax.vlines(idx+shift,interval[0]*1e6,interval[1]*1e6,color=color)
 ax.set_xticks(range(len(keys)),labels,rotation=15);ax.set_yscale('log');ax.set_ylabel('Equivalent amplitude [μV]');ax.set_title(title,fontsize=10);ax.legend(fontsize=8)
keys=['white500','power50','power60','morph_local'];vals=[data['nonflat_'+k]['postfilter_rms'] for k in keys];ax=axs[1,1];ax.bar(range(4),vals,color=colors[0]);ax.set_xticks(range(4),['White','50 Hz','60 Hz','Local shape'],rotation=15);ax.set_ylabel('RMS after / RMS before');ax.set_title('(d) Declared digital filter',fontsize=10)
for i,v in enumerate(vals):ax.text(i,v+.02,fmt(v),ha='center',fontsize=8)
for ax in axs.flat:ax.grid(alpha=.15)
fig.savefig(paper/'fig14_physical_validation.pdf',bbox_inches='tight');fig.savefig(paper/'fig14_physical_validation.png',dpi=220,bbox_inches='tight');print('Physical-input figure regenerated')
