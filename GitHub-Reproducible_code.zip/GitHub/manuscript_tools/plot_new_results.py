"""Generate exact numerical figures from verified new_results.json; no model evaluation."""
import json,sys,os,tempfile
from pathlib import Path
import numpy as np
os.environ.setdefault("MPLCONFIGDIR",str(Path(tempfile.gettempdir())/"paper20_mpl"))
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];d=json.load(open(root/('analysis_preflight' if '--allow-profile-pending' in sys.argv else 'analysis')/'new_results.json'));out=root/'manuscript'
plt.rcParams.update({'text.color':'blue','axes.labelcolor':'blue','xtick.color':'blue','ytick.color':'blue','font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],'font.size':9,'axes.labelsize':9,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})
colors=['#0072B2','#D55E00','#009E73'];fig,axs=plt.subplots(2,2,figsize=(7.1,5.6),constrained_layout=True)
ax=axs[0,0];sigma=np.array([v['sigma'] for v in d['MC']]);yy=np.array([v['signed_deviation']*100 for v in d['MC']]);ci=np.array([v['signed_deviation_ci95'] for v in d['MC']])*100
ax.plot(sigma,yy,'o-',color=colors[0],markersize=3);ax.vlines(sigma,ci[:,0],ci[:,1],color=colors[0],linewidth=1);ax.hlines(ci[:,0],sigma/1.06,sigma*1.06,color=colors[0],linewidth=1);ax.hlines(ci[:,1],sigma/1.06,sigma*1.06,color=colors[0],linewidth=1);ax.axhline(10,color='gray',ls='--',lw=.8);ax.axhline(-10,color='gray',ls='--',lw=.8);ax.axhline(0,color='gray',lw=.5);ax.set_xscale('log');ax.set_xlabel('Parameter multiplier σ');ax.set_ylabel('(CF − MC) / MC [%]');ax.set_title('(a) Squared-drift matching: 95% intervals',fontsize=9)
ax=axs[0,1];rounds=[0,1,5,10,20,30]
for i,seed in enumerate([20260921,20260922,20260923]):
 vals=[d['trajectories'][f'trajectory_s{seed}_r{v:03d}'] for v in rounds[:-1]]+[next(x['sensitivity'] for x in d['models'] if x['name']==f'native_composite_s{seed}')]
 ax.errorbar(rounds,[v['R_ratio_of_means'] for v in vals],yerr=[v['single_run_type_A_sd'] for v in vals],color=colors[i],marker=['o','s','^'][i],lw=1,label=str(seed))
ax.set_yscale('log');ax.set_xlabel('Communication round');ax.set_ylabel('Sensitivity coefficient R');ax.set_title('(b) State dependence; bars: probe SD',fontsize=9);ax.legend()
ax=axs[1,0];ks=[2,4,8,16,32];vals=[d['K_sweep'][str(k)] for k in ks];ax.plot(ks,[v['single_run_type_A_sd']/v['R_mean_of_runs']*100 for v in vals],'o-',color=colors[0]);ax.set_xticks(ks);ax.set_xlabel('Output probes K');ax.set_ylabel('Single-run SD / mean [%]');ax.set_title('(c) Twenty repeats, fixed 32 records',fontsize=9)
ax=axs[1,1]
for i,seed in enumerate([20260921,20260922,20260923]):
 vals=[next(v['sensitivity'] for v in d['models'] if v['name']==f'dirichlet_{alpha}_s{seed}') for alpha in ['0.1','0.5','1.0','iid']];ax.errorbar(np.arange(4)+(i-1)*.15,[v['R_ratio_of_means'] for v in vals],yerr=[v['single_run_type_A_sd'] for v in vals],fmt=['o','s','^'][i],color=colors[i],capsize=2)
ax.set_xticks(range(4),['0.1','0.5','1.0','near-IID']);ax.set_xlabel('Dirichlet allocation α');ax.set_ylabel('Sensitivity coefficient R');ax.set_title('(d) Three trained states; bars: probe SD',fontsize=9)
for ax in axs.flat:ax.grid(alpha=.18)
fig.savefig(out/'fig13_revision_validation.pdf');fig.savefig(out/'fig13_revision_validation.png',dpi=300)
print(out/'fig13_revision_validation.pdf')
