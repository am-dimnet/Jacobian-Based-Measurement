"""Replot the paired figure from retained predictions; no model evaluation."""
from pathlib import Path
import os,argparse,csv,tempfile
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'paper20_mpl'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,default=Path(__file__).resolve().parents[1]);a=ap.parse_args()
root=a.package.resolve();paper=root/'manuscript';out=root/'legacy/analysis_outputs';pred=root/'legacy/results/preds/main'
methods=['local','fedavg','fedprox','scaffold','fedbn','centralised','ours'];nodes=['N1','N2','N3','N4'];seeds=list(range(20260601,20260606))
labels=['Local-only','FedAvg','FedProx','CV variant','BN variant','Centralised','Composite']
rows={(r['method'],int(r['seed']),r['node']):r for r in csv.DictReader(open(out/'paired_by_model.csv'))}
v=np.array([[[float(rows[(m,s,n)]['icc']) for n in nodes] for s in seeds] for m in methods]).mean(2);means=v.mean(1);sds=v.std(1,ddof=1)
plt.rcParams.update({'text.color':'blue','axes.labelcolor':'blue','xtick.color':'blue','ytick.color':'blue','font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight'})
fig,axes=plt.subplots(1,2,figsize=(10,3.5),gridspec_kw={'width_ratios':[1.05,1.4]});ax=axes[0];xx=np.arange(7)
ax.errorbar(means,xx,xerr=sds,fmt='o',color='#174e9a',capsize=3);ax.set_yticks(xx,labels);ax.invert_yaxis();ax.axvline(0,c='.7',lw=.7)
for y,v,sd in zip(xx,means,sds):ax.annotate(f'{v:.4f}',(v+sd,y),xytext=(4,0),textcoords='offset points',va='center',fontsize=7)
ax.set_xlim(min(0,min(means-sds))-.01,max(means+sds)+.032);ax.set_xlabel('ICC(A,1), mean ± seed SD');ax.set_title('(a) Same estimates as Table IV',loc='left');ax.grid(axis='x',alpha=.15)
for method,color in [('fedavg','#c16c17'),('ours','#174e9a')]:
 chunks=[]
 for node in nodes:
  z=np.load(pred/method/'seed20260601'/f'{node}.npz');p=np.stack([z['proba_D'+str(i)] for i in range(1,5)],axis=1).astype('float64');dom=p.mean(1).argmax(-1);chunks.append(np.take_along_axis(p,dom[:,None,None],axis=2).squeeze(-1))
 m=np.concatenate(chunks);d=m[:,0]-m[:,3];ax=axes[1];ax.scatter((m[:,0]+m[:,3])/2,d,s=4,alpha=.15,c=color,rasterized=True)
 for val,style in [(d.mean(),'-'),(d.mean()-1.96*d.std(ddof=1),':'),(d.mean()+1.96*d.std(ddof=1),':')]:ax.axhline(val,c=color,ls=style,lw=.8)
 ax.plot([],[],c=color,label=f'{"Composite" if method=="ours" else "FedAvg"}: mean {d.mean():.3f}')
axes[1].set_title('(b) Fixed seed 20260601, all nodes',loc='left');axes[1].set_xlabel('Mean dominant-class probability (D1, D4)');axes[1].set_ylabel('D1 minus D4');axes[1].legend(fontsize=7);fig.tight_layout();fig.savefig(paper/'fig10_paired_consistency.pdf');plt.close(fig)
print('Saved paired figure with Table IV association; all numeric inputs unchanged')
