"""Reanalyse saved arrays only. Never imports torch or evaluates an encoder."""
from pathlib import Path
import sys, os, json, csv, hashlib, tempfile, tempfile, tempfile, tempfile
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'paper20_mpl'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]/'legacy';WORK=ROOT/'work';PAPER=ROOT.parent/'manuscript';OUT=ROOT/'analysis_outputs';OUT.mkdir(parents=True,exist_ok=True)
(PAPER/'figures').mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'text.color':'blue','axes.labelcolor':'blue','xtick.color':'blue','ytick.color':'blue','font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight'})
METHODS=['local','fedavg','fedprox','scaffold','fedbn','centralised','ours'];NODES=['N1','N2','N3','N4'];SEEDS=list(range(20260601,20260606))
LABEL=['Local-only','FedAvg','FedProx','CV variant','BN variant','Centralised','Composite'];TEX=['Local-only','FedAvg','FedProx','Control-variate variant','BN-sharing variant','Centralised','Composite']
BLUE='#174e9a'
def save(fig,name):
 fig.savefig(PAPER/name);fig.savefig(OUT/(Path(name).stem+'.png'),dpi=160);plt.close(fig)
def icc(m):
 # Accept [..., records, fixed chains]. No clamping of valid negative ICC.
 n,k=m.shape[-2:];grand=m.mean(axis=(-2,-1));mr=m.mean(-1);mc=m.mean(-2)
 ssr=k*((mr-grand[...,None])**2).sum(-1);ssc=n*((mc-grand[...,None])**2).sum(-1)
 sst=((m-grand[...,None,None])**2).sum(axis=(-2,-1));mse=np.maximum(sst-ssr-ssc,0)/((n-1)*(k-1));msr=ssr/(n-1);msc=ssc/(k-1)
 den=msr+(k-1)*mse+k*(msc-mse)/n
 return np.divide(msr-mse,den,out=np.full_like(den,np.nan),where=den>0)
def kappa(a,b):
 po=(a==b).mean();pe=sum((a==k).mean()*(b==k).mean() for k in range(5));return float((po-pe)/(1-pe)) if pe<1 else None
def macro(y,p):
 labels=np.union1d(y,p);scores=[]
 for c in labels:
  tp=((y==c)&(p==c)).sum();den=(y==c).sum()+(p==c).sum();scores.append(2*tp/den if den else 0)
 return float(np.mean(scores))
def metrics(z):
 p=np.stack([z['proba_D'+str(i)] for i in range(1,5)],axis=1).astype('float64');dom=p.mean(1).argmax(-1);m=np.take_along_axis(p,dom[:,None,None],axis=2).squeeze(-1);d=m[:,0]-m[:,3]
 return m,dict(icc=float(icc(m)),kappa=kappa(z['pred_D1'],z['pred_D2']),cv=float((m.std(1,ddof=1)/np.maximum(abs(m.mean(1)),1e-6)).mean()),bias=float(d.mean()),difference_sd=float(d.std(ddof=1)))
cached={}
if (OUT/'paired_by_model.csv').exists():
 for r in csv.DictReader(open(OUT/'paired_by_model.csv')):cached[(r['method'],int(r['seed']),r['node'])]=r
source=json.load(open(ROOT/'results/results_v20.json'));rows=[];allmetrics=np.empty((7,5,4,4));provenance=[];boot_count=2000
for im,method in enumerate(METHODS):
 for js,seed in enumerate(SEEDS):
  for kn,node in enumerate(NODES):
   path=ROOT/f'results/preds/main/{method}/seed{seed}/{node}.npz';z=np.load(path);m,met=metrics(z)
   assert np.isfinite(m).all() and (m>=0).all() and (m<=1).all()
   original=source['results']['main'][method]['per_seed'][js][node]
   f1=macro(z['y'],z['proba_clean'].argmax(-1));assert abs(f1-original['f1'])<1e-9,(method,seed,node)
   key=(method,seed,node)
   if key in cached:
    q=[float(cached[key]['icc_ci_low']),float(cached[key]['icc_ci_high'])]
   else:
    rng=np.random.default_rng(91000+im*100+js*4+kn);bs=[]
    for offset in range(0,boot_count,100):
     idx=rng.integers(len(m),size=(min(100,boot_count-offset),len(m)));bs.extend(icc(m[idx]).tolist())
    q=np.nanquantile(bs,[.025,.975])
   row=dict(method=method,seed=seed,node=node,n_records=len(m),labels=' '.join(map(str,np.unique(z['y']))),**met,icc_ci_low=float(q[0]),icc_ci_high=float(q[1]),bootstrap_replicates=boot_count,bootstrap_unit='record conditional on stored predictions')
   rows.append(row);allmetrics[im,js,kn]=[met[k] for k in ['icc','kappa','cv','bias']]
   provenance.append(dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
with open(OUT/'paired_by_model.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
seed_av=allmetrics.mean(axis=2);means=seed_av.mean(axis=1);sds=seed_av.std(axis=1,ddof=1)
lines=[r'\begin{tabular}{lrrrr}',r'\toprule',r'Method & ICC(A,1) & $\kappa_{12}$ & CV & $D_1-D_4$ mean \\',r'\midrule']
for im in range(7):lines.append(TEX[im]+' & '+' & '.join(f'${a:.4f}\\pm{b:.4f}$' for a,b in zip(means[im],sds[im]))+r' \\')
lines.extend([r'\bottomrule',r'\end{tabular}']);(PAPER/'figures/tab2_v12_paired.tex').write_text('\n'.join(lines))
fig,axes=plt.subplots(1,2,figsize=(10,3.5),gridspec_kw={'width_ratios':[1.05,1.4]});ax=axes[0];xx=np.arange(7)
ax.errorbar(means[:,0],xx,xerr=sds[:,0],fmt='o',color=BLUE,capsize=3);ax.set_yticks(xx,LABEL);ax.invert_yaxis();ax.axvline(0,c='.7',lw=.7)
for y,v,sd in zip(xx,means[:,0],sds[:,0]):ax.annotate(f'{v:.4f}',(v+sd,y),xytext=(4,0),textcoords='offset points',va='center',fontsize=7)
lo=min(0,min(means[:,0]-sds[:,0]));hi=max(means[:,0]+sds[:,0]);ax.set_xlim(lo-.01,hi+.032);ax.set_xlabel('ICC(A,1), mean ± seed SD');ax.set_title('(a) Same estimates as Table V',loc='left');ax.grid(axis='x',alpha=.15)
for method,color in [('fedavg','#c16c17'),('ours',BLUE)]:
 chunks=[]
 for node in NODES:
  z=np.load(ROOT/f'results/preds/main/{method}/seed20260601/{node}.npz');m,_=metrics(z);chunks.append(m)
 m=np.concatenate(chunks);d=m[:,0]-m[:,3];ax=axes[1];ax.scatter((m[:,0]+m[:,3])/2,d,s=4,alpha=.15,c=color,rasterized=True)
 for val,style in [(d.mean(),'-'),(d.mean()-1.96*d.std(ddof=1),':'),(d.mean()+1.96*d.std(ddof=1),':')]:ax.axhline(val,c=color,ls=style,lw=.8)
 ax.plot([],[],c=color,label=f'{"Composite" if method=="ours" else "FedAvg"}: mean {d.mean():.3f}')
axes[1].set_title('(b) Fixed seed 20260601, all nodes',loc='left');axes[1].set_xlabel('Mean dominant-class probability (D1, D4)');axes[1].set_ylabel('D1 minus D4');axes[1].legend(fontsize=7);fig.tight_layout();save(fig,'fig10_paired_consistency.pdf')
# Descriptive summaries keep the historical macro definition; corrected seed SD.
main={};fig,axes=plt.subplots(1,2,figsize=(10,3.2),gridspec_kw={'width_ratios':[2,1]})
f1nodes=[]
for im,meth in enumerate(METHODS):
 a=np.array([[s[n]['f1'] for n in NODES] for s in source['results']['main'][meth]['per_seed']]);main[meth]={'f1_mean':float(a.mean()),'f1_seed_sd':float(a.mean(1).std(ddof=1)),'node_mean':a.mean(0).tolist(),'node_sd':a.std(0,ddof=1).tolist(),'cv_of_node_means':float(a.mean(0).std(ddof=1)/a.mean())};f1nodes.append(a.mean(0))
 axes[0].plot(NODES,a.mean(0),'o-',label=LABEL[im],lw=1);axes[0].errorbar(NODES,a.mean(0),yerr=a.std(0,ddof=1),fmt='none',capsize=2,lw=.6)
axes[0].set_ylabel('Macro-F1 (historical class convention)');axes[0].legend(ncol=2,fontsize=7);axes[1].barh(LABEL,[main[m]['cv_of_node_means'] for m in METHODS],color=BLUE);axes[1].invert_yaxis();axes[1].set_xlabel('CV of four node means (sample SD)');fig.tight_layout();save(fig,'fig6_consistency.pdf')
fig,ax=plt.subplots(figsize=(9,3));x=np.arange(4)
for im,meth in enumerate(METHODS):ax.bar(x+(im-3)*.11,main[meth]['node_mean'],width=.105,yerr=main[meth]['node_sd'],capsize=1,label=LABEL[im])
ax.set_xticks(x,NODES);ax.set_ylabel('Macro-F1');ax.legend(ncol=4,fontsize=7);fig.tight_layout();save(fig,'fig4_main_results.pdf')
# Match heterogeneity to the exact v20 main summary.
fig,axes=plt.subplots(1,2,figsize=(9,3));pri=np.array([source['nodes'][n]['prior'] for n in NODES]);base=np.zeros(4)
for c,lab in enumerate(['NORM','MI','STTC','CD','HYP']):axes[0].bar(NODES,pri[:,c],bottom=base,label=lab);base+=pri[:,c]
axes[0].set_ylabel('Class proportion');axes[0].legend(ncol=3,fontsize=7);axes[1].bar(NODES,[source['nodes'][n]['sqi_mean'] for n in NODES],color=BLUE)
for i,n in enumerate(NODES):axes[1].text(i,.9,f'n={source["nodes"][n]["n"]}\nSQI={source["nodes"][n]["sqi_mean"]:.3f}',ha='center',fontsize=8)
axes[1].set_ylim(0,1.06);axes[1].set_ylabel('Mean SQI');fig.tight_layout();save(fig,'fig3_heterogeneity.pdf')
# Ablations are historical configuration comparisons, no isolated noWeight claim.
abl={};fig,axes=plt.subplots(1,2,figsize=(9,3))
for ax,key in zip(axes,['ablation_1e-3','ablation_1e-2']):
 ab=source['results'][key];vals=[];errs=[]
 for variant in ['full','noWeight','noDamp','noDP']:
  a=np.array([[s[n]['f1'] for n in NODES] for s in ab[variant]['per_seed']]);vals.append(a.mean());errs.append(a.mean(1).std(ddof=1));abl[key+'/'+variant]={'mean':float(a.mean()),'seed_sd':float(a.mean(1).std(ddof=1)),'seeds':len(a)}
 ax.bar(range(4),vals,yerr=errs,capsize=3,color=BLUE);ax.set_xticks(range(4),['Full','FedAvg\nswitch','No damping','No noise'],fontsize=8);ax.set_title(key.replace('ablation_','sigma = '));ax.set_ylabel('Macro-F1')
fig.tight_layout();save(fig,'fig9_ablation.pdf')
# Only use the five-scale five-seed prediction sweep, never older fallback JSON.
priv=[]
for folder in sorted((ROOT/'results/preds/priv').iterdir()):
 if not folder.is_dir():continue
 print('privacy folder',folder.name)
 vals=[];ics=[]
 for seedfolder in sorted(folder.iterdir()):
  vf=[];vi=[]
  for path in sorted(seedfolder.glob('N*.npz')):
   z=np.load(path);vf.append(macro(z['y'],z['proba_clean'].argmax(-1)));_,mt=metrics(z);vi.append(mt['icc'])
  if vf:vals.append(np.mean(vf));ics.append(np.mean(vi))
 if vals:priv.append(dict(tag=folder.name,sigma=float(folder.name.replace('sigma','').replace('sig','').strip('_')),n_seeds=len(vals),f1_mean=float(np.mean(vals)),f1_sd=float(np.std(vals,ddof=1)),icc_mean=float(np.mean(ics)),icc_sd=float(np.std(ics,ddof=1))))
priv.sort(key=lambda d:d['sigma']);fig,axes=plt.subplots(1,2,figsize=(9,3));x=np.arange(len(priv))
for ax,key in zip(axes,['f1','icc']):
 ax.errorbar(x,[r[key+'_mean'] for r in priv],yerr=[r[key+'_sd'] for r in priv],fmt='o-',capsize=3,color=BLUE);ax.set_xticks(x,[f'{r["sigma"]:g}' for r in priv],rotation=30);ax.set_xlabel('Parameter perturbation multiplier sigma');ax.set_ylabel('Macro-F1' if key=='f1' else 'ICC(A,1)')
fig.tight_layout();save(fig,'fig11_privacy_v12.pdf')
# Existing architecture output: retain direct summaries, not trained reference line.
h=json.load(open(ROOT/'results/hutchinson_multi.json'));arch={};fig,ax=plt.subplots(figsize=(8,3));names=list(h['encoders'])
for ds,dx in [('ptbxl',-.18),('chapman',.18)]:
 means_h=[];sd_h=[]
 for name in names:
  a=np.array([r['R'] for r in h['encoders'][name][ds]]);arch[name+'/'+ds]={'mean':float(a.mean()),'sd':float(a.std(ddof=1)),'cv_percent':float(100*a.std(ddof=1)/a.mean())};means_h.append(a.mean());sd_h.append(a.std(ddof=1))
 ax.bar(np.arange(len(names))+dx,means_h,width=.34,yerr=sd_h,capsize=3,label=ds)
ax.set_xticks(range(len(names)),names);ax.set_ylabel('Sensitivity coefficient R');ax.legend();fig.tight_layout();save(fig,'fig12_jacobian_validation.pdf')
summary=dict(main=main,paired={m:dict(zip(['icc','kappa','cv','bias'],[{'mean':float(a),'seed_sd':float(b)} for a,b in zip(means[i],sds[i])])) for i,m in enumerate(METHODS)},ablation=abl,privacy=priv,architecture=arch,bootstrap_replicates=boot_count,bootstrap_scope='within each fixed model/node only; no patient identifiers',sources=provenance)
(OUT/'verified_analysis.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k in ['main','paired','privacy']},indent=2))
