"""Test dispatch logic with mocked child processes; never launches an experiment."""
import contextlib
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]

class Child:
    pid=12345
    def __init__(self,*args,**kwargs):pass
    def wait(self):return 0

class FailedChild(Child):
    def wait(self):return 1

def run(name,root,child=Child):
    argv=[name,'--repo',str(root),'--gpus','0','--execute']
    with patch.object(sys,'argv',argv),patch('subprocess.Popen',child),contextlib.redirect_stdout(io.StringIO()):
        runpy.run_path(str(PACKAGE/'revision/server'/name),run_name='__main__')

with tempfile.TemporaryDirectory(prefix='tim-driver-test-') as temporary:
    root=Path(temporary);(root/'revision').mkdir();(root/'logs').mkdir()
    run('train_queue.py',root)
    generated=json.loads((root/'revision/training_matrix.json').read_text())
    reference=json.loads((PACKAGE/'revision/training_matrix.json').read_text())
    assert generated==reference and len(generated)==24
    status=json.loads((root/'revision/queue_status.json').read_text())
    assert all(v['state']=='complete' and v['command'][0]==sys.executable for v in status.values())
    for job in generated:
        folder=root/'runs'/job['name'];folder.mkdir()
        for round_ in [0,1,5,10,20,30]:(folder/f'round_{round_:03d}.pt').touch()
    run('measurement_queue.py',root)
    generated=json.loads((root/'revision/measurement_matrix.json').read_text())
    reference=json.loads((PACKAGE/'revision/measurement_matrix.json').read_text())
    for rows in [generated,reference]:
        for job in rows:job['checkpoint']=job['checkpoint'].split('/runs/',1)[1]
    assert generated==reference and len(generated)==48
    assert all(v['state']=='complete' for v in json.loads((root/'revision/measurement_status.json').read_text()).values())
    try:run('train_queue.py',root)
    except RuntimeError:pass
    else:raise AssertionError('Duplicate matrix was accepted')
with tempfile.TemporaryDirectory(prefix='tim-failure-test-') as temporary:
    root=Path(temporary);(root/'revision').mkdir();(root/'logs').mkdir()
    try:run('train_queue.py',root,FailedChild)
    except SystemExit:pass
    else:raise AssertionError('Child failure did not propagate')
print('PASS: unchanged 24/48 job matrices, active interpreter, duplicate guard and failure propagation. All children were mocked.')
