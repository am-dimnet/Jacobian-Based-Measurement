"""Read retained arrays and recompute statistics; no model imports or evaluation."""
from pathlib import Path
import numpy as np,json,csv,hashlib,re
w=Path(__file__).resolve().parent;r=w.parent
d=json.loads((r/'analysis/new_results.json').read_text());ex=json.loads((r/'supplement_round2/additional_results.json').read_text())
checks=[]
def check(name,a,b):
    assert np.allclose(a,b,rtol=1e-8,atol=1e-11), (name,a,b)
    checks.append(name)
def f1(y,p,fixed=False):
    return np.mean([2*np.sum((y==c)&(p==c))/max(np.sum(y==c)+np.sum(p==c),1) for c in (range(5) if fixed else np.union1d(y,p))])
def icc(m):
    n,k=m.shape[-2:];g=m.mean((-2,-1));mr=m.mean(-1);mc=m.mean(-2)
    ssr=k*((mr-g[...,None])**2).sum(-1);ssc=n*((mc-g[...,None])**2).sum(-1);sst=((m-g[...,None,None])**2).sum((-2,-1))
    mse=np.maximum(sst-ssr-ssc,0)/((n-1)*(k-1));msr=ssr/(n-1);msc=ssc/(k-1)
    return (msr-mse)/(msr+(k-1)*mse+k*(msc-mse)/n)
z=np.load(r/'measurements/E2_joint/probes_K8.npz');R=np.sqrt(z['A'].mean()/z['B'].mean());check('primary R',R,d['R'])
check('single-run Type A',np.sqrt(z['A'].mean((1,2))/z['B'].mean((1,2))).std(ddof=1),d['K8_single_run_sd_R'])
ref=np.load(r/'runs/native_composite_s20260921/reference.npz');check('patients',len(np.unique(ref['patient_id'])),248)
j=np.load(r/'analysis/joint_uncertainty.npz');mc=np.load(r/'measurements/E1_white/raw_curves.npz');s=np.sqrt((ref['scale_V'][:,1]**2).mean());check('reference',s,d['reference_V'])
cov=np.cov(j['R'],j['s']);check('joint covariance',cov,d['R_s_covariance'])
for i,row in enumerate(d['MC']):
    sig=row['sigma'];boot=mc['root_bootstrap'][i];dev=(sig*j['R']-boot)/boot;g=np.array([sig*s,sig*R]);u=2*np.sqrt(g@cov@g)
    check(f'primary {sig} U',u,row['U_k2_V']);check(f'primary {sig} MC interval',np.quantile(boot,[.025,.975]),row['MC_joint_ci95']);check(f'primary {sig} deviation interval',np.quantile(dev,[.025,.975]),row['signed_deviation_ci95'])
    check(f'primary {sig} LWR',np.quantile(abs(dev),.975)<=.1,row['eligible_LWR'])
monotone=[]
for key,info in ex.items():
    folder=r/'supplement_round2'/(f's{key[4:]}_MC' if key.startswith('seed') else key)
    if key.startswith('seed'):
        energy=np.load(r/'supplement_round2'/f's{key[4:]}_HXV/probes_K8.npz');B=energy['B']
    else:
        energy=np.load(folder/'energies.npz');B=energy['B_physical'] if key.startswith('norm') else energy['B_direction']
    check(key+' R raw',np.sqrt(energy['A'].mean()/B.mean()),info['R'])
    boot=np.load(folder/'joint_bootstrap.npz')['R'];raw=np.load(folder/'raw_curves.npz');check(key+' R interval',np.quantile(boot,[.025,.975]),info['R_ci95'])
    curve=raw['input_drift'].mean((1,2),dtype=float);monotone.append(dict(case=key,mean_curve_monotone=bool((np.diff(curve)>=0).all()),minimum_increment=float(np.diff(curve).min())))
    for i,row in enumerate(info['MC']):
        sig=row['sigma'];roots=raw['root_bootstrap'][i];valid=np.isfinite(roots);deviation=(sig*boot[valid]-roots[valid])/roots[valid]
        check(key+f' {sig} U',2*sig*boot.std(ddof=1),row['local_U_k2']);check(key+f' {sig} local percentile',np.quantile(sig*boot,[.025,.975]),row['local_ci95'])
        if row['converged']:
            assert valid.all()
            check(key+f' {sig} MC CI',np.quantile(roots,[.025,.975]),row['ci95']);check(key+f' {sig} deviation',np.quantile(deviation,[.025,.975]),row['signed_deviation_ci95']);check(key+f' {sig} criterion',np.quantile(abs(deviation),.975)<=.1,row['eligible_point'])
    print('checked',key,flush=True)
for row in d['models']:
    name=row['name'];z=np.load(r/'runs'/name/'predictions.npz');check(name+' utility F1',f1(z['y'],z['proba'].argmax(-1),True),row['utility']['macro_f1_fixed_five'])
    z=np.load(r/'measurements'/('model_'+name)/'probes_K8.npz');check(name+' R',np.sqrt(z['A'].mean()/z['B'].mean()),row['sensitivity']['R_ratio_of_means'])
    check(name+' SD',np.sqrt(z['A'].mean((1,2))/z['B'].mean((1,2))).std(ddof=1),row['sensitivity']['single_run_type_A_sd'])
for key,v in d['profile'].items():
    check(key+' median time',np.median(v['times_seconds']),v['median_seconds']);check(key+' timing percentiles',np.quantile(v['times_seconds'],[.025,.975]),v['empirical_timing_interval95'])
methods=['local','fedavg','fedprox','scaffold','fedbn','centralised','ours'];nodes=['N1','N2','N3','N4'];old=json.loads((r/'legacy/analysis_outputs/verified_analysis.json').read_text());table=list(csv.DictReader(open(r/'legacy/analysis_outputs/paired_by_model.csv')))
historical=json.loads((r/'legacy/results/results_v20.json').read_text());m_all=np.empty((7,5,4,4));f_all=np.empty((7,5,4))
for im,method in enumerate(methods):
    for js,seed in enumerate(range(20260601,20260606)):
        for kn,node in enumerate(nodes):
            z=np.load(r/f'legacy/results/preds/main/{method}/seed{seed}/{node}.npz');p=np.stack([z['proba_D'+str(i)] for i in range(1,5)],1).astype(float);dom=p.mean(1).argmax(-1);m=np.take_along_axis(p,dom[:,None,None],2).squeeze(-1)
            row=next(v for v in table if v['method']==method and int(v['seed'])==seed and v['node']==node)
            pred=z['proba_clean'].argmax(-1);fv=f1(z['y'],pred);f_all[im,js,kn]=fv;check(f'{method}/{seed}/{node} F1',fv,historical['results']['main'][method]['per_seed'][js][node]['f1'])
            pa,pb=z['pred_D1'],z['pred_D2'];po=(pa==pb).mean();pe=sum((pa==c).mean()*(pb==c).mean() for c in range(5));v=[float(icc(m)),(po-pe)/(1-pe),float((m.std(1,ddof=1)/np.maximum(abs(m.mean(1)),1e-6)).mean()),float((m[:,0]-m[:,3]).mean())]
            m_all[im,js,kn]=v
            check(f'{method}/{seed}/{node} paired values',v,[float(row[k]) for k in ['icc','kappa','cv','bias']])
            rng=np.random.default_rng(91000+im*100+js*4+kn);bs=[]
            for start in range(0,2000,100):bs.extend(icc(m[rng.integers(len(m),size=(100,len(m)))]))
            check(f'{method}/{seed}/{node} ICC bootstrap',np.quantile(bs,[.025,.975]),[float(row['icc_ci_low']),float(row['icc_ci_high'])])
    check(method+' F1 summary',f_all[im].mean(),old['main'][method]['f1_mean']);check(method+' CV',f_all[im].mean(0).std(ddof=1)/f_all[im].mean(),old['main'][method]['cv_of_node_means'])
    for c,key in enumerate(['icc','kappa','cv','bias']):
        check(method+' '+key+' mean',m_all[im].mean(1)[:,c].mean(),old['paired'][method][key]['mean']);check(method+' '+key+' seed SD',m_all[im].mean(1)[:,c].std(ddof=1),old['paired'][method][key]['seed_sd'])
    print('historical checked',method,flush=True)
report=dict(passed=True,checks=len(checks),detail=checks,monotonicity=monotone,experiments_executed=0,historical_prediction_sets=140,controlled_prediction_sets=24,bootstrap_repetitions_per_historical_set=2000)
(w/'numerical_checks.json').write_text(json.dumps(report,indent=2));print('PASS',len(checks))
