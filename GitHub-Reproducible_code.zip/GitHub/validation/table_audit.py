from pathlib import Path
import json,re,csv,numpy as np
w=Path(__file__).resolve().parent;r=w.parent;pack=r;t=(r/'manuscript/main.tex').read_text();s=(r/'manuscript/supplementary.tex').read_text()
d=json.loads((pack/'analysis/new_results.json').read_text());e=json.loads((pack/'supplement_round2/additional_results.json').read_text());legacy=json.loads((pack/'legacy/analysis_outputs/verified_analysis.json').read_text());h=json.loads((pack/'legacy/results/results_v20.json').read_text())
f=lambda x:f'{x:.4g}'
ci=lambda a,m=1:'['+', '.join(f(x*m) for x in a)+']'
checks=[]
def has(text,needle,name):
    assert needle in text,(name,needle);checks.append(name)
for v in d['MC']:
    row=' & '.join([f(v['sigma']),f(v['CF']),f(v['root'])+' '+ci(v['MC_joint_ci95']),f(v['u_V']*1e6)+r'$\pm$'+f(v['U_k2_V']*1e6),f(v['signed_deviation']*100)+' '+ci(v['signed_deviation_ci95'],100),'yes' if v['eligible_LWR'] else 'no'])
    has(t,row,'Table III '+str(v['sigma']))
for meth in legacy['paired']:
    vals=legacy['paired'][meth];row=' & '.join(f'${vals[k]["mean"]:.4f}\\pm{vals[k]["seed_sd"]:.4f}$' for k in ['icc','kappa','cv','bias'])
    has(t,row,'Table IV '+meth)
for key,v in d['profile'].items():
    row='&'.join([f(v['median_seconds']),ci(v['empirical_timing_interval95']),f(v['peak_allocated_MiB']),f(v['peak_reserved_MiB']),f(v['counted_flops']/1e9)+' G'])
    has(t,row,'Table V '+key)
for rule in ['fedavg','fedprox','noisy_fedavg','composite']:
    runs=[x for x in d['models'] if x['name'].startswith('native_'+rule+'_')];R=np.array([x['sensitivity']['R_ratio_of_means'] for x in runs]);F=np.array([x['utility']['macro_f1_fixed_five'] for x in runs]);CV=np.array([x['sensitivity']['single_run_type_A_sd']/x['sensitivity']['R_ratio_of_means']*100 for x in runs])
    row=' & '.join([f(R.mean())+r'$\pm$'+f(R.std(ddof=1)),f(CV.min())+'--'+f(CV.max()),f(F.mean())+r'$\pm$'+f(F.std(ddof=1))])
    has(t,row,'Table VI '+rule)
for v in csv.DictReader(open(pack/'legacy/analysis_outputs/paired_by_model.csv')):
    x=str(v['n_records'])+'; '+f"{float(v['icc']):.4f}"+r'\\{['+f"{float(v['icc_ci_low']):.4f}, {float(v['icc_ci_high']):.4f}"+']}'
    has(s,x,'Table S1 '+v['method']+v['seed']+v['node'])
for m in d['models']:
    name=m['name'];sn=name.replace('_',r'\_');v=m['sensitivity'];row=' & '.join([sn,f(v['R_ratio_of_means']),f(v['single_run_type_A_sd']),f(100*v['single_run_type_A_sd']/v['R_mean_of_runs']),f(m['utility']['macro_f1_fixed_five'])])
    has(s,row,'Table S4 '+name)
    if name.startswith('dirichlet_'):
        _,alpha,seed=name.split('_');seed=seed[1:];has(s,' & '.join([alpha,seed]+list(map(str,m['client_counts']))),'S2 '+name)
        for i,row in enumerate(m['class_counts']):has(s,' & '.join([alpha+'/'+seed,str(i+1)]+list(map(str,row))),'S3 '+name+str(i))
for k,v in d['structured'].items():has(s,k+r' ($R_\Sigma$) & -- & '+f(v['R'])+' & '+ci(v['ci95']),'S5 '+k)
for k in ['baseline','narrow']:
    for v in d['E4_'+k+'_MC']['results']:has(s,' & '.join([k+r' ($a^{\rm MC}$)',f(v['sigma']),f(v['root']),ci(v['ci95'])]),'S5 MC '+k+str(v['sigma']))
for b in [.5,1.,2.]:
    n=d['normalization'];row=' & '.join([str(b),f(n[f'{b}_fixed_network']['R']),f(n[f'{b}_coordinate_wrapper']['R']),f(n[f'{b}_coordinate_wrapper']['R_times_relative_reference'])]);has(s,row,'S6 '+str(b))
for rnd in [0,1,5,10,20,30]:
    vals=[]
    for seed in [20260921,20260922,20260923]:
        x=d['trajectories'].get(f'trajectory_s{seed}_r{rnd:03d}') or next(v['sensitivity'] for v in d['models'] if v['name']==f'native_composite_s{seed}')
        vals.extend([f(x['R_ratio_of_means']),f(x['single_run_type_A_sd'])])
    has(s,' & '.join([str(rnd)]+vals),'S7 '+str(rnd))
for k in ['norm_record_lead','norm_fixed_lead','norm_fixed_global','expanded_white500','expanded_power50','expanded_power60','noise_morph_local','nonflat_white500','nonflat_power50','nonflat_power60','nonflat_morph_local']:
    for v in e[k]['MC']:
        has(s,' & '.join([f(v['sigma']),f(v['local_amplitude']*1e6)+r'$\pm$'+f(v['local_U_k2']*1e6),f(v['root']*1e6),f(v['signed_deviation']*100),'converged']),'S8/9 '+k+str(v['sigma']))
        has(s,ci(v['ci95'],1e6)+' & '+ci(v['signed_deviation_ci95'],100),'S8/9 interval '+k+str(v['sigma']))
        if k.startswith('expanded') or k=='noise_morph_local':has(s,ci(v['local_ci95'],1e6),'S9a local percentile '+k+str(v['sigma']))
for seed in [20260922,20260923]:
    for v in e['seed'+str(seed)]['MC']:
        row=' & '.join([str(seed),f(v['sigma']),f(v['local_amplitude']),f(v['root'])+' '+ci(v['ci95']),f(v['signed_deviation']*100)+' '+ci(v['signed_deviation_ci95'],100),'yes' if v['eligible_point'] else 'no']);has(s,row,'S10 '+str(seed)+str(v['sigma']))
for k in ['record_lead','fixed_lead','fixed_global']:
    for lead,v in e['norm_'+k]['reference_conventions'].items():has(s,' & '.join([lead,f(v['reference_V']*1e3),f(v['u_sigma1e3_V']*1e6),ci(v['ci95_V'],1e6)]),'S11 '+k+lead)
for name,v in h['results']['main'].items():
    a=np.array([[[float(x[node][m]) if x[node][m] is not None else np.nan for m in ['acc','f1','auc']] for node in ['N1','N2','N3','N4']] for x in v['per_seed']]);means=a.mean(0);avg=np.nanmean(a,axis=1).mean(0);row=' & '.join('--' if not np.isfinite(x) else f'{x:.3f}' for x in np.concatenate([means.flatten(),avg]));has(s,row,'S12 '+name)
(w/'table_checks.json').write_text(json.dumps(dict(passed=True,checks=len(checks),detail=checks),indent=2));print('PASS table rows/interval checks',len(checks))
