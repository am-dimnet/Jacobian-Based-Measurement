"""PyTorch registered FLOP formulas without ModuleTracker autograd.grad hooks.
Only explicit registered core operators are counted; unregistered names are retained.
"""
from collections import defaultdict
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils.flop_counter import flop_registry
class CoreFlops(TorchDispatchMode):
 def __init__(self):super().__init__();self.counts=defaultdict(int);self.calls=defaultdict(int)
 def __torch_dispatch__(self,func,types,args=(),kwargs=None):
  kwargs=kwargs or {};out=func(*args,**kwargs);packet=func._overloadpacket;self.calls[str(packet)]+=1
  if packet in flop_registry:self.counts[str(packet)]+=int(flop_registry[packet](*args,**kwargs,out_val=out))
  return out
 def get_total_flops(self):return sum(self.counts.values())
 def get_flop_counts(self):return {'Global':dict(self.counts)}
