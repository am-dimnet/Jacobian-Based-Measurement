"""Server-only measurement utilities. No top-level model or data execution."""
from pathlib import Path
import json, hashlib, platform
import numpy as np

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(2**20),b''):h.update(block)
 return h.hexdigest()
def write_json(path,obj):
 Path(path).write_text(json.dumps(obj,indent=2,allow_nan=False,default=lambda x:x.item() if hasattr(x,'item') else str(x)))
def load_case(args):
 import torch,sys
 torch.set_num_threads(4)
 sys.path.insert(0,str(Path(args.repo)/'code'))
 from models import ECGEncoder
 if not args.execute:raise SystemExit('No experiment started. Pass --execute only after the server run is authorized.')
 if not torch.cuda.is_available() and args.device=='cuda':raise RuntimeError('CUDA unavailable; no implicit CPU experiment fallback')
 out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
 z=np.load(args.reference,allow_pickle=False)
 for key in ('X','record_id','patient_id'): 
  if key not in z:raise ValueError('Reference requires '+key)
 if len(np.unique(z['record_id']))!=len(z['X']):raise ValueError('Duplicate record IDs')
 indices=np.arange(min(args.n,len(z['X'])))
 if len(indices)<args.n:raise ValueError('Insufficient reference records; no silent truncation')
 x=torch.as_tensor(z['X'][indices].astype('float32'),device=args.device)
 if x.shape[1:]!=(12,1000) or not torch.isfinite(x).all():raise ValueError('Expected finite normalized N x 12 x 1000 reference')
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
 if hasattr(torch.backends,'mha'):torch.backends.mha.set_fastpath_enabled(False)
 # Disable fused attention so input and parameter gradients have consistent support.
 if torch.cuda.is_available():torch.backends.cuda.enable_flash_sdp(False);torch.backends.cuda.enable_mem_efficient_sdp(False)
 model=ECGEncoder().to(args.device).eval()
 checkpoint=torch.load(args.checkpoint,map_location=args.device,weights_only=True)
 state=checkpoint.get('encoder',checkpoint)
 model.load_state_dict(state,strict=True)
 meta=dict(checkpoint=str(args.checkpoint),checkpoint_sha256=sha(args.checkpoint),reference_sha256=sha(args.reference),record_ids=z['record_id'][indices].tolist(),patient_ids=z['patient_id'][indices].tolist(),torch=torch.__version__,cuda=torch.version.cuda,device=torch.cuda.get_device_name() if args.device=='cuda' else platform.processor(),python=platform.python_version(),parameter_count=sum(p.numel() for p in model.parameters()),arguments=vars(args),parameter_scope='trainable parameters only; all buffers fixed')
 write_json(out/'provenance.json',meta)
 return model,x,z['patient_id'][indices],out

def hxv(model,x,K,seed):
 import torch
 torch.manual_seed(seed);a=np.zeros((len(x),K));b=a.copy()
 params=tuple(model.parameters())
 for i in range(len(x)):
  xi=x[i:i+1].detach().clone().requires_grad_(True);z=model(xi)
  for k in range(K):
   v=torch.randn(z.shape,device=z.device,dtype=torch.float32).to(z.dtype);v=v/v.norm();g=torch.autograd.grad((z*v).sum(),params+(xi,),retain_graph=k<K-1)
   aa=torch.stack([t.double().square().sum() for t in g[:-1]]).sum()
   a[i,k]=z.numel()*aa.item();b[i,k]=z.numel()*g[-1].double().square().sum().item()
 if not np.isfinite(a).all() or not np.isfinite(b).all() or b.mean()<=0:raise ValueError('Nonfinite/degenerate Jacobian energies')
 return a,b

def noise(shape,kind,seed,device):
 import torch
 gen=torch.Generator(device=device).manual_seed(seed)
 if kind=='white':return torch.randn(shape,generator=gen,device=device)
 # Independent sinusoid per record/lead, phase uniform, RMS normalization sqrt(2).
 n,l,t=shape;time=torch.arange(t,device=device)/100
 lo,hi={'baseline':(.1,.5),'narrow':(20.,20.)}[kind]
 f=torch.rand((n,l,1),generator=gen,device=device)*(hi-lo)+lo
 phase=torch.rand((n,l,1),generator=gen,device=device)*(2*np.pi)
 return 2**.5*torch.sin(2*np.pi*f*time+phase)

def cluster_indices(groups,rng):
 groups=np.asarray(groups).astype(str)
 if (groups=='').any():raise ValueError('Empty patient IDs; choose a documented record-conditional reference explicitly')
 unique=np.unique(groups);draw=rng.choice(unique,len(unique),replace=True)
 return np.concatenate([np.flatnonzero(groups==g) for g in draw])
