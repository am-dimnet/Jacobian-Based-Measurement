from pathlib import Path
import numpy as np,json,sys
from common import sha,write_json
r=Path(sys.argv[1]);results=[]
for name in ['native.npz','ptb.npz']:
 p=r/'data/revision_v2'/name;q=r/'data/rebuild_verification'/name;original=np.load(p);rebuilt=np.load(q);assert original.files==rebuilt.files
 matches={k:bool(np.array_equal(original[k],rebuilt[k])) for k in original.files};assert all(matches.values()),matches
 results.append(dict(file=name,array_matches=matches,original_sha256=sha(p),rebuilt_sha256=sha(q),byte_identical=sha(p)==sha(q)))
(r/'analysis').mkdir(exist_ok=True);write_json(r/'analysis/source_rebuild_verification.json',dict(status='passed',datasets=results,scope='all saved accepted records reconstructed from source waveforms with recorded code; array equality checked for every field'))
print('SOURCE REBUILD VERIFIED',flush=True)
