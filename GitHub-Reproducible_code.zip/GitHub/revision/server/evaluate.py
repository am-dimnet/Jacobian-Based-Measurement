"""E1/E2/E4/E5/E9. Prepare only locally; requires explicit --execute on server."""
from pathlib import Path
import argparse,json,time
import numpy as np
from common import load_case,hxv,noise,write_json,cluster_indices

def repeatability(model,x,groups,out,args):
 estimates={};aa=[];bb=[]
 # Nested K prefixes use exactly the same maximum-K probes; repeats remain independent.
 for r in range(args.repeats):
  a,b=hxv(model,x,max(args.Ks),args.seed+r);aa.append(a);bb.append(b)
  print('probe_repeat',r+1,'/',args.repeats,flush=True)
 aa=np.array(aa);bb=np.array(bb)
 for k in args.Ks:
  ak=aa[:,:,:k];bk=bb[:,:,:k];rr=np.sqrt(ak.mean((1,2))/bk.mean((1,2)))
  np.savez_compressed(out/f'probes_K{k}.npz',A=ak,B=bk,R=rr,patient_id=groups)
  estimates[str(k)]={'R_ratio_of_means':float(np.sqrt(ak.mean()/bk.mean())),'R_mean_of_runs':float(rr.mean()),'single_run_type_A_sd':float(rr.std(ddof=1)),'mean_standard_uncertainty':float(rr.std(ddof=1)/np.sqrt(len(rr))),'repeats':len(rr),'N':len(x),'K_comparison':'nested prefixes of common max-K probes'}
 write_json(out/'repeatability.json',estimates)

def mc(model,x,groups,out,args):
 import torch
 from torch.func import functional_call
 params={k:p.detach() for k,p in model.named_parameters()};buffers={k:b.detach().clone() for k,b in model.named_buffers()}
 def outputs(parameters,xx):
  return torch.cat([functional_call(model,(parameters,buffers),(xx[i:i+args.batch],),strict=True) for i in range(0,len(xx),args.batch)])
 with torch.no_grad():
  base=outputs(params,x)
  # Only squared vector norm, averaged over records/draws later. No RMS before averaging.
  for sig in args.sigmas:
   for M in args.draw_counts:
    target=np.empty((len(x),M));cache={}
    for m in range(M):
     gen=torch.Generator(device=x.device).manual_seed(args.seed+100000+m)
     pp={k:v+sig*args.clip*torch.randn(v.shape,generator=gen,device=x.device,dtype=v.dtype) for k,v in params.items()}
     target[:,m]=(outputs(pp,x)-base).double().square().sum(-1).cpu().numpy()
    def evaluate(a):
     a=float(a)
     if a not in cache:
      mat=np.empty((len(x),M))
      for m in range(M):
       # Identical directions across amplitudes: common random numbers.
       dx=noise(x.shape,args.kind,args.seed+200000+m,x.device)
       mat[:,m]=(outputs(params,x+a*dx)-base).double().square().sum(-1).cpu().numpy()
      if not np.isfinite(mat).all():raise ValueError('Nonfinite input drift')
      cache[a]=mat
     return cache[a]
    if not np.isfinite(target).all():raise ValueError('Nonfinite parameter drift')
    for a in np.geomspace(args.lower,args.upper,args.grid):evaluate(a)
    def crossing(amps,curve,t):return np.flatnonzero((curve[:-1]-t)*(curve[1:]-t)<=0)
    success=False
    for it in range(args.max_refinements):
     amps=np.array(sorted(cache));curve=np.array([cache[a].mean() for a in amps]);ix=crossing(amps,curve,target.mean())
     if len(ix)!=1:break
     lo,hi=amps[ix[0]:ix[0]+2];root=float(np.interp(target.mean(),curve[ix[0]:ix[0]+2],amps[ix[0]:ix[0]+2]));res=abs(evaluate(root).mean()/target.mean()-1)
     if hi/lo-1<=args.bracket_rtol and res<=args.drift_rtol:success=True;break
     evaluate(np.sqrt(lo*hi))
    amps=np.array(sorted(cache));drifts=np.stack([cache[a] for a in amps]);curve=drifts.mean((1,2));ix=crossing(amps,curve,target.mean())
    monotone=bool((np.diff(curve)>=0).all());root=float(np.interp(target.mean(),curve[ix[0]:ix[0]+2],amps[ix[0]:ix[0]+2])) if len(ix)==1 else None
    # Crossed cluster/noise resampling. Shared parameter draws remain shared across records.
    bootstrap_grid_ok=False
    for refinement in range(13):
     rng=np.random.default_rng(args.seed+7);roots=[];fail=0;refine_segments=set()
     amps=np.array(sorted(cache));drifts=np.stack([cache[a] for a in amps])
     for b in range(args.bootstrap):
      ids=cluster_indices(groups,rng);pm=rng.integers(M,size=M);xm=rng.integers(M,size=M)
      t=target[ids][:,pm].mean();c=drifts[:,ids][:,:,xm].mean((1,2));ci=crossing(amps,c,t)
      if len(ci)!=1:fail+=1;continue
      j=ci[0];roots.append(float(np.interp(t,c[j:j+2],amps[j:j+2])))
      if amps[j+1]/amps[j]-1>args.bracket_rtol:refine_segments.add(j)
     if not refine_segments:bootstrap_grid_ok=True;break
     if refinement<12:
      for j in sorted(refine_segments):evaluate(np.sqrt(amps[j]*amps[j+1]))
    ci=np.quantile(roots,[.025,.975]).tolist() if roots else [None,None]
    halfwidth=(ci[1]-ci[0])/(2*root) if root and ci[0] is not None else None
    summary=dict(sigma=sig,kind=args.kind,N=len(x),M_parameter=M,M_input=M,root=root,ci95=ci,successful_bootstraps=len(roots),failed_bootstraps=fail,monotone=monotone,unique_crossings=len(ix),numerically_converged=success,relative_ci_halfwidth=halfwidth,precision_target=args.ci_rtol,bootstrap_interpolation_verified=bootstrap_grid_ok,converged=bool(success and monotone and bootstrap_grid_ok and fail==0 and halfwidth is not None and halfwidth<=args.ci_rtol),interval_scope='patient-cluster and independent perturbation-draw bootstrap; conditional on checkpoint')
    tag=f'{args.kind}_sigma{sig:g}_M{M}'
    np.savez_compressed(out/(tag+'.npz'),parameter_drift=target,input_drift=drifts,amplitudes=amps,root_bootstrap=np.array(roots),patient_id=groups,bootstrap_seed=args.seed+7)
    write_json(out/(tag+'.json'),summary)
    if summary['converged']:break

def structured(model,x,groups,out,args):
 import torch
 from torch.autograd.functional import jvp
 base_a,base_b=hxv(model,x,args.K,args.seed)
 report={}
 for kind in ['white','baseline','narrow']:
  b=np.zeros((len(x),args.repeats))
  for r in range(args.repeats):
   direction=noise(x.shape,kind,args.seed+300000+r,x.device)
   for i in range(0,len(x),args.batch):
    _,j=jvp(model,(x[i:i+args.batch],),(direction[i:i+args.batch],),create_graph=False,strict=True)
    b[i:i+len(j),r]=j.double().square().sum(-1).detach().cpu().numpy()
  np.savez_compressed(out/f'structured_{kind}.npz',A=base_a,B=b,patient_id=groups)
  report[kind]={'R':float(np.sqrt(base_a.mean()/b.mean())),'covariance_normalization':'trace(Sigma)=q in expectation','input_direction_repeats':args.repeats}
 write_json(out/'structured.json',report)

def normalization(model,x,groups,out,args):
 import torch
 report={}
 class Wrapper(torch.nn.Module):
  def __init__(self,model,gain):super().__init__();self.model=model;self.gain=gain
  def forward(self,x):return self.model(x/self.gain)
 for gain in [.5,1.,2.]:
  for kind in ['fixed_network','coordinate_wrapper']:
   m=model if kind=='fixed_network' else Wrapper(model,gain)
   a,b=hxv(m,x*gain,args.K,args.seed);r=float(np.sqrt(a.mean()/b.mean()));np.savez_compressed(out/f'gain{gain}_{kind}.npz',A=a,B=b,patient_id=groups)
   report[f'{gain}_{kind}']={'R':r,'R_times_relative_reference':r/gain if kind=='coordinate_wrapper' else r,'reference_factor':1/gain if kind=='coordinate_wrapper' else 1}
 write_json(out/'normalization.json',report)

def profile(model,x,groups,out,args):
 import torch
 if x.device.type!='cuda':raise ValueError('GPU profiling requires CUDA')
 def back():
  model.zero_grad(set_to_none=True);model(x).square().mean().backward()
 report={}
 for tag,fn in [('backprop',back)]+[(f'K{k}',lambda k=k:hxv(model,x,k,args.seed)) for k in args.Ks]:
  for _ in range(args.warmup):fn()
  timing=[];allocated=[];reserved=[]
  for r in range(args.repeats):
   torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();start=time.perf_counter();fn();torch.cuda.synchronize();timing.append(time.perf_counter()-start);allocated.append(torch.cuda.max_memory_allocated()/2**20);reserved.append(torch.cuda.max_memory_reserved()/2**20)
  with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],with_flops=True) as prof:fn()
  prof.export_chrome_trace(str(out/f'{tag}_trace.json'))
  from core_flops import CoreFlops
  with CoreFlops() as counter:fn()
  formula_counts={module:{str(op):count for op,count in values.items()} for module,values in counter.get_flop_counts().items()}
  write_json(out/f'{tag}_formula_flops.json',{'counts':formula_counts,'observed_operator_calls':dict(counter.calls),'unregistered':[op for op in counter.calls if op not in counter.counts]})
  ops=[dict(operator=e.key,flops=e.flops,count=e.count) for e in prof.key_averages()]
  write_json(out/f'{tag}_operators.json',ops)
  report[tag]={'times_seconds':timing,'median_seconds':float(np.median(timing)),'empirical_timing_interval95':np.quantile(timing,[.025,.975]).tolist(),'peak_allocated_MiB':max(allocated),'peak_reserved_MiB':max(reserved),'counted_flops':counter.get_total_flops(),'profiler_counted_flops':sum(e['flops'] or 0 for e in ops),'flops_scope':'PyTorch registered formula counts: matrix products and convolutions including backward, multiply-add=2 FLOPs; unregistered elementwise/normalization operations excluded; theoretical count, not hardware instructions','N':len(x)}
 write_json(out/'profile.json',report)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['hxv','mc','structured','normalization','profile']);p.add_argument('--execute',action='store_true');p.add_argument('--repo',required=True);p.add_argument('--checkpoint',required=True);p.add_argument('--reference',required=True);p.add_argument('--out',required=True);p.add_argument('--device',default='cuda');p.add_argument('--n',type=int,default=32);p.add_argument('--seed',type=int,default=260921);p.add_argument('--K',type=int,default=8);p.add_argument('--Ks',nargs='+',type=int,default=[2,4,8,16,32]);p.add_argument('--repeats',type=int,default=20);p.add_argument('--warmup',type=int,default=5);p.add_argument('--batch',type=int,default=32);p.add_argument('--sigmas',nargs='+',type=float,default=[.0001,.0003,.0005,.001,.002,.003,.01]);p.add_argument('--draw-counts',nargs='+',type=int,default=[64,128,256,512]);p.add_argument('--clip',type=float,default=1);p.add_argument('--kind',choices=['white','baseline','narrow'],default='white');p.add_argument('--lower',type=float,default=1e-7);p.add_argument('--upper',type=float,default=10);p.add_argument('--grid',type=int,default=25);p.add_argument('--max-refinements',type=int,default=40);p.add_argument('--bracket-rtol',type=float,default=.001);p.add_argument('--drift-rtol',type=float,default=.01);p.add_argument('--ci-rtol',type=float,default=.02);p.add_argument('--bootstrap',type=int,default=2000)
 args=p.parse_args();model,x,groups,out=load_case(args)
 {'hxv':repeatability,'mc':mc,'structured':structured,'normalization':normalization,'profile':profile}[args.mode](model,x,groups,out,args)
