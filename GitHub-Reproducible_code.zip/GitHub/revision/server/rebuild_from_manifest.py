"""Recreate exactly the saved accepted inputs from selected raw records and manifest."""
import argparse,json,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--raw-root',required=True);p.add_argument('--manifest',required=True);p.add_argument('--out',required=True);p.add_argument('--workers',type=int,default=8);a=p.parse_args();sys.path.insert(0,str(Path(a.repo)/'code'))
 from build_revision_data import load_record
 m=json.load(open(a.manifest));rows=[]
 for item in m['records']:
  row=dict(item['row']);suffix=row['path'].split('/data/raw/',1)[1];row['path']=str(Path(a.raw_root)/suffix);rows.append(row)
 with ProcessPoolExecutor(max_workers=a.workers) as pool:loaded=list(pool.map(load_record,rows,chunksize=8))
 assert all(v['error'] is None for v in loaded),[v for v in loaded if v['error']]
 arrays=dict(X=np.stack([v['X'] for v in loaded]),y=np.array([v['row']['y'] for v in loaded]),patient_id=np.array([v['row']['patient_id'] for v in loaded]),record_id=np.array([v['row']['record_id'] for v in loaded]),site=np.array([v['row']['site'] for v in loaded]),node=np.array([v['row']['node'] for v in loaded]),cohort=np.array([v['row']['cohort'] for v in loaded]),sqi=np.array([v['q'] for v in loaded]),scale_V=np.stack([v['scale'] for v in loaded]),fold=np.array([v['row']['fold'] for v in loaded]))
 out=Path(a.out);out.mkdir(parents=True,exist_ok=False);np.savez_compressed(out/'native.npz',**arrays);mask=arrays['cohort']=='ptb';np.savez_compressed(out/'ptb.npz',**{k:v[mask] for k,v in arrays.items()});print('reconstructed',len(rows),'records; compare arrays before training')
if __name__=='__main__':main()
