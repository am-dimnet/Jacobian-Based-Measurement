"""E6/E7/E8 controlled rerun, not a replay of unverified historical training.
Input NPZ: X [N,12,1000], y [N], patient_id, record_id, site, sqi.
Only verified PTB-XL patient IDs and superclass labels are accepted.
"""
import argparse,sys,time,copy
from pathlib import Path
import numpy as np
from common import write_json,sha

def main(a):
 if not a.execute:raise SystemExit('No training started; server authorization and --execute required.')
 import torch
 import torch.nn.functional as F
 from torch.utils.data import TensorDataset,DataLoader
 sys.path.insert(0,str(Path(a.repo)/'code'))
 from models import ECGEncoder,ProjHead
 from fed_algos import nt_xent
 out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
 if not torch.cuda.is_available():raise RuntimeError('CUDA required; no implicit local execution')
 z=np.load(a.data,allow_pickle=False)
 for k in ['X','y','patient_id','record_id','site','sqi']:
  if k not in z:raise ValueError('Missing '+k)
 X=z['X'].astype('float32');y=z['y'].astype(int);patients=z['patient_id'].astype(str)
 if set(np.unique(y))-set(range(5)):raise ValueError('Labels must be verified five-superclass indices')
 if (patients=='').any() or len(np.unique(patients))<10:raise ValueError('Real patient grouping is required')
 if len(np.unique(z['record_id']))!=len(X):raise ValueError('Duplicate record IDs')
 # Fixed evaluation split across partition and training seeds; never allocate held-out patients.
 rng=np.random.default_rng(a.split_seed);trainp=[];valp=[];testp=[]
 for cohort in sorted(np.unique(z['cohort'])) if 'cohort' in z else ['ptb']:
  mask=(z['cohort']==cohort) if 'cohort' in z else np.ones(len(patients),dtype=bool)
  ps=np.unique(patients[mask]);crng=np.random.default_rng(a.split_seed);crng.shuffle(ps);cut=int(.8*len(ps));vcut=int(.9*len(ps));trainp.extend(ps[:cut]);valp.extend(ps[cut:vcut]);testp.extend(ps[vcut:])
 trainp=np.array(trainp);valp=np.array(valp);testp=np.array(testp)
 tr=np.flatnonzero(np.isin(patients,trainp));va=np.flatnonzero(np.isin(patients,valp));te=np.flatnonzero(np.isin(patients,testp))
 prng=np.random.default_rng(a.partition_seed);allocation={};client=[[] for _ in range(4)]
 if a.alpha=='native':
  if 'node' not in z:raise ValueError('Native federation requires audited node labels')
  for i in tr:client[int(z['node'][i])].append(int(i))
 # Label-stratified assignment operates on patients, represented by modal superclass.
 for lab in ([] if a.alpha=='native' else range(5)):
  group=np.array([p for p in trainp if np.argmax(np.bincount(y[patients==p],minlength=5))==lab]);prng.shuffle(group)
  proportions=np.ones(4)/4 if a.alpha=='iid' else prng.dirichlet(np.full(4,float(a.alpha)))
  assignments=prng.choice(4,len(group),p=proportions)
  for p,c in zip(group,assignments):allocation[p]=int(c)
 if a.alpha!='native':
  for i in tr:client[allocation[patients[i]]].append(int(i))
 if min(map(len,client))<8:raise ValueError('A client has fewer than 8 records. Record this partition failure; do not silently balance or resample it.')
 manifest=dict(data_sha256=sha(a.data),args=vars(a),train_record_ids=z['record_id'][tr].tolist(),validation_record_ids=z['record_id'][va].tolist(),test_record_ids=z['record_id'][te].tolist(),clients=[dict(record_ids=z['record_id'][ii].tolist(),n=len(ii),class_counts=np.bincount(y[ii],minlength=5).tolist(),patients=len(np.unique(patients[ii]))) for ii in client],training_semantics='parameter-only clipping/noise; weighted BN buffers; projection head aggregated; AdamW FP32; independent component switches',torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name())
 write_json(out/'manifest.json',manifest)
 reference_ids=te[(z['cohort'][te]=='ptb')] if 'cohort' in z else te.copy()
 np.random.default_rng(20260902).shuffle(reference_ids);reference_ids=reference_ids[:256]
 for name,idx in [('reference',reference_ids),('validation',va)]:
  np.savez_compressed(out/(name+'.npz'),X=X[idx],y=y[idx],record_id=z['record_id'][idx],patient_id=patients[idx],scale_V=z['scale_V'][idx])
 torch.set_num_threads(4);torch.manual_seed(a.seed);np.random.seed(a.seed);torch.backends.cudnn.benchmark=False;torch.backends.cuda.matmul.allow_tf32=False
 enc=ECGEncoder().cuda();head=ProjHead().cuda();param_names=set(dict(enc.named_parameters()));buffers=set(dict(enc.named_buffers()));history=[]
 # Physically defined augmentation time base at 100 Hz (distinct from legacy 1-second index).
 def aug(x):
  x=x.clone();B,L,T=x.shape
  lengths=torch.randint(int(.07*T),int(.22*T)+1,(B,),device=x.device)
  for i,n in enumerate(lengths):
   start=torch.randint(0,T-int(n)+1,(),device=x.device);x[i,:,int(start):int(start+n)]=0
  x=x*(torch.rand((B,L,1),device=x.device)>=.2);x=x+.05*torch.randn_like(x)
  timeaxis=torch.arange(T,device=x.device)/100;freq=torch.empty(B,1,1,device=x.device).uniform_(.5,3);phase=torch.empty(B,1,1,device=x.device).uniform_(0,2*np.pi)
  return x+.04*torch.sin(2*np.pi*freq*timeaxis+phase)
 def checkpoint(r):torch.save({'encoder':enc.state_dict(),'projection':head.state_dict(),'round':r,'config':vars(a)},out/f'round_{r:03d}.pt')
 checkpoint(0)
 for r in range(1,a.rounds+1):
  torch.cuda.synchronize();tic=time.perf_counter();states=[];heads=[];losses=[];weights=[]
  original={k:v.detach().clone() for k,v in enc.state_dict().items()}
  for cid,idx in enumerate(client):
   local=copy.deepcopy(enc).train();lh=copy.deepcopy(head).train();opt=torch.optim.AdamW(list(local.parameters())+list(lh.parameters()),lr=a.lr,weight_decay=1e-4)
   data=torch.from_numpy(X[idx]);loader=DataLoader(TensorDataset(data),batch_size=min(a.batch,len(idx)),shuffle=True,drop_last=False)
   for epoch in range(a.local_epochs):
    for (xx,) in loader:
     if len(xx)<2:continue
     xx=xx.cuda();v1,v2=aug(xx),aug(xx);loss=nt_xent(lh(local(v1)),lh(local(v2)),.2)
     if a.prox_mu:loss=loss+.5*a.prox_mu*sum((p-original[n]).square().sum() for n,p in local.named_parameters())
     opt.zero_grad();loss.backward();opt.step();losses.append(float(loss.detach()))
   state=local.state_dict();delta={k:state[k]-original[k] for k in param_names};norm=torch.sqrt(sum(v.square().sum() for v in delta.values()));factor=min(1.,a.clip/max(float(norm),1e-12))
   for k in param_names:state[k]=original[k]+factor*delta[k]
   states.append({k:v.detach().cpu() for k,v in state.items()});heads.append({k:v.detach().cpu() for k,v in lh.state_dict().items()})
   prior=np.bincount(y[idx],minlength=5)/len(idx);entropy=-sum(t*np.log(t) for t in prior if t>0)/np.log(5)
   weights.append(len(idx)*(1+.5*entropy)*(1+.5*float(z['sqi'][idx].mean())) if a.quality_weight else len(idx))
   del local,lh,opt
  weights=np.array(weights)/sum(weights);merged={}
  for key,v in original.items():
   if v.dtype.is_floating_point:
    agg=sum(float(w)*st[key].to(v.device) for w,st in zip(weights,states))
    if key in param_names:
     delta=agg-v
     if key.startswith(('stem.','blocks.0.','blocks.1.')):delta=delta*a.damping
     agg=v+delta
     if a.sigma:agg=agg+a.sigma*a.clip*torch.randn_like(agg)
    merged[key]=agg
   else:merged[key]=torch.stack([st[key] for st in states]).max(0).values.to(v.device)
  enc.load_state_dict(merged,strict=True);head.load_state_dict({k:sum(float(w)*st[k] for w,st in zip(weights,heads)).cuda() for k in heads[0]})
  torch.cuda.synchronize();history.append(dict(round=r,loss=float(np.mean(losses)),round_seconds=time.perf_counter()-tic));write_json(out/'history.json',history)
  print(f'round={r} loss={history[-1]["loss"]:.5f} seconds={history[-1]["round_seconds"]:.2f}',flush=True)
  if r in [1,5,10,20,30] or r==a.rounds:checkpoint(r)
 # Save diagnostic utility from a fixed train/test linear probe, not the test-set tuned setting.
 enc.eval()
 def embed(indices):
  with torch.no_grad():return torch.cat([enc(torch.from_numpy(X[ii]).cuda()).cpu() for ii in np.array_split(indices,max(1,int(np.ceil(len(indices)/256))))])
 train_z=embed(tr).cuda();test_z=embed(te).cuda();clf=torch.nn.Linear(train_z.shape[1],5).cuda();opt=torch.optim.AdamW(clf.parameters(),lr=.01,weight_decay=.001);yt=torch.as_tensor(y[tr],device='cuda')
 for _ in range(40):
  order=torch.randperm(len(tr),device='cuda')
  for ids in order.split(256):loss=F.cross_entropy(clf(train_z[ids]),yt[ids]);opt.zero_grad();loss.backward();opt.step()
 with torch.no_grad():proba=clf(test_z).softmax(-1).cpu().numpy()
 from sklearn.metrics import f1_score,accuracy_score
 write_json(out/'utility.json',dict(macro_f1_fixed_five=float(f1_score(y[te],proba.argmax(-1),labels=np.arange(5),average='macro',zero_division=0)),accuracy=float(accuracy_score(y[te],proba.argmax(-1))),scope=('native four-node held-out records; PTB patient-disjoint and Chapman record-disjoint' if a.alpha=='native' else 'common patient-disjoint PTB-XL held-out test set')+'; pooled training linear probe; separate from historical benchmark'))
 np.savez_compressed(out/'predictions.npz',y=y[te],proba=proba,record_id=z['record_id'][te],patient_id=patients[te]);torch.save(clf.state_dict(),out/'linear_probe.pt')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--repo',required=True);p.add_argument('--data',required=True);p.add_argument('--out',required=True);p.add_argument('--alpha',default='iid');p.add_argument('--seed',type=int,default=20260921);p.add_argument('--partition-seed',type=int,default=20260921);p.add_argument('--split-seed',type=int,default=20260901);p.add_argument('--rounds',type=int,default=30);p.add_argument('--local-epochs',type=int,default=1);p.add_argument('--batch',type=int,default=1024);p.add_argument('--lr',type=float,default=.001);p.add_argument('--clip',type=float,default=1);p.add_argument('--sigma',type=float,default=0);p.add_argument('--prox-mu',type=float,default=0);p.add_argument('--quality-weight',action='store_true');p.add_argument('--damping',type=float,default=1)
 main(p.parse_args())
