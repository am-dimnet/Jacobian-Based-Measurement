"""Build a documented new revision cohort from existing physical WFDB recordings.
This does not claim to reconstruct the missing historical checkpoint or data manifest.
"""
import os,ast,json,argparse,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
import wfdb
from scipy.signal import resample_poly
from fractions import Fraction
from common import write_json,sha
CLASSES=['NORM','MI','STTC','CD','HYP']
LEADS=['I','II','III','aVR','aVL','aVF','V1','V2','V3','V4','V5','V6']
# Conservative morphology/conduction superclass bridge. Arrhythmia-only labels
# (AF, flutter, tachyarrhythmia etc.) are not reassigned to CD or STTC.
CHAP={'SR':'NORM','SB':'NORM','SA':'NORM','1AVB':'CD','2AVB':'CD','2AVB1':'CD','2AVB2':'CD','3AVB':'CD','AVB':'CD','LBBB':'CD','RBBB':'CD','ILBBB':'CD','IRBBB':'CD','CLBBB':'CD','CRBBB':'CD','LAFB':'CD','LPFB':'CD','LFBBB':'CD','WPW':'CD','IVB':'CD','STD':'STTC','STDD':'STTC','STE':'STTC','STTC':'STTC','STTU':'STTC','TWO':'STTC','TWI':'STTC','TInv':'STTC','MI':'MI','AMI':'MI','IMI':'MI','ALMI':'MI','ASMI':'MI','ILMI':'MI','LVH':'HYP','RVH':'HYP','LAE':'HYP','RAE':'HYP','BVH':'HYP'}
def load_record(row):
 try:
  rec=wfdb.rdrecord(row['path'],physical=True)
  if any(x.upper() not in [n.upper() for n in rec.sig_name] for x in LEADS):raise ValueError('Missing canonical leads')
  ix=[[n.upper() for n in rec.sig_name].index(x.upper()) for x in LEADS]
  conv={'V':1.,'mV':.001,'uV':.000001};f=np.array([conv[rec.units[i]] for i in ix]);raw=rec.p_signal[:,ix].T*f[:,None]
  ratio=Fraction(100/rec.fs).limit_denominator(10000);x=resample_poly(raw,ratio.numerator,ratio.denominator,axis=-1)
  if x.shape!=(12,1000) or not np.isfinite(x).all():raise ValueError('Not finite 12 lead 10 second waveform')
  scale=x.std(-1,ddof=0);xm=x*1000
  # Explicit single normalization at the model boundary; avoid hidden double normalization.
  normalized=((xm-xm.mean(-1,keepdims=True))/(xm.std(-1,keepdims=True,ddof=1)+1e-6)).astype('float32')
  # Use the archived scalar SQI implementation, with its source hash recorded.
  from preprocess import _sqi_features
  q=float(_sqi_features(xm.astype('float32')).mean())
  return dict(row=row,X=normalized,scale=scale,q=q,header_sha256=sha(row['path']+'.hea'),units=[rec.units[i] for i in ix],fs=rec.fs,error=None)
 except Exception as e:return dict(row=row,error=repr(e))
def main(a):
 out=Path(a.out);out.mkdir(parents=True,exist_ok=False);sys.path.insert(0,str(Path(a.repo)/'code'))
 db=pd.read_csv(Path(a.ptb)/'ptbxl_database.csv');scp=pd.read_csv(Path(a.ptb)/'scp_statements.csv',index_col=0);rng=np.random.default_rng(a.seed);rows=[]
 for site in [0,1,2]:
  candidates=[]
  for _,r in db[db.site==site].iterrows():
   scores={}
   for code,lik in ast.literal_eval(r.scp_codes).items():
    if code in scp.index and scp.loc[code,'diagnostic_class'] in CLASSES:
     cl=scp.loc[code,'diagnostic_class'];scores[cl]=scores.get(cl,0)+float(lik or 100)
   if scores and pd.notna(r.patient_id):
    cl=max(CLASSES,key=lambda c:scores.get(c,-1));candidates.append(dict(path=str(Path(a.ptb)/r.filename_lr),record_id='ptb:'+str(r.ecg_id),patient_id='ptb:'+str(int(r.patient_id)),y=CLASSES.index(cl),site=site,node=site,cohort='ptb',fold=int(r.strat_fold)))
  chosen=rng.permutation(len(candidates))[:a.per_node];rows.extend([candidates[i] for i in chosen])
 cond=pd.read_csv(Path(a.chap)/'ConditionNames_SNOMED-CT.csv');snomed=dict(zip(cond['Snomed_CT'].astype(str),cond['Acronym Name']));heads=sorted(Path(a.chap).rglob('*.hea'));rng.shuffle(heads);chap=[];excluded=0
 for path in heads:
  codes=[]
  for line in path.read_text(errors='replace').splitlines():
   if line.replace(' ','').startswith('#Dx:'):codes=line.split(':',1)[1].replace(' ','').split(',')
  mapped=[CHAP.get(snomed.get(c,'')) for c in codes];mapped=[m for m in mapped if m is not None]
  if not mapped:excluded+=1;continue
  count={c:mapped.count(c) for c in CLASSES};cl=max(CLASSES,key=lambda c:count[c]);rid=str(path.relative_to(a.chap)).removesuffix('.hea')
  chap.append(dict(path=str(path.with_suffix('')),record_id='chap:'+rid,patient_id='chap-record:'+rid,y=CLASSES.index(cl),site=3,node=3,cohort='chap',fold=-1))
  if len(chap)>=a.per_node:break
 rows.extend(chap)
 with ProcessPoolExecutor(max_workers=a.workers) as ex:loaded=list(ex.map(load_record,rows,chunksize=8))
 failures=[r for r in loaded if r['error']];valid=[r for r in loaded if not r['error']]
 arrays=dict(X=np.stack([r['X'] for r in valid]),y=np.array([r['row']['y'] for r in valid]),patient_id=np.array([r['row']['patient_id'] for r in valid]),record_id=np.array([r['row']['record_id'] for r in valid]),site=np.array([r['row']['site'] for r in valid]),node=np.array([r['row']['node'] for r in valid]),cohort=np.array([r['row']['cohort'] for r in valid]),sqi=np.array([r['q'] for r in valid]),scale_V=np.stack([r['scale'] for r in valid]),fold=np.array([r['row']['fold'] for r in valid]))
 np.savez_compressed(out/'native.npz',**arrays)
 mask=arrays['cohort']=='ptb';np.savez_compressed(out/'ptb.npz',**{k:v[mask] for k,v in arrays.items()})
 manifest=dict(build_script_sha256=sha(__file__),seed=a.seed,per_node_cap=a.per_node,N=len(valid),node_counts=np.bincount(arrays['node']).tolist(),classes=CLASSES,ptb_label_rule='sum likelihood by superclass, zero likelihood treated as 100 as in archived preprocessor; ties CLASSES order',chap_label_rule='conservative mapped diagnosis count; arrhythmia-only records excluded; ties CLASSES order; record-level grouping only',chap_mapping=CHAP,chap_excluded_before_cap=excluded,normalization='physical mV, per-record/lead sample SD ddof=1 plus 1e-6 mV; one boundary normalization',reference_definition='sqrt(mean within-record temporal Lead-II variances), physical V, ddof=0',sqi_source_sha256=sha(Path(a.repo)/'code/preprocess.py'),ptb_metadata_sha256=sha(Path(a.ptb)/'ptbxl_database.csv'),scp_sha256=sha(Path(a.ptb)/'scp_statements.csv'),chap_dictionary_sha256=sha(Path(a.chap)/'ConditionNames_SNOMED-CT.csv'),records=[{k:v for k,v in r.items() if k not in ['X','scale']} for r in valid],failed_records=failures)
 write_json(out/'manifest.json',manifest);print(json.dumps({k:v for k,v in manifest.items() if k in ['N','node_counts','failed_records']},indent=2),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--ptb',required=True);p.add_argument('--chap',required=True);p.add_argument('--out',required=True);p.add_argument('--per-node',type=int,default=4000);p.add_argument('--seed',type=int,default=20260921);p.add_argument('--workers',type=int,default=12);main(p.parse_args())
