"""Paired arithmetic precision diagnostic, holding FP32-generated probes fixed."""
import argparse,numpy as np
from common import load_case,hxv,write_json
p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--repo',required=True);p.add_argument('--checkpoint',required=True);p.add_argument('--reference',required=True);p.add_argument('--out',required=True);p.add_argument('--n',type=int,default=32);p.add_argument('--K',type=int,default=8);p.add_argument('--seed',type=int,default=260921);p.add_argument('--device',default='cuda');a=p.parse_args();m,x,g,out=load_case(a)
a32,b32=hxv(m,x,a.K,a.seed);a64,b64=hxv(m.double(),x.double(),a.K,a.seed);r32=np.sqrt(a32.mean()/b32.mean());r64=np.sqrt(a64.mean()/b64.mean())
np.savez_compressed(out/'precision.npz',A32=a32,B32=b32,A64=a64,B64=b64,patient_id=g)
write_json(out/'precision.json',dict(R32=r32,R64=r64,relative_R_difference=(r32-r64)/r64,A_relative_difference=a32.mean()/a64.mean()-1,B_relative_difference=b32.mean()/b64.mean()-1,scope='same checkpoint converted to FP64; same FP32-generated output directions; arithmetic diagnostic not calibration uncertainty'))
