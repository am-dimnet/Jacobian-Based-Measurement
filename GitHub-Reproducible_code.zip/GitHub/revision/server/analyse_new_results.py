"""Evidence-only postprocessing: no model execution. Conditional uncertainty and result audit."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from common import write_json
from joint_mc import curves_boot,roots
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--allow-profile-pending',action='store_true');a=p.parse_args();r=Path(a.repo);m=r/'measurements';out=r/('analysis_preflight' if a.allow_profile_pending else 'analysis');out.mkdir(exist_ok=True)
q=json.load(open(r/'revision/queue_status.json'));mq=json.load(open(r/'revision/measurement_status.json'))
if not all(v['state']=='complete' for v in q.values()):raise RuntimeError('Incomplete training')
if not all(v['state']=='complete' for k,v in mq.items() if not (a.allow_profile_pending and k=='E9_profile')):raise RuntimeError('Incomplete measurements')
ref=np.load(r/'runs/native_composite_s20260921/reference.npz');z=np.load(m/'E2_joint/probes_K8.npz');A=z['A'];B=z['B'];assert np.array_equal(z['patient_id'],ref['patient_id'])
mc=np.load(m/'E1_white/raw_curves.npz');rw=mc['patient_weights'];rng=np.random.default_rng(260930);runw=rng.multinomial(A.shape[0],np.full(A.shape[0],1/A.shape[0]),size=len(rw))/A.shape[0]
av=np.sum((runw@A.mean(2))*rw,1);bv=np.sum((runw@B.mean(2))*rw,1);rb=np.sqrt(av/bv);variance=ref['scale_V'][:,1]**2;sb=np.sqrt(rw@variance);R=float(np.sqrt(A.mean()/B.mean()));s=float(np.sqrt(variance.mean()));cov=np.cov(rb,sb,ddof=1);rprobe=np.sqrt((runw@A.mean((1,2)))/(runw@B.mean((1,2))));rrecord=np.sqrt(rw@A.mean((0,2))/(rw@B.mean((0,2))))
np.savez_compressed(out/'joint_uncertainty.npz',R=rb,s=sb,A=av,B=bv,probe_only_R=rprobe,record_only_R=rrecord)
report={'R':R,'R_ci95':np.quantile(rb,[.025,.975]).tolist(),'reference_V':s,'reference_standard_uncertainty_V':float(sb.std(ddof=1)),'reference_ci95_V':np.quantile(sb,[.025,.975]).tolist(),'reference_N':len(variance),'reference_patients':len(np.unique(ref['patient_id'])),'R_s_covariance':cov.tolist(),'probe_mean_standard_uncertainty_R':float(rprobe.std(ddof=1)),'record_standard_uncertainty_R':float(rrecord.std(ddof=1)),'K8_single_run_sd_R':float(np.sqrt(A.mean((1,2))/B.mean((1,2))).std(ddof=1)),'measurement_estimate':'ratio of grand mean energies, 20 independent K=8 evaluations, N=256','calibration_scope':'conditional on nominal dataset voltages; no device SI calibration uncertainty available','bootstrap':len(rw),'MC':[]}
infos=json.load(open(m/'E1_white/mc_summary.json'))['results'];lwr=None;connected=True
for i,info in enumerate(infos):
 sig=info['sigma'];boot=mc['root_bootstrap'][i];valid=np.isfinite(boot);dev=(sig*rb[valid]-boot[valid])/boot[valid];gradient=np.array([sig*s,sig*R]);uc=float(np.sqrt(gradient@cov@gradient));u=sig*R*s;ub=sig*rb*sb;upper=float(np.quantile(abs(dev),.975));ok=bool(info['converged'] and valid.all() and upper<=.1);connected=connected and ok
 if connected:lwr=sig
 item=dict(info,CF=sig*R,u_V=u,standard_uncertainty_V=uc,U_k2_V=2*uc,u_percentile95_V=np.quantile(ub,[.025,.975]).tolist(),bootstrap_fraction_in_k2=float(np.mean(abs(ub-u)<=2*uc)),signed_deviation=(sig*R-info['root'])/info['root'] if info['root'] else None,signed_deviation_ci95=np.quantile(dev,[.025,.975]).tolist(),absolute_deviation_upper95=upper,eligible_LWR=ok,MC_joint_ci95=np.quantile(boot[valid],[.025,.975]).tolist())
 report['MC'].append(item)
report['LWR_largest_connected_tested_sigma']=lwr
# Confirm identical reference rows and no training/test leakage for every run; preserve utility details.
models=[];audit=[];native=np.load(r/'data/revision_v2/native.npz');patient_by_record=dict(zip(native['record_id'],native['patient_id']))
for name in q:
 run=r/'runs'/name;manifest=json.load(open(run/'manifest.json'));zref=np.load(run/'reference.npz');assert np.array_equal(zref['record_id'],ref['record_id']);assert np.array_equal(zref['X'],ref['X']);tr=set(manifest['train_record_ids']);va=set(manifest['validation_record_ids']);te=set(manifest['test_record_ids']);assert not (tr&te or tr&va or va&te);assert set(ref['record_id'])<=te
 h=json.load(open(m/('model_'+name)/'repeatability.json'))['8'];utility=json.load(open(run/'utility.json'));hist=json.load(open(run/'history.json'))
 models.append(dict(name=name,sensitivity=h,utility=utility,client_counts=[c['n'] for c in manifest['clients']],class_counts=[c['class_counts'] for c in manifest['clients']],median_round_seconds=float(np.median([v['round_seconds'] for v in hist]))))
 trainpat={patient_by_record[i] for i in tr};valpat={patient_by_record[i] for i in va};testpat={patient_by_record[i] for i in te};assert not (trainpat&valpat or trainpat&testpat or valpat&testpat)
 audit.append(dict(name=name,train=len(tr),validation=len(va),test=len(te),reference_equal=True,reference_disjoint_from_training=True,group_overlap_zero=True,group_scope='PTB patient identifiers; fourth cohort record surrogates'))
report['models']=models;report['trajectories']={v.name:json.load(open(v/'repeatability.json'))['8'] for v in sorted(m.glob('trajectory*'))};report['normalization']=json.load(open(m/'E5_normalization/normalization.json'));report['structured']=json.load(open(m/'E4_structured/structured.json'));report['profile']={'pending':True} if a.allow_profile_pending else json.load(open(m/'E9_profile/profile.json'));report['precision']=json.load(open(m/'E0_precision/precision.json'));report['K_sweep']=json.load(open(m/'E2_K_sweep/repeatability.json'))
# Patient/bootstrap and direction resampling for covariance-specific R.
structure={}
for kind in ['white','baseline','narrow']:
 zz=np.load(m/'E4_structured'/f'structured_{kind}.npz');aa=zz['A'];bb=zz['B'];vals=[]
 for w in rw:
  cols=rng.integers(bb.shape[1],size=bb.shape[1]);acols=rng.integers(aa.shape[1],size=aa.shape[1]);vals.append(np.sqrt(w@aa[:,acols].mean(1)/(w@bb[:,cols].mean(1))))
 structure[kind]=dict(report['structured'][kind],ci95=np.quantile(vals,[.025,.975]).tolist())
report['structured']=structure
for key in ['E4_baseline_MC','E4_narrow_MC']:report[key]=json.load(open(m/key/'mc_summary.json'))
write_json(out/'new_results.json',report);write_json(out/'split_audit.json',audit)
print(json.dumps({k:report[k] for k in ['R','reference_V','LWR_largest_connected_tested_sigma','precision']},indent=2))
