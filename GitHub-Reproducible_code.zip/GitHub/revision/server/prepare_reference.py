"""E0: raw WFDB reference, voltage metadata and patient-cluster sampling uncertainty.
CSV columns: record_id, patient_id, wfdb_record (path without extension).
The ordered CSV must identify the authorized reference ensemble explicitly.
"""
from pathlib import Path
import argparse,csv
import numpy as np
from common import write_json,sha,cluster_indices

def main(a):
 if not a.execute:raise SystemExit('Prepared only; --execute is required on the server.')
 import wfdb
 from scipy.signal import resample_poly
 from fractions import Fraction
 rows=list(csv.DictReader(open(a.records)));out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
 if not rows or any(not r['patient_id'] for r in rows):raise ValueError('Reference record and patient identifiers required')
 X=[];scales=[];metadata=[]
 normalized=np.load(a.normalized_reference,allow_pickle=False)
 lookup={str(v):i for i,v in enumerate(normalized['record_id'])}
 if len(lookup)!=len(normalized['X']):raise ValueError('Duplicate normalized reference IDs')
 canonical=['I','II','III','aVR','aVL','aVF','V1','V2','V3','V4','V5','V6']
 for row in rows:
  rec=wfdb.rdrecord(row['wfdb_record'],physical=True)
  if any(l not in rec.sig_name for l in canonical):raise ValueError('Reference requires all named canonical leads')
  idx=[rec.sig_name.index(l) for l in canonical];factors=[]
  for j in idx:
   units=rec.units[j]
   if units not in ['mV','uV','V']:raise ValueError('Unknown voltage unit '+str(units))
   factors.append({'mV':1e-3,'uV':1e-6,'V':1}[units])
  raw=rec.p_signal[:,idx].T*np.array(factors)[:,None]
  if not np.isfinite(raw).all():raise ValueError('Missing physical samples must be resolved explicitly')
  ratio=Fraction(100/rec.fs).limit_denominator(10000);wave=resample_poly(raw,ratio.numerator,ratio.denominator,axis=-1)
  if wave.shape[-1]!=1000:raise ValueError('Reference records must span exactly 10 seconds after resampling')
  scales.append(wave.std(-1,ddof=0))
  j=lookup[row['record_id']]
  if str(normalized['patient_id'][j])!=row['patient_id']:raise ValueError('Patient identity mismatch')
  X.append(normalized['X'][j].astype('float32'))
  metadata.append(dict(record_id=row['record_id'],wfdb_record=row['wfdb_record'],header_sha256=sha(row['wfdb_record']+'.hea'),fs=rec.fs,lead_names=canonical,original_units=[rec.units[j] for j in idx],adc_gain=[float(rec.adc_gain[j]) for j in idx],baseline=[int(rec.baseline[j]) for j in idx]))
 # Preserve the exact checkpoint input coordinates from the separately audited cache.
 # Raw waveforms are used for voltage reference only; their preprocessing linkage must be checked.
 groups=np.array([r['patient_id'] for r in rows]);record_ids=np.array([r['record_id'] for r in rows]);scales=np.array(scales)
 rng=np.random.default_rng(a.seed);draws=[]
 for _ in range(a.bootstrap):
  ids=cluster_indices(groups,rng);draws.append(np.sqrt(np.mean(scales[ids,1]**2)))
 np.savez_compressed(out/'reference.npz',X=np.array(X),record_id=record_ids,patient_id=groups,scale_V=scales)
 np.savez_compressed(out/'reference_uncertainty.npz',bootstrap_reference_V=np.array(draws),scale_V=scales,patient_id=groups)
 write_json(out/'reference.json',dict(reference_V=float(np.sqrt(np.mean(scales[:,1]**2))),standard_uncertainty_V=float(np.std(draws,ddof=1)),ci95_V=np.quantile(draws,[.025,.975]).tolist(),definition='sqrt(mean within-record centered Lead-II variance), temporal ddof=0; 100 Hz after anti-aliased resampling',N=len(rows),patients=len(np.unique(groups)),bootstrap=a.bootstrap,records_csv_sha256=sha(a.records),scope=a.scope,normalization='copied without alteration from audited normalized reference',normalized_reference_sha256=sha(a.normalized_reference),calibration_chain='not established by WFDB metadata alone',records=metadata))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--records',required=True);p.add_argument('--normalized-reference',required=True);p.add_argument('--out',required=True);p.add_argument('--scope',required=True,help='Describe selection and its relation to checkpoint training');p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=260921);p.add_argument('--execute',action='store_true');main(p.parse_args())
