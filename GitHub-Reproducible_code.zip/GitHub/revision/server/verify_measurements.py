"""Analytic linear-model and ECG gradient smoke checks, run before measurement."""
import argparse,time,json,sys
from pathlib import Path
import numpy as np
import torch
from common import hxv,write_json
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args();torch.set_num_threads(4);torch.manual_seed(260921)
linear=torch.nn.Linear(3,2,bias=True).double();x=torch.randn(4,3,dtype=torch.float64);A=2*(x.square().sum(-1)+1);B=linear.weight.square().sum();aa,bb=hxv(linear,x,512,10)
for est,true in [(aa,A.detach().numpy()),(bb,np.repeat(B.item(),len(x)))]:
 mean=est.mean(-1);se=est.std(-1,ddof=1)/512**.5
 assert np.all(np.abs(mean-true)<5*se+1e-12)
class Wrap(torch.nn.Module):
 def __init__(self,m,g):super().__init__();self.m=m;self.g=g
 def forward(self,x):return self.m(x/self.g)
a2,b2=hxv(Wrap(linear,2),x*2,64,13);a1,b1=hxv(linear,x,64,13)
assert np.allclose(a1,a2,rtol=1e-10);assert np.allclose(b1/4,b2,rtol=1e-10)
# Direct finite perturbation energy agrees with the exactly linear expectation.
M=20000;sig=.01;w=linear.weight.detach();eps=torch.randn(M,2,3,dtype=torch.float64);epsb=torch.randn(M,2,dtype=torch.float64)
d=(torch.einsum('mdq,nq->mnd',eps,x)+epsb[:,None,:])*sig;energies=d.square().sum(-1).mean(-1);target=sig**2*A.mean()
assert abs(energies.mean()-target)<5*energies.std(unbiased=True)/M**.5
sys.path.insert(0,str(Path(a.repo)/'code'));from models import ECGEncoder
if hasattr(torch.backends,'mha'):torch.backends.mha.set_fastpath_enabled(False)
torch.backends.cuda.enable_flash_sdp(False);torch.backends.cuda.enable_mem_efficient_sdp(False)
enc=ECGEncoder().cuda().eval();inp=torch.randn(2,12,1000,device='cuda');before={k:v.clone() for k,v in enc.named_buffers()};start=time.perf_counter();ea,eb=hxv(enc,inp,2,17);torch.cuda.synchronize();seconds=time.perf_counter()-start
assert np.isfinite(ea).all() and np.isfinite(eb).all();assert all(torch.equal(v,before[k]) for k,v in enc.named_buffers())
write_json(a.out,dict(status='passed',linear_probe_check='within five Monte Carlo standard errors',coordinate_wrapper='A preserved, B scaled by 1/4 exactly',finite_noise_linear_energy='within five MC standard errors',ECG_N2_K2_seconds=seconds,ECG_parameter_count=sum(p.numel() for p in enc.parameters()),buffers_unchanged=True,torch=torch.__version__,gpu=torch.cuda.get_device_name()))
print(Path(a.out).read_text(),flush=True)
