"""Postprocess E0/E1/E2 raw outputs; never evaluates or trains a model.
Requires aligned record order and explicit provenance review before publication.
"""
import argparse,json
from pathlib import Path
import numpy as np
from common import cluster_indices,write_json

def root(amps,curve,target):
 ix=np.flatnonzero((curve[:-1]-target)*(curve[1:]-target)<=0)
 if len(ix)!=1:return None
 k=ix[0];return float(np.interp(target,curve[k:k+2],amps[k:k+2]))
def main(a):
 out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
 z=np.load(a.probes,allow_pickle=False);ref=np.load(a.reference,allow_pickle=False);A=z['A'];B=z['B'];groups=z['patient_id']
 if A.shape!=B.shape or A.ndim!=3:raise ValueError('Expected repeats x records x probes')
 if len(ref['X'])!=A.shape[1] or not np.array_equal(ref['patient_id'],groups):raise ValueError('Reference/probe rows must match exactly; inspect record IDs in provenance')
 if 'scale_V' not in ref:raise ValueError('Physical per-record reference scales are missing')
 variance=ref['scale_V'][:,1]**2
 rng=np.random.default_rng(a.seed);draws=[];samples=[]
 for _ in range(a.bootstrap):
  ids=cluster_indices(groups,rng);runs=rng.integers(A.shape[0],size=A.shape[0]);pa=rng.integers(A.shape[2],size=A.shape[2])
  # Same bootstrap indices for numerator and denominator retain their probe covariance.
  av=A[runs][:,ids][:,:,pa].mean();bv=B[runs][:,ids][:,:,pa].mean();sv=np.sqrt(variance[ids].mean());draws.append([av,bv,np.sqrt(av/bv),sv]);samples.append((ids,runs,pa))
 draws=np.array(draws);rr=np.sqrt(A.mean((1,2))/B.mean((1,2)));R=np.sqrt(A.mean()/B.mean());s=np.sqrt(variance.mean());cov=np.cov(draws[:,2:4].T,ddof=1);results=[]
 for mcfile in sorted(Path(a.mc).glob('*.npz')):
  m=np.load(mcfile,allow_pickle=False)
  if not np.array_equal(m['patient_id'],groups):raise ValueError('MC/reference mismatch')
  info=json.load(open(mcfile.with_suffix('.json')));sig=info['sigma'];amp=root(m['amplitudes'],m['input_drift'].mean((1,2)),m['parameter_drift'].mean());signed=[];u_draw=[];mc_roots=[];failed=0
  for i,(ids,_,_) in enumerate(samples):
   M=m['parameter_drift'].shape[1];pm=rng.integers(M,size=M);xm=rng.integers(M,size=M);target=m['parameter_drift'][ids][:,pm].mean();curve=m['input_drift'][:,ids][:,:,xm].mean((1,2));rt=root(m['amplitudes'],curve,target)
   if rt is None:failed+=1;continue
   cf=sig*a.clip*draws[i,2];signed.append((cf-rt)/rt);u_draw.append(cf*draws[i,3]);mc_roots.append(rt)
  gradient=np.array([sig*a.clip*s,sig*a.clip*R]);uc=float(np.sqrt(gradient@cov@gradient));u=sig*a.clip*R*s
  result={'sigma':sig,'kind':info['kind'],'R':float(R),'reference_V':float(s),'u_V':float(u),'standard_uncertainty_V':uc,'U_k2_V':2*uc,'coverage_factor':2,'coverage_claim':'k=2 only; approximate 95% requires distribution/effective-df assessment','MC_root':amp,'MC_ci95':np.quantile(mc_roots,[.025,.975]).tolist() if mc_roots else None,'signed_deviation':float((sig*a.clip*R-amp)/amp) if amp else None,'signed_deviation_ci95':np.quantile(signed,[.025,.975]).tolist() if signed else None,'absolute_deviation_upper95':float(np.quantile(np.abs(signed),.975)) if signed else None,'bootstrap_failures':failed,'numerical_MC_convergence':info['converged'],'uncertainty_scope':'sampling and output-probe components conditional on dataset voltage metadata; calibration and numerical model effects not silently zeroed'}
  result['eligible_LWR_point']=bool(info['converged'] and failed==0 and result['absolute_deviation_upper95'] is not None and result['absolute_deviation_upper95']<=a.lwr_tolerance)
  results.append(result)
 np.savez_compressed(out/'joint_bootstrap.npz',A=draws[:,0],B=draws[:,1],R=draws[:,2],reference_V=draws[:,3]);write_json(out/'measurement_summary.json',{'estimator':'ratio of average energies over repeats; not mean of ratios','R':float(R),'single_K_run_sd':float(rr.std(ddof=1)),'R_s_covariance':cov.tolist(),'results':results,'publication_ready':False,'remaining_checks':['preprocessing and reference alignment','MC bootstrap interpolation convergence','calibration scope','numerical precision comparison','coverage approximation','select largest resolved M per scale and connected LWR sequence']})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--probes',required=True);p.add_argument('--reference',required=True);p.add_argument('--mc',required=True);p.add_argument('--out',required=True);p.add_argument('--clip',type=float,default=1);p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=260921);p.add_argument('--lwr-tolerance',type=float,default=.1);main(p.parse_args())
