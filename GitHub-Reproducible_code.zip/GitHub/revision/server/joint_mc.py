"""Shared-input-curve MC with crossed patient/draw bootstrap and verified grid refinement.
Fixed, predeclared M; no precision-based selection of favourable samples.
"""
import argparse,time
from pathlib import Path
import numpy as np
from common import load_case,noise,write_json

def weights(groups,M,B,seed):
 rng=np.random.default_rng(seed);unique,inv=np.unique(groups,return_inverse=True)
 counts=rng.multinomial(len(unique),np.full(len(unique),1/len(unique)),size=B)[:,inv].astype(float)
 counts/=counts.sum(1,keepdims=True)
 return counts,rng.multinomial(M,np.full(M,1/M),size=B)/M,rng.multinomial(M,np.full(M,1/M),size=B)/M

def curves_boot(drifts,rw,nw):
 # B x N weights multiply each A x N x M drift matrix, then paired noise weights.
 return np.stack([np.sum((rw@d)*nw,axis=1) for d in drifts],axis=1)

def roots(amps,curves,targets):
 if curves.ndim==1:curves=curves[None];targets=np.atleast_1d(targets)
 cross=(curves[:,:-1]-targets[:,None])*(curves[:,1:]-targets[:,None])<=0
 counts=cross.sum(1);ix=cross.argmax(1);row=np.arange(len(curves));lo=curves[row,ix];hi=curves[row,ix+1]
 result=np.full(len(curves),np.nan);valid=(counts==1)&(hi>lo)
 result[valid]=amps[ix[valid]]+(targets[valid]-lo[valid])/(hi[valid]-lo[valid])*(amps[ix[valid]+1]-amps[ix[valid]])
 return result,ix,counts

def run(a):
 import torch
 from torch.func import functional_call
 model,x,groups,out=load_case(a);M=a.draws;N=len(x);start=time.time()
 params={k:p.detach() for k,p in model.named_parameters()};buffers={k:b.detach().clone() for k,b in model.named_buffers()}
 def output(p,xx):return torch.cat([functional_call(model,(p,buffers),(part,),strict=True) for part in xx.split(a.batch)])
 cache={};targets=[]
 rw,pw,xw=weights(groups,M,a.bootstrap,a.seed+7)
 with torch.no_grad():
  base=output(params,x)
  for sig in a.sigmas:
   t=np.empty((N,M),dtype=np.float32)
   for m in range(M):
    gen=torch.Generator(device=x.device).manual_seed(a.seed+100000+m)
    pp={k:v+sig*a.clip*torch.randn(v.shape,generator=gen,device=x.device,dtype=v.dtype) for k,v in params.items()}
    t[:,m]=(output(pp,x)-base).double().square().sum(-1).cpu().numpy()
   if not np.isfinite(t).all():raise ValueError('Nonfinite parameter drift')
   targets.append(t);print('parameter',sig,'done',time.time()-start,flush=True)
  targets=np.stack(targets);tboot=curves_boot(targets,rw,pw).T
  # Store directions on CPU, stream groups of draws through GPU without changing RNG.
  directions=torch.stack([noise(x.shape,a.kind,a.seed+200000+m,x.device).cpu() for m in range(M)])
  def evaluate(amp):
   amp=float(amp)
   if amp in cache:return
   d=np.empty((N,M),dtype=np.float32);drawbatch=max(1,a.batch//N)
   for j in range(0,M,drawbatch):
    dx=directions[j:j+drawbatch].to(x.device);xx=(x[None]+amp*dx).flatten(0,1)
    z=output(params,xx).reshape(len(dx),N,-1)
    d[:,j:j+len(dx)]=(z-base[None]).double().square().sum(-1).cpu().numpy().T
   if not np.isfinite(d).all():raise ValueError('Nonfinite input drift')
   cache[amp]=d
  for amp in np.geomspace(a.lower,a.upper,a.grid):evaluate(amp)
  previous=None;verified=False;maxchange=None
  for iteration in range(a.max_refinements+1):
   amps=np.array(sorted(cache));drifts=np.stack([cache[v] for v in amps]);curve=drifts.mean((1,2),dtype=np.float64);cboot=curves_boot(drifts,rw,xw)
   estimates=[];boots=[];segments=set();countlist=[]
   for i,t in enumerate(targets):
    rr,ii,cc=roots(amps,curve,t.mean(dtype=np.float64));br,bi,bc=roots(amps,cboot,tboot[i]);estimates.append(rr[0]);boots.append(br);countlist.append(cc[0])
    segments.update(ii[np.isfinite(rr)].tolist());segments.update(bi[np.isfinite(br)].tolist())
   boots=np.array(boots);estimates=np.array(estimates)
   current=np.concatenate([estimates[:,None],boots],axis=1)
   if previous is not None:
    mask=np.isfinite(current)&np.isfinite(previous);same=np.array_equal(np.isfinite(current),np.isfinite(previous));maxchange=float(np.max(np.abs(current[mask]/previous[mask]-1))) if mask.any() else None
    if same and maxchange is not None and maxchange<=a.interpolation_rtol:verified=True;break
   print('grid',iteration,'amplitudes',len(amps),'max_root_change',maxchange,flush=True)
   if iteration==a.max_refinements or not segments:break
   previous=current
   for j in sorted(segments):evaluate(np.sqrt(amps[j]*amps[j+1]))
  residuals=[]
  for i,rt in enumerate(estimates):
   if np.isfinite(rt):evaluate(rt);residuals.append(float(abs(cache[float(rt)].mean(dtype=np.float64)/targets[i].mean(dtype=np.float64)-1)))
   else:residuals.append(None)
  # Exact root evaluations are retained too, while bootstrap uses the explicitly verified grid above.
  np.savez_compressed(out/'raw_curves.npz',parameter_drift=targets,input_drift=drifts,amplitudes=amps,sigmas=np.array(a.sigmas),root_bootstrap=boots,patient_id=groups,patient_weights=rw,parameter_weights=pw,input_weights=xw)
  report=[]
  for i,sig in enumerate(a.sigmas):
   valid=np.isfinite(boots[i]);ci=np.quantile(boots[i,valid],[.025,.975]).tolist() if valid.any() else None
   numerical=bool(np.isfinite(estimates[i]) and verified and residuals[i]<=a.drift_rtol)
   report.append(dict(sigma=sig,kind=a.kind,N=N,M_parameter=M,M_input=M,root=float(estimates[i]) if np.isfinite(estimates[i]) else None,ci95=ci,failed_bootstraps=int((~valid).sum()),numerically_converged=numerical,unique_point_crossings=int(countlist[i]),root_residual=residuals[i],bootstrap_interpolation_verified=verified,maximum_refinement_root_change=maxchange,converged=numerical and valid.all(),interval_scope='crossed patient-cluster and independent parameter/input draw bootstrap, conditional on checkpoint'))
  write_json(out/'mc_summary.json',dict(results=report,bootstrap=a.bootstrap,draw_stopping='fixed M declared before evaluation; CI width reported without an arbitrary acceptance threshold',grid_stopping='all finite point/bootstrap roots change <= interpolation_rtol upon simultaneous midpoint refinement; point drift residual <= drift_rtol; cap max_refinements',amplitude_count=len(amps),seconds=time.time()-start))
  print('FINISHED',time.time()-start,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--repo',required=True);p.add_argument('--checkpoint',required=True);p.add_argument('--reference',required=True);p.add_argument('--out',required=True);p.add_argument('--device',default='cuda');p.add_argument('--n',type=int,default=256);p.add_argument('--draws',type=int,default=256);p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=260921);p.add_argument('--batch',type=int,default=512);p.add_argument('--kind',choices=['white','baseline','narrow'],default='white');p.add_argument('--sigmas',nargs='+',type=float,default=[.0001,.0003,.0005,.001,.002,.003,.01]);p.add_argument('--clip',type=float,default=1);p.add_argument('--lower',type=float,default=1e-7);p.add_argument('--upper',type=float,default=10);p.add_argument('--grid',type=int,default=25);p.add_argument('--max-refinements',type=int,default=12);p.add_argument('--interpolation-rtol',type=float,default=.001);p.add_argument('--drift-rtol',type=float,default=.01);run(p.parse_args())
