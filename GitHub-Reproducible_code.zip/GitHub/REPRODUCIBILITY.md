# Reproducibility boundaries and result map

The GitHub source distribution excludes large binary evidence. References below to included inputs, arrays and checkpoints describe the assembled package. See `EXTERNAL_ASSETS.md` for the required assets and current availability.

## Evidence hierarchy

1. `data/revision_v2/`, `runs/`, `measurements/` and `supplement_round2/` contain the retained controlled inputs and outputs.
2. `analysis/new_results.json` and `supplement_round2/additional_results.json` are the main numerical publication sources. Original raw arrays remain available to independently check these summaries.
3. `legacy/results/` contains historical predictions and summaries. Their inference definitions differ from the controlled experiment and must not be pooled silently.
4. `manuscript/` is the current final-audit article and supplement. Numerical validation is against this source snapshot.

The primary training seeds are 20260921, 20260922 and 20260923; split seed is 20260901 and reference-selection seed is 20260902. The principal reference contains 256 PTB records from 248 patients, disjoint from training. Method/state comparisons often use the common 32-record subset. The original matrices and commands are retained in `revision/` as historical execution records. Absolute server paths in these records are provenance, not active path requirements.

## Result-to-code map

| Manuscript item | Numerical source | Executable source |
|---|---|---|
| Figs. 1–2 | Method definitions | `schematics/fig1_verified.tex`, `fig2_verified.tex` |
| Figs. 3–4; Table S12 | Historical saved probabilities and labels | `manuscript_tools/reanalyse_legacy.py` |
| Fig. 5; Table IV/S1 | Historical paired predictions, shared dominant class, 2000 record bootstrap samples | `manuscript_tools/reanalyse_legacy.py`, `plot_paired.py`; independent `validation/numerical_audit.py` |
| Fig. 6 | 100 historical perturbation-sweep prediction sets | `manuscript_tools/reanalyse_legacy.py` |
| Fig. 7; Tables II/III | Joint probe/record energies and finite-amplitude drift curves | `revision/server/evaluate.py`, `joint_mc.py`, `analyse_new_results.py`, `manuscript_tools/plot_new_results.py` |
| Fig. 8 | Retained random-architecture energy summaries | `provenance/historical_code/hutchinson_multi.py`; `manuscript_tools/reanalyse_legacy.py` for retained-output plotting |
| Fig. 9; Tables S8–S11 | Physical-input and cross-seed arrays | `supplement_round2/scripts/physical_eval.py`, `analyse_supplement.py`, `manuscript_tools/plot_physical.py` |
| Table V | Synchronized profiler outputs and operation records | `revision/server/evaluate.py` profile mode, `core_flops.py`, `analyse_new_results.py` |
| Table VI; Tables S2–S4/S7 | Controlled run manifests, utility predictions, final/intermediate energies | `revision/server/train_controlled.py`, `evaluate.py`, `analyse_new_results.py` |
| Tables S5/S6 | Structured covariance, MC matching and coherent/fixed-network gain controls | `revision/server/evaluate.py`, `joint_mc.py`, `analyse_new_results.py` |
| Fig. S1 | Historical class/SQI summary | `manuscript_tools/reanalyse_legacy.py` |
| Fig. S2 | Historical configuration summaries | `manuscript_tools/reanalyse_legacy.py` |

All 19 main/supplement table units are retained in TeX. `validation/table_audit.py` checks 371 numerical rows/interval entries against the retained outputs; Table I is a definition table. The independent numerical audit performs 883 assertions against raw arrays and saved statistical summaries. These counts describe software checks, not independent experimental replicates. Historical audit receipts remain in the local evidence archive; they are not needed to run these checks.

## What is fully replayable

The controlled cohort can be reconstructed from the selected raw waveforms and manifest. Training code, seeds, partitions, exact processed arrays, checkpoint files, labels/predictions, measurement arrays and settings are included. The 24-run training and 48-job initial measurement queues are portable, fail on incomplete child jobs, and use the active Python interpreter. The additional driver replays 15 evaluations and 3 bracket extensions from retained checkpoints without retraining.

The physical-input directions are deterministic given the retained input, seeds and code; their hashes and filter energies are recorded. Parameter and input perturbations, shared resampling dependencies, frozen buffers, coordinate conventions and stopping rules follow the executed scientific sources.

## What remains limited

- Original historical trained checkpoints and the complete cached-label/SQI-to-source mapping are unavailable. Historical source scripts are included under `provenance/historical_code/` for inspection, with their original machine paths and implementation distinctions. They are not the supported end-to-end replay entry points. Historical random-architecture outputs are retained, but their unavailable source cache prevents claiming exact fresh evaluation replay.
- Some historical configuration comparisons retain only summary outputs. They support reconstruction of the reported figures, not new uncertainty estimates requiring absent independent runs.
- The controlled five-class bridge is operational. It does not recreate the original multilabel clinical task. Fourth-cohort record IDs are not verified patient identities.
- WFDB units/gains establish nominal voltage conversion, not an unbroken SI calibration chain. Missing acquisition-calibration uncertainty is not zero.
- The scalar reference measurand and direct physical-input measurand are distinct. Changing normalization, covariance, checkpoint or reporting reference changes the condition being measured.
- The 128-record full-reference additive results are numerically converged after bracket extension but do not satisfy the declared 10% criterion. Their asymmetric distributions require percentile intervals. The exploratory 125-record stratum does not replace them.
- The largest qualifying tested scales are pointwise, checkpoint-specific decisions. They do not certify untested scales or arbitrary disturbances.
- Server timing and registered core FLOP counts do not establish edge-device latency or total hardware instruction counts.

## Packaging changes

The original scientific data and result payloads are unchanged. The main scientific algorithms remain the executed implementations. Packaging changes are restricted to:

- selecting the current English manuscript and avoiding old document-rewriting pipelines;
- retaining English code, comments, documentation, metadata and filenames;
- replacing the queue's hard-coded child interpreter with `sys.executable` and exposing GPU scheduling;
- propagating failed/incomplete queue status and requiring completed training before initial measurement dispatch;
- adding a separate-workspace preparation helper and explicit execution-stage wrapper;
- adapting plot/audit input paths to the package root and extracting the physical figure builder from its earlier document-editing script;
- replacing unused legacy-cache path defaults in `code/preprocess.py` with a relative path; the SQI function used for controlled inputs is unchanged;
- excluding cloud cleanup, shutdown, upload credentials, obsolete manuscript builders and temporary render/compile caches from the runnable workflow.

Original queue and round-two source snapshots are retained under `provenance/`. `PACKAGE_MANIFEST.json` defines integrity for the current distribution, including portability changes; `EXTERNAL_ASSETS.json` lists separately stored evidence. Older transfer manifests describe their original transfer sets; do not mistake them for the manifest of this curated directory.

## Validation of this delivery

Historical packaging checks are retained in the local archive. Fresh checks write new reports under `validation/`; no historical receipt is presented as a new execution. No new training, model inference, HXV evaluation or server experiment was run. The two postprocessing entry points were also executed in a separate workspace: 2,781 numerical values agreed with the retained reports to a maximum relative difference below 4e-13 (floating-point reduction differences). Nine quantitative figures were regenerated successfully. Queue tests used mocked child processes and confirmed the original 24/48 job matrices, overwrite guards and failure propagation. A successful static/retained-array check is not a claim that a new end-to-end GPU replay was executed on the local computer.
