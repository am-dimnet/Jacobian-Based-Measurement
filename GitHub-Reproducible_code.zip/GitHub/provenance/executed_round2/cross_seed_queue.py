"""Additional fixed-checkpoint validation; no training and no previous-output overwrite."""
import os,sys,json,time,subprocess,threading
from pathlib import Path
r=Path('/root/autodl-tmp/Paper20_TIM_revision');out=r/'supplement_round2';out.mkdir(exist_ok=True);(out/'logs').mkdir(exist_ok=True)
status={};lock=threading.Lock()
def save():
 p=out/'cross_seed_status.tmp';p.write_text(json.dumps(status,indent=2));p.replace(out/'cross_seed_status.json')
def worker(gpu,seed):
 env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
 base=['--execute','--repo',str(r),'--checkpoint',str(r/f'runs/native_composite_s{seed}/round_030.pt'),'--reference',str(r/'runs/native_composite_s20260921/reference.npz')]
 for mode,script,opts in [('MC','joint_mc.py',[]),('HXV','evaluate.py',['hxv','--n','256','--Ks','8','--repeats','20'])]:
  name=f's{seed}_{mode}';dest=out/name
  if dest.exists():raise RuntimeError(f'Refusing overwrite {dest}')
  cmd=[sys.executable,'-u',str(r/'revision/server'/script)]+opts+base+['--out',str(dest)]
  with lock:status[name]=dict(state='running',gpu=gpu,command=cmd,start=time.time());save()
  with (out/'logs'/f'{name}.log').open('w') as f:code=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  with lock:status[name].update(state='complete' if code==0 else 'failed',exitcode=code,end=time.time());save()
  if code:return
threads=[threading.Thread(target=worker,args=(i,s)) for i,s in enumerate([20260922,20260923])]
for t in threads:t.start()
for t in threads:t.join()
