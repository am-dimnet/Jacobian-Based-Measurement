import json,time,subprocess,sys,hashlib,shutil
from pathlib import Path
r=Path(sys.argv[1]);out=r/'supplement_round2'
while True:
 s=json.load(open(out/'expanded_status.json'))
 if any(v['state']=='failed' for v in s.values()):raise RuntimeError('Expanded matching failed; inspect logs')
 if len(s)==3 and all(v['state']=='complete' for v in s.values()):break
 time.sleep(10)
subprocess.run([sys.executable,str(r/'revision/analyse_supplement.py'),str(r)],check=True)
executed=out/'scripts/executed'
for src,dest in [('physical_eval.py','physical_eval_expanded.py'),('analyse_supplement.py','analyse_supplement_final.py'),('expanded_queue.py','expanded_queue.py'),('archive_server_round2.py','archive_server_round2.py')]:shutil.copy2(r/'revision'/src,executed/dest)
protocol=json.load(open(out/'protocol.json'));protocol['matching_only_followup']={'types':['white500','power50','power60'],'lower_V':1e-12,'upper_V':.01,'same_saved_jacobian_energies':True,'same_random_seeds_and_128_record_reference':True,'initial_failures_retained':True};(out/'protocol.json').write_text(json.dumps(protocol,indent=2))
# Compare reused quantities and shared draws; only the amplitude-search grid changes.
checks={}
import numpy as np
for kind in ['white500','power50','power60']:
 original=out/('noise_'+kind);updated=out/('expanded_'+kind)
 assert hashlib.sha256((original/'energies.npz').read_bytes()).digest()==hashlib.sha256((updated/'energies.npz').read_bytes()).digest()
 a=np.load(original/'directions.npz');b=np.load(updated/'directions.npz');assert all(np.array_equal(a[k],b[k]) for k in a.files)
 a=np.load(original/'raw_curves.npz');b=np.load(updated/'raw_curves.npz');same=[k for k in a.files if k in ['parameter_drift','parameter_weights','input_weights','patient_weights']];assert all(np.array_equal(a[k],b[k]) for k in same)
 checks[kind]={'energies_byte_identical':True,'directions_identical':True,'unchanged_arrays':same}
(out/'expanded_reuse_audit.json').write_text(json.dumps(checks,indent=2))
items=[]
for f in sorted(out.rglob('*')):
 if not f.is_file() or f.name in ['return_manifest.json','archive_final.log']:continue
 h=hashlib.sha256()
 with f.open('rb') as stream:
  for b in iter(lambda:stream.read(2**20),b''):h.update(b)
 items.append(dict(path=str(f.relative_to(out)),bytes=f.stat().st_size,sha256=h.hexdigest()))
(out/'return_manifest.json').write_text(json.dumps(dict(files=items,total_bytes=sum(v['bytes'] for v in items)),indent=2));print('FINAL_ARCHIVE_COMPLETE',len(items),sum(v['bytes'] for v in items),flush=True)
