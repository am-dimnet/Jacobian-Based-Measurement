"""Joint resampling of retained additional experiments; no new model evaluation."""
import sys,json
from pathlib import Path
import numpy as np
r=Path(sys.argv[1]);out=Path(sys.argv[2]) if len(sys.argv)>2 else r/'supplement_round2';reports={}
def result(folder,A,B,dirB=False,scale=None):
 z=np.load(folder/'raw_curves.npz');rw=z['patient_weights'];xw=z['input_weights'];rng=np.random.default_rng(260940);nboot=len(rw);runw=rng.multinomial(len(A),np.full(len(A),1/len(A)),size=nboot)/len(A)
 a=runw@A.mean(2);ab=np.sum(a*rw,1)
 if dirB:
  # Chunk bootstrap rows to limit memory, preserving common input-draw weights in CF and MC.
  bm=B.mean(2);bb=[]
  for start in range(0,nboot,100):
   vals=(runw[start:start+100]@bm.reshape(len(A),-1)).reshape(-1,bm.shape[1],bm.shape[2]);bb.extend(np.einsum('bn,bm,bnm->b',rw[start:start+100],xw[start:start+100],vals,optimize=True))
  bb=np.array(bb)
 else:bb=np.sum((runw@B.mean(2))*rw,1)
 R=float(np.sqrt(A.mean()/B.mean()));rb=np.sqrt(ab/bb);RR=np.sqrt(A.mean(tuple(range(1,A.ndim)))/B.mean(tuple(range(1,B.ndim))));infos=json.load(open(folder/'mc_summary.json'))['results'];rows=[];connected=True;lwr=None
 for i,v in enumerate(infos):
  sigma=v['sigma'];root=z['root_bootstrap'][i];valid=np.isfinite(root)&np.isfinite(rb);dev=(sigma*rb[valid]-root[valid])/root[valid];complete=bool(valid.all() and v['converged']);ci=np.quantile(dev,[.025,.975]).tolist() if complete else None;upper=float(np.quantile(abs(dev),.975)) if complete else None
  ok=bool(v['converged'] and valid.all() and upper<=.1);connected &= ok
  if connected:lwr=sigma
  row=dict(v,local_amplitude=sigma*R,local_standard_uncertainty=float(sigma*rb.std(ddof=1)),local_U_k2=float(2*sigma*rb.std(ddof=1)),local_ci95=np.quantile(sigma*rb,[.025,.975]).tolist(),signed_deviation=(sigma*R-v['root'])/v['root'] if v['root'] else None,signed_deviation_ci95=ci,absolute_deviation_upper95=upper,eligible_point=ok)
  if not complete:row['ci95']=None
  rows.append(row)
 info=dict(R=R,R_ci95=np.quantile(rb,[.025,.975]).tolist(),single_run_sd=float(RR.std(ddof=1)),N=A.shape[1],K=A.shape[2],repeats=len(A),largest_connected_tested_sigma=lwr,MC=rows)
 np.savez_compressed(folder/'joint_bootstrap.npz',R=rb,probe_weights=runw)
 return info,rw,runw
for seed in [20260922,20260923]:
 folder=out/f's{seed}_MC';z=np.load(out/f's{seed}_HXV/probes_K8.npz');info,_,_=result(folder,z['A'],z['B']);info['amplitude_unit']='normalized-input units';reports[f'seed{seed}']=info
for name in ['norm_record_lead','norm_fixed_lead','norm_fixed_global','noise_white500','noise_power50','noise_power60','noise_morph_local']+[f'nonflat_{k}' for k in ['white500','power50','power60','morph_local'] if (out/f'nonflat_{k}'/'mc_summary.json').exists()]+[f'expanded_{k}' for k in ['white500','power50','power60'] if (out/f'expanded_{k}'/'mc_summary.json').exists()]:
 folder=out/name;z=np.load(folder/'energies.npz');isdir=name.startswith(('noise_','nonflat_','expanded_'));info,rw,runw=result(folder,z['A'],z['B_direction'] if isdir else z['B_physical'],dirB=isdir);info.update(json.load(open(folder/'definition.json')));info['amplitude_unit']='nominal V before declared preprocessing'
 if not isdir:
  ref=np.load(out/'normalization_input.npz');scales=ref['scale_V'];Rnorm=float(np.sqrt(z['A'].mean()/z['B_normalized'].mean()));Rnb=np.sqrt(np.sum((runw@z['A'].mean(2))*rw,1)/np.sum((runw@z['B_normalized'].mean(2))*rw,1));conventions={}
  for j,label in [(0,'I'),(1,'II'),(6,'V1'),(10,'V5')]:
   sb=np.sqrt(rw@(scales[:,j]**2));ub=.001*Rnb*sb;conventions[label]=dict(reference_V=float(np.sqrt(np.mean(scales[:,j]**2))),reference_standard_uncertainty_V=float(sb.std(ddof=1)),u_sigma1e3_V=float(.001*Rnorm*np.sqrt(np.mean(scales[:,j]**2))),U_k2_V=float(2*ub.std(ddof=1)),ci95_V=np.quantile(ub,[.025,.975]).tolist())
  info['normalized_R']=Rnorm;info['reference_conventions']=conventions
 reports[name]=info
(out/'additional_results.json').write_text(json.dumps(reports,indent=2,allow_nan=False))
print(json.dumps({k:{'R':v['R'],'LWR':v['largest_connected_tested_sigma'],'MC_status':[x['converged'] for x in v['MC']]} for k,v in reports.items()},indent=2))

# Diagnose the explicitly preserved flat-lead stratum from retained arrays only.
flat=(np.load(out/'interference_input.npz')['scale_V']==0).any(1);diagnostics={}
for kind in ['white500','power50','power60','morph_local']:
 folder=out/('noise_'+kind);b=np.load(folder/'energies.npz')['B_direction'].astype(float).mean((0,2,3));w=np.load(folder/'raw_curves.npz')['patient_weights'];diagnostics[kind]=dict(flat_record_input_energy_fraction=float(b[flat].sum()/b.sum()),bootstrap_replicates_without_flat_records=int((w[:,flat].sum(1)==0).sum()),bootstrap_replicates=len(w))
(out/'flat_lead_diagnostics.json').write_text(json.dumps(diagnostics,indent=2))
