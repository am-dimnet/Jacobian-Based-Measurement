import json,time,subprocess,sys
from pathlib import Path
r=Path('/root/autodl-tmp/Paper20_TIM_revision');out=r/'supplement_round2'
while True:
 cs=json.load(open(out/'cross_seed_status.json'));ps=json.load(open(out/'physical_status.json'));ns=json.load(open(out/'nonflat_status.json'))
 if any(v['state']=='failed' for v in list(cs.values())+list(ps.values())+list(ns.values())):raise RuntimeError('Evaluation failed; inspect output, no finalization')
 if len(cs)==4 and len(ps)==7 and len(ns)==4 and all(v['state']=='complete' for v in list(cs.values())+list(ps.values())+list(ns.values())):break
 time.sleep(10)
subprocess.run([sys.executable,str(r/'revision/analyse_supplement.py'),str(r)],check=True)
print('ANALYSIS_COMPLETE',flush=True)
