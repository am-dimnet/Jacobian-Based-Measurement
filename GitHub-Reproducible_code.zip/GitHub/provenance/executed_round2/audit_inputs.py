import sys,json,hashlib
from pathlib import Path
import numpy as np
r=Path(sys.argv[1]);out=r/'supplement_round2';rows={v['row']['record_id']:v for v in json.load(open(r/'data/revision_v2/manifest.json'))['records']};m=json.load(open(r/'runs/native_composite_s20260921/manifest.json'));test=set(m['test_record_ids']);train=set(m['train_record_ids']);report={}
for name in ['normalization_input','interference_input']:
 z=np.load(out/(name+'.npz'));ids=z['record_id'];assert set(ids)<=test and not set(ids)&train
 for rid in ids:
  row=rows[rid];assert hashlib.sha256(Path(row['row']['path']+'.hea').read_bytes()).hexdigest()==row['header_sha256']
 scale=z['physical_V'].astype(float).std(-1);positive=z['scale_V']>0;err=float(np.max(abs(scale[positive]/z['scale_V'][positive]-1)));assert err<1e-5,err;assert (scale[~positive]==0).all()
 flat=~positive.all(1)
 report[name]={'records':len(ids),'source_header_hashes_match':True,'test_membership_confirmed':True,'train_record_overlap':0,'physical_scale_max_relative_error_nonzero':err,'zero_variance_leads':int((~positive).sum()),'records_with_zero_variance_leads':ids[flat].tolist(),'all_zero_scales_match_raw':True}
 if name=='interference_input':
  keep=~flat;target=out/'interference_nonflat_input.npz'
  if not target.exists():np.savez_compressed(target,**{k:(z[k][keep] if k in ['physical_500_V','physical_V','X','record_id','patient_id','scale_V'] else z[k]) for k in z.files})
  report[name]['sensitivity_analysis']={'selection':'post-audit exploratory stratum: all 12 leads have strictly positive temporal variance; no threshold on model outputs','N':int(keep.sum()),'original_all_record_analysis_preserved':True,'normalization_epsilon_V':1e-9}
(out/'input_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
