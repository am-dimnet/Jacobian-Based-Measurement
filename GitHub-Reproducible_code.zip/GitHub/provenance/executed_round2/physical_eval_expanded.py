"""Frozen-encoder physical-domain preprocessing and disturbance evaluations."""
import sys,argparse,json,time,hashlib
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);p.add_argument('--mode',choices=['normalization','interference','verify'],required=True);p.add_argument('--scheme',choices=['record_lead','fixed_lead','fixed_global'],default='record_lead');p.add_argument('--kind',default='white100');p.add_argument('--block',type=int,default=8);p.add_argument('--reuse-energies');p.add_argument('--lower',type=float,default=1e-8);p.add_argument('--reference');p.add_argument('--n',type=int);a=p.parse_args()
r=Path(a.repo);sys.path.insert(0,str(r/'revision/server'))
import torch
from common import load_case,write_json,sha
from scipy.signal import resample_poly
import joint_mc
args=argparse.Namespace(execute=True,repo=str(r),checkpoint=str(r/'runs/native_composite_s20260921/round_030.pt'),reference=str(r/'supplement_round2'/('interference_input.npz' if a.mode=='interference' else 'normalization_input.npz')),out=a.out,device='cuda',n=128 if a.mode=='interference' else (4 if a.mode=='verify' else 256),seed=260922,K=8,repeats=20,draws=256,bootstrap=2000,batch=512,kind=a.kind,sigmas=[.0001,.0003,.001] if a.mode=='interference' else [.0001,.001],clip=1.,lower=1e-8,upper=.01,grid=25,max_refinements=12,interpolation_rtol=.001,drift_rtol=.01)
args.lower=a.lower
if a.reference:args.reference=a.reference
if a.n:args.n=a.n
model,xnorm,groups,out=load_case(args);torch.set_num_threads(2);z=np.load(args.reference);v=torch.as_tensor(z['physical_V'][:args.n],device='cuda');N=len(v)
class Physical(torch.nn.Module):
 def __init__(self,core,scheme):
  super().__init__();self.core=core;self.scheme=scheme
  self.register_buffer('fixed',torch.tensor(z['fixed_lead_V'] if scheme=='fixed_lead' else z['fixed_global_V'],device='cuda',dtype=torch.float32).reshape(1,-1,1))
 def normalize(self,x):return (x-x.mean(-1,keepdim=True))/(x.std(-1,keepdim=True)+1e-9 if self.scheme=='record_lead' else self.fixed)
 def forward(self,x):return self.core(self.normalize(x))
f=Physical(model,a.scheme).eval()
if a.scheme=='record_lead':assert torch.allclose(f.normalize(v),xnorm,rtol=3e-5,atol=3e-5)

def energies(K,seed,directions=None,serial=False):
 gen=torch.Generator(device='cuda').manual_seed(seed)
 probes=torch.randn((N,K,128),generator=gen,device='cuda');probes/=probes.norm(dim=-1,keepdim=True)
 aa=np.zeros((N,K));bb=aa.copy();pp=aa.copy();bd=np.zeros((N,K,args.draws),dtype=np.float32) if directions is not None else None
 params=tuple(model.parameters())
 for start in range(0,N,a.block):
  vv=v[start:start+a.block].detach().clone().requires_grad_(True);xx=f.normalize(vv);zz=model(xx);n=len(vv);ix=torch.arange(n,device='cuda')
  dd=directions[:,start:start+n].to('cuda').permute(1,0,2,3).flatten(2) if directions is not None else None
  for k in range(K):
   if serial:
    ga=[];gx=[];gv=[]
    for j in range(n):
     g=torch.autograd.grad((zz[j]*probes[start+j,k]).sum(),params+(xx,vv),retain_graph=True)
     ga.append(sum(t.double().square().sum() for t in g[:-2]));gx.append(g[-2][j]);gv.append(g[-1][j])
    ea=torch.stack(ga);ex=torch.stack(gx);ev=torch.stack(gv)
   else:
    go=torch.zeros((n,n,128),device='cuda');go[ix,ix]=probes[start:start+n,k]
    g=torch.autograd.grad(zz,params+(xx,vv),grad_outputs=go,is_grads_batched=True,retain_graph=k<K-1)
    ea=sum(t.double().square().flatten(1).sum(1) for t in g[:-2]);ex=g[-2][ix,ix];ev=g[-1][ix,ix]
   aa[start:start+n,k]=(128*ea).detach().cpu().numpy();bb[start:start+n,k]=(128*ex.double().square().flatten(1).sum(1)).detach().cpu().numpy();pp[start:start+n,k]=(128*ev.double().square().flatten(1).sum(1)).detach().cpu().numpy()
   if dd is not None:bd[start:start+n,k]=(128*torch.einsum('nt,nmt->nm',ev.flatten(1),dd).double().square()).detach().cpu().numpy()
 return aa,bb,pp,bd

if a.mode=='verify':
 t=time.time();bat=energies(2,77);ser=energies(2,77,serial=True);errors=[]
 for x,y in zip(bat[:3],ser[:3]):
  err=float(np.max(abs(x-y)/np.maximum(abs(y),1e-30)));assert np.allclose(x,y,rtol=2e-5,atol=1e-7),err;errors.append(err)
 # Directional finite difference validates differentiation through normalization.
 gen=torch.Generator(device='cuda').manual_seed(987);direction=torch.randn(v.shape,generator=gen,device='cuda');eps=1e-7
 _,j=torch.autograd.functional.jvp(f,(v,),(direction,));fd=(f(v+eps*direction)-f(v-eps*direction))/(2*eps);rel=float((fd-j).norm()/j.norm());assert rel<.01,rel
 write_json(out/'verification.json',dict(batched_vs_serial_relative_errors=errors,preprocessing_directional_derivative_relative_error=rel,seconds=time.time()-t));print('VERIFIED',errors,rel,flush=True);sys.exit()

# Generate and fingerprint the actual post-filter directions, with amplitudes referred to 500-Hz volts.
dirs=None;atten=[]
if a.mode=='interference':
 raw=z['physical_500_V'][:N];tt=np.arange(5000)/500.;centered=raw-raw.mean(-1,keepdims=True);arr=[];hashes=[]
 for m in range(args.draws):
  rng=np.random.default_rng(args.seed+200000+m)
  if a.kind=='white500':d=rng.standard_normal(raw.shape)
  elif a.kind in ['power50','power60']:
   freq=50 if a.kind=='power50' else 60;phase=rng.uniform(0,2*np.pi,(N,12,1));d=np.sqrt(2)*np.sin(2*np.pi*freq*tt+phase)
  elif a.kind=='morph_local':
   center=rng.uniform(2,8,(N,1,1));window=np.exp(-.5*((tt-center)/.1)**2);sign=rng.choice([-1.,1.],(N,12,1));d=centered*window*sign;scale=np.sqrt(np.mean(d**2,axis=(1,2),keepdims=True));assert np.all(scale>0);d/=scale
  else:raise ValueError(a.kind)
  low=resample_poly(d,1,5,axis=-1).astype('float32');atten.append(np.mean(low.astype(float)**2,axis=(1,2)));arr.append(torch.from_numpy(low));hashes.append(hashlib.sha256(low).hexdigest())
 dirs=torch.stack(arr);np.savez_compressed(out/'directions.npz',post_filter_mean_square=np.array(atten),seed=args.seed+200000,per_draw_sha256=np.array(hashes))
 print('DIRECTIONS',a.kind,'postfilter RMS',float(np.sqrt(np.mean(atten))),flush=True)

if a.reuse_energies:
 import shutil
 source=Path(a.reuse_energies);zz=np.load(source/'energies.npz');assert np.array_equal(zz['record_id'],z['record_id'][:N]);shutil.copy2(source/'energies.npz',out/'energies.npz');write_json(out/'energy_reuse.json',dict(source=str(source),sha256=sha(source/'energies.npz'),reason='matching-only follow-up with a wider physical-amplitude bracket; no new Jacobian evaluations'))
else:
 AA=[];BB=[];PP=[];DD=[];t=time.time()
 for repeat in range(args.repeats):
  aa,bb,pp,bd=energies(args.K,args.seed+repeat,dirs);AA.append(aa);BB.append(bb);PP.append(pp)
  if bd is not None:DD.append(bd)
  print('HXV',repeat+1,'seconds',time.time()-t,flush=True)
 np.savez_compressed(out/'energies.npz',A=np.array(AA),B_normalized=np.array(BB),B_physical=np.array(PP),B_direction=np.array(DD) if DD else np.zeros((0,)),patient_id=groups,record_id=z['record_id'][:N])
write_json(out/'definition.json',dict(mode=a.mode,scheme=a.scheme,kind=a.kind,N=N,repeats=args.repeats,K=args.K,voltage_boundary='physical nominal volts before preprocessing; before 500-to-100-Hz filtering for interference',amplitude_unit='V',directions=args.draws if dirs is not None else 'isotropic 100-Hz input covariance',fixed_scales_V=z['fixed_lead_V'].tolist(),global_scale_V=float(z['fixed_global_V']),probe_scheme='unit-sphere Gaussian output directions, factor 128; independent repeat streams',input_gradient='through centering and scale estimation, or frozen training-set scale',postfilter_rms=float(np.sqrt(np.mean(atten))) if atten else None))
# Reuse the tested matching and crossed-bootstrap algorithm with this explicit measurement boundary.
joint_mc.load_case=lambda unused:(f,v,groups,out)
if dirs is not None:joint_mc.noise=lambda shape,kind,seed,device:dirs[seed-args.seed-200000].to(device)
else:
 from common import noise
 joint_mc.noise=lambda shape,kind,seed,device:noise(shape,'white',seed,device)
joint_mc.run(args)
