"""Four workers on two GPUs; additive evidence directories only."""
import os,sys,time,json,threading,queue,subprocess
from pathlib import Path
r=Path('/root/autodl-tmp/Paper20_TIM_revision');out=r/'supplement_round2';status={};lock=threading.Lock();q=queue.Queue()
jobs=[(f'nonflat_{k}',['--mode','interference','--kind',k,'--reference',str(out/'interference_nonflat_input.npz'),'--n','125']) for k in ['white500','power50','power60','morph_local']]
for j in jobs:q.put(j)
(out/'nonflat_matrix.json').write_text(json.dumps(jobs,indent=2))
def save():
 p=out/'nonflat_status.tmp';p.write_text(json.dumps(status,indent=2));p.replace(out/'nonflat_status.json')
def worker(gpu):
 while True:
  try:name,opts=q.get_nowait()
  except queue.Empty:return
  cmd=[sys.executable,'-u',str(r/'revision/physical_eval.py'),'--repo',str(r),'--out',str(out/name)]+opts
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
  with lock:status[name]=dict(state='running',gpu=gpu,command=cmd,start=time.time());save()
  with (out/'logs'/f'{name}.log').open('w') as f:code=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  with lock:status[name].update(state='complete' if code==0 else 'failed',exitcode=code,end=time.time());save()
  q.task_done()
threads=[threading.Thread(target=worker,args=(g,)) for g in [0,1,0,1]]
for t in threads:t.start()
for t in threads:t.join()
