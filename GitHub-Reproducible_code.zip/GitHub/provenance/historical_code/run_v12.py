"""
V12 runner: addresses TIM reviewer requirements.

* R=30 communication rounds, 3 seeds, GPU pre-load + AMP for speed
* Paired-device evaluation protocol -> proper ICC/Cohen-kappa/Bland-Altman
* Multi-seed ablation and privacy sweep
* All artefacts to /root/autodl-tmp/Paper48_v12/results/
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch
import torch.nn.functional as F

from data_real import (load_ptbxl, load_chapman, build_nodes, patient_split,
                       class_prior, SUPERCLASSES, N_CLASSES)
from models import ECGEncoder, ProjHead, ClsHead
from fed_algos import (FederatedTrainer, local_ssl)
from metrics import cls_metrics
from paired_eval import (paired_predictions, paired_consistency_metrics,
                          DEVICE_CHAINS)


# ---------------------------------------------------------------------------
@torch.no_grad()
def embed_gpu(enc, X, device, bs=512):
    enc.eval()
    out = []
    for i in range(0, len(X), bs):
        x = torch.from_numpy(X[i:i + bs].astype(np.float32)).to(device)
        x = (x - x.mean(-1, keepdim=True)) / (x.std(-1, keepdim=True) + 1e-6)
        z = enc(x).cpu().numpy()
        out.append(z)
    return np.concatenate(out)


def train_linear_probe(Ztr, ytr, K=5, device="cuda", epochs=40, lr=1e-2):
    clf = ClsHead(Ztr.shape[1], K).to(device)
    opt = torch.optim.AdamW(clf.parameters(), lr=lr, weight_decay=1e-3)
    Ztr_t = torch.from_numpy(Ztr).float().to(device)
    ytr_t = torch.from_numpy(ytr).long().to(device)
    bs = 256
    for _ in range(epochs):
        idx = torch.randperm(len(Ztr_t))
        for i in range(0, len(Ztr_t), bs):
            sel = idx[i:i + bs]
            loss = F.cross_entropy(clf(Ztr_t[sel]), ytr_t[sel])
            opt.zero_grad(); loss.backward(); opt.step()
    return clf


# ---------------------------------------------------------------------------
def make_node_gpu_loaders(nodes_split, batch=1024, device="cuda"):
    loaders = {}; priors = []; sizes = []; sqi_means = []
    for nk, sp in nodes_split.items():
        X = torch.from_numpy(sp["Xtr"].astype(np.float32)).to(device)
        X._batch = batch
        loaders[nk] = X
        priors.append(class_prior(sp["ytr"]))
        sizes.append(len(sp["ytr"]))
        sqi_means.append(float(np.nanmean(sp.get("sqi_q_tr",
                                                   np.array([1.0])))))
    return loaders, priors, sizes, sqi_means


def split_node(node, seed):
    tr, va, te = patient_split(node, 0.8, 0.1, seed=seed)
    return {
        "Xtr": node["X"][tr], "ytr": node["y"][tr],
        "Xte": node["X"][te], "yte": node["y"][te],
        "sqi_q_tr": node["sqi_q"][tr] if "sqi_q" in node else None,
        "sqi_q_te": node["sqi_q"][te] if "sqi_q" in node else None,
    }


def train_one(algo, nodes_split, args, device, log, **kw):
    """Train one algorithm config and return trained encoder."""
    loaders, priors, sizes, sqi = make_node_gpu_loaders(nodes_split,
                                                          batch=args.batch,
                                                          device=device)
    if algo == "local":
        encs = {}
        for nk, ldr in loaders.items():
            enc = ECGEncoder().to(device); hd = ProjHead().to(device)
            for _ in range(args.rounds):
                local_ssl(enc, hd, ldr, args.local_epochs, args.lr, device)
            encs[nk] = enc
        return encs
    if algo == "centralised":
        X_pool = torch.cat([torch.from_numpy(sp["Xtr"].astype(np.float32))
                             .to(device) for sp in nodes_split.values()])
        X_pool._batch = args.batch
        enc = ECGEncoder().to(device); hd = ProjHead().to(device)
        for _ in range(args.rounds):
            local_ssl(enc, hd, X_pool, args.local_epochs, args.lr, device)
        return enc
    fp_kw = dict(prox_mu=kw.get("prox_mu", 0.01),
                  dp_sigma=kw.get("dp_sigma", 1e-3),
                  damping_gamma=kw.get("damping_gamma", 0.6))
    trainer = FederatedTrainer(lambda: ECGEncoder(), lambda: ProjHead(),
                                loaders, priors, sizes, sqi,
                                algo=algo, rounds=args.rounds,
                                local_epochs=args.local_epochs,
                                lr=args.lr, device=device,
                                fedbn_layers=["bn"], log=log, **fp_kw)
    _, enc, _ = trainer.train()
    return enc


# ---------------------------------------------------------------------------
def evaluate_full(enc_or_dict, nodes_split, device, algo,
                  do_paired=True, log=print):
    """For each method we compute:
       - per-node classification metrics (Acc, F1, AUC, kappa)
       - paired-device consistency (ICC, kappa, BA, CV) on a fixed test set
    """
    # 1. pool training embeddings for one linear probe
    if isinstance(enc_or_dict, dict):
        # local-only: one encoder per node
        per_node = {}; paired = {}
        for nk, sp in nodes_split.items():
            enc = enc_or_dict[nk]
            Ztr = embed_gpu(enc, sp["Xtr"], device)
            Zte = embed_gpu(enc, sp["Xte"], device)
            clf = train_linear_probe(Ztr, sp["ytr"], device=device)
            with torch.no_grad():
                Zte_t = torch.from_numpy(Zte).float().to(device)
                logits = clf(Zte_t)
                proba = torch.softmax(logits, -1).cpu().numpy()
                pred = proba.argmax(-1)
            m = cls_metrics(sp["yte"], pred, proba, N_CLASSES)
            per_node[nk] = {**m, "n_test": int(len(sp["yte"]))}
            if do_paired:
                pred_d, proba_d, y = paired_predictions(
                    enc, clf, sp["Xte"], sp["yte"], device,
                    chains=DEVICE_CHAINS)
                paired[nk] = paired_consistency_metrics(pred_d, proba_d)
        return per_node, paired

    # 2. shared encoder: build one pooled probe
    enc = enc_or_dict
    Xtr_all = np.concatenate([sp["Xtr"] for sp in nodes_split.values()])
    ytr_all = np.concatenate([sp["ytr"] for sp in nodes_split.values()])
    Ztr = embed_gpu(enc, Xtr_all, device)
    clf = train_linear_probe(Ztr, ytr_all, device=device)
    per_node = {}; paired = {}
    for nk, sp in nodes_split.items():
        Zte = embed_gpu(enc, sp["Xte"], device)
        with torch.no_grad():
            Zte_t = torch.from_numpy(Zte).float().to(device)
            logits = clf(Zte_t)
            proba = torch.softmax(logits, -1).cpu().numpy()
            pred = proba.argmax(-1)
        m = cls_metrics(sp["yte"], pred, proba, N_CLASSES)
        per_node[nk] = {**m, "n_test": int(len(sp["yte"]))}
        if do_paired:
            pred_d, proba_d, y = paired_predictions(
                enc, clf, sp["Xte"], sp["yte"], device, chains=DEVICE_CHAINS)
            paired[nk] = paired_consistency_metrics(pred_d, proba_d)
    return per_node, paired


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper48_v12/results")
    ap.add_argument("--rounds", type=int, default=30)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=1024)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seeds", type=int, nargs="+",
                    default=[20260522, 20260523, 20260524])
    ap.add_argument("--max-per-node", type=int, default=4000)
    ap.add_argument("--max-chapman", type=int, default=6000)
    ap.add_argument("--stage", default="all",
                    help="all|main|ablation|privacy")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device, "rounds:", args.rounds, "seeds:", args.seeds)

    p = load_ptbxl(); c = load_chapman()
    nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                         max_per_node=args.max_per_node)
    summary = {"config": vars(args),
                "nodes": {nk: {"source": v["source"], "n": int(len(v["y"])),
                                "prior": class_prior(v["y"]).tolist(),
                                "sqi_mean": float(v["sqi_q"].mean())}
                           for nk, v in nodes.items()},
                "results": {}}

    t0 = time.time()
    if args.stage in ("all", "main"):
        out_main = {}
        for algo in ["local", "fedavg", "fedprox", "scaffold", "fedbn",
                     "centralised", "ours"]:
            out_main[algo] = {"per_seed": [], "paired_per_seed": []}
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                print(f"\n>>> {algo} seed={seed}")
                nodes_split = {nk: split_node(n, seed)
                                for nk, n in nodes.items()}
                enc_or_dict = train_one(algo, nodes_split, args, device, print)
                per_node, paired = evaluate_full(
                    enc_or_dict, nodes_split, device, algo)
                out_main[algo]["per_seed"].append(per_node)
                out_main[algo]["paired_per_seed"].append(paired)
                for nk, m in per_node.items():
                    print(f"  {nk}: acc={m['acc']:.3f} f1={m['f1']:.3f} "
                           f"auc={m['auc']:.3f}")
                if paired:
                    icc = np.mean([paired[nk]["icc_proba_dom"]
                                    for nk in paired])
                    cv  = np.mean([paired[nk]["cv_mean"]
                                    for nk in paired])
                    print(f"  paired: ICC(proba_dom)={icc:.3f}  CV={cv:.3f}")
        summary["results"]["main"] = out_main
        with open(os.path.join(args.out, "results.json"), "w") as f:
            json.dump(summary, f, indent=2)

    if args.stage in ("all", "ablation"):
        abl_out = {}
        variants = [
            ("full",     dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
            ("noWeight", dict(algo="fedavg", prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
            ("noDamp",   dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=1.0)),
            ("noProx",   dict(algo="ours",   prox_mu=0.00, dp_sigma=1e-3, damping_gamma=0.6)),
            ("noDP",     dict(algo="ours",   prox_mu=0.01, dp_sigma=0.00, damping_gamma=0.6)),
        ]
        for vname, kw in variants:
            algo = kw.pop("algo")
            abl_out[vname] = {"per_seed": [], "paired_per_seed": []}
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                print(f"\n>>> ABL {vname} seed={seed}")
                nodes_split = {nk: split_node(n, seed)
                                for nk, n in nodes.items()}
                enc = train_one(algo, nodes_split, args, device, print, **kw)
                per_node, paired = evaluate_full(
                    enc, nodes_split, device, vname)
                abl_out[vname]["per_seed"].append(per_node)
                abl_out[vname]["paired_per_seed"].append(paired)
                kw["algo"] = algo
        summary["results"]["ablation"] = abl_out
        with open(os.path.join(args.out, "results.json"), "w") as f:
            json.dump(summary, f, indent=2)

    if args.stage in ("all", "privacy"):
        pr_out = {}
        for sigma in [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]:
            pr_out[str(sigma)] = {"per_seed": [], "paired_per_seed": []}
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                print(f"\n>>> PRIV sigma={sigma} seed={seed}")
                nodes_split = {nk: split_node(n, seed)
                                for nk, n in nodes.items()}
                enc = train_one("ours", nodes_split, args, device, print,
                                 prox_mu=0.01, dp_sigma=sigma,
                                 damping_gamma=0.6)
                per_node, paired = evaluate_full(
                    enc, nodes_split, device, f"sigma{sigma}")
                pr_out[str(sigma)]["per_seed"].append(per_node)
                pr_out[str(sigma)]["paired_per_seed"].append(paired)
        summary["results"]["privacy"] = pr_out

    with open(os.path.join(args.out, "results.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nTOTAL TIME: {time.time() - t0:.1f}s")
    print(f"saved -> {args.out}/results.json")


if __name__ == "__main__":
    main()
