"""
Paired-device evaluation protocol.

For each held-out test ECG x, we generate K virtual device chains
{d_1, ..., d_K} that mimic different ECG acquisition systems
(sampling rate / lead set / additive sensor noise) and we evaluate
the SAME encoder under EACH device chain. The resulting K paired
predictions per ECG enable methodologically correct computation of:

  - Intraclass Correlation Coefficient ICC(3,1)  (same ECG, K raters)
  - Cohen's kappa                                 (between any two devices)
  - Bland-Altman 95% Limits of Agreement          (per-class probability)
  - Cross-device Coefficient of Variation         (per ECG, across devices)

This is the metrologically valid way to evaluate cross-node measurement
consistency of a representation, as requested by TIM reviewers.

Device chains (calibrated against real ECG acquisition envelope):
  D1: 12-lead, 500-Hz-equivalent, low noise         (diagnostic cart)
  D2: 6-lead , 250-Hz-equivalent, mild noise        (clinic monitor)
  D3: 3-lead , 125-Hz-equivalent, moderate noise    (telemetry)
  D4: 1-lead , 100-Hz-equivalent, heavy noise       (single-lead wearable)
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn.functional as F


# ----------------------------------------------------------------------------
# Device chain definitions
# ----------------------------------------------------------------------------
DEVICE_CHAINS = {
    "D1": {"leads": list(range(12)),       "ds_ratio": 1.0,  "snr_db": 30.0},
    "D2": {"leads": [0,1,2,3,4,5],         "ds_ratio": 0.5,  "snr_db": 20.0},
    "D3": {"leads": [0,1,2],               "ds_ratio": 0.25, "snr_db": 10.0},
    "D4": {"leads": [1],                   "ds_ratio": 0.2,  "snr_db":  0.0},
}


def apply_device(x: torch.Tensor, chain: dict, rng) -> torch.Tensor:
    """Apply one device chain to a (B, 12, T) tensor.
    Returns a (B, 12, T) tensor that has been (a) lead-masked to the chain,
    (b) low-pass / down-sampled to the target rate then up-sampled back
    (so the encoder receives the same T), and (c) corrupted with
    Gaussian noise at the chain's SNR.  Missing leads are zero-padded."""
    B, C, T = x.shape
    out = torch.zeros_like(x)
    # lead mask
    keep = sorted(chain["leads"])
    sub = x[:, keep, :]                           # (B, C', T)

    # down-sample + up-sample (linear) to mimic anti-alias + ADC
    r = float(chain["ds_ratio"])
    if r < 1.0:
        Tn = max(64, int(T * r))
        idx_down = torch.linspace(0, T - 1, Tn, device=x.device).long()
        sub_d = sub.index_select(-1, idx_down)
        idx_up = torch.linspace(0, Tn - 1, T, device=x.device).long()
        sub = sub_d.index_select(-1, idx_up)

    # noise at controlled SNR (per-channel, per-sample variance match)
    sig_pow = (sub.float() ** 2).mean(dim=-1, keepdim=True) + 1e-8
    noise_pow = sig_pow / (10 ** (chain["snr_db"] / 10.0))
    noise = torch.randn_like(sub) * noise_pow.sqrt()
    sub = sub + noise

    # zero-pad back to 12 leads at the original positions
    for i, l in enumerate(keep):
        out[:, l, :] = sub[:, i, :]
    return out


@torch.no_grad()
def encode_under_device(enc, x_batch, chain, device):
    enc.eval()
    x = x_batch.to(device, non_blocking=True)
    # per-batch normalisation BEFORE device perturbation,
    # mimicking on-site preprocessing (clinical convention)
    x = (x - x.mean(-1, keepdim=True)) / (x.std(-1, keepdim=True) + 1e-6)
    rng = np.random.default_rng(0)
    xd = apply_device(x, chain, rng)
    z = enc(xd)
    return z


@torch.no_grad()
def predict_under_device(enc, clf, x_batch, chain, device):
    z = encode_under_device(enc, x_batch, chain, device)
    logits = clf(z)
    proba = F.softmax(logits, dim=-1).cpu().numpy()
    pred = proba.argmax(axis=1)
    return pred, proba


@torch.no_grad()
def paired_predictions(enc, clf, X, y, device, batch=256,
                        chains=DEVICE_CHAINS):
    """Return, for every test ECG and every device chain, the predicted
    class and the class-probability vector.

    Returns:
      pred_per_dev: dict {chain_id: (N,)}  predicted class index
      proba_per_dev: dict {chain_id: (N, K)} softmax probabilities
      y: (N,) the ground-truth class
    """
    N = len(X)
    out_pred  = {c: np.zeros(N, dtype=np.int64) for c in chains}
    out_proba = None
    for s in range(0, N, batch):
        e = min(s + batch, N)
        x_t = torch.from_numpy(X[s:e].astype(np.float32))
        for cid, ch in chains.items():
            pred, proba = predict_under_device(enc, clf, x_t, ch, device)
            out_pred[cid][s:e] = pred
            if out_proba is None:
                K = proba.shape[1]
                out_proba = {c: np.zeros((N, K), dtype=np.float32) for c in chains}
            out_proba[cid][s:e] = proba
    return out_pred, out_proba, y


# ----------------------------------------------------------------------------
# Metrology metrics on paired data
# ----------------------------------------------------------------------------
def icc_3_1(M):
    """Two-way mixed effects, absolute agreement, single rater.
    M: (n_subjects, n_raters) numeric. Returns scalar ICC(3,1)."""
    M = np.asarray(M, dtype=np.float64)
    n, k = M.shape
    if n < 2 or k < 2: return float("nan")
    grand = M.mean()
    SSR = k * ((M.mean(1) - grand) ** 2).sum()
    SSC = n * ((M.mean(0) - grand) ** 2).sum()
    SST = ((M - grand) ** 2).sum()
    SSE = max(SST - SSR - SSC, 1e-12)
    MSR = SSR / (n - 1)
    MSE = SSE / ((n - 1) * (k - 1))
    MSC = SSC / (k - 1)
    denom = MSR + (k - 1) * MSE + k * (MSC - MSE) / n
    if denom <= 0: return float("nan")
    return float((MSR - MSE) / denom)


def cohen_kappa(a, b):
    from sklearn.metrics import cohen_kappa_score
    try:
        return float(cohen_kappa_score(a, b))
    except Exception:
        return float("nan")


def bland_altman(a, b):
    """Returns dict with mean bias, SD of differences, and 95% LoA."""
    a = np.asarray(a, dtype=np.float64); b = np.asarray(b, dtype=np.float64)
    d = a - b
    bias = float(d.mean()); sd = float(d.std(ddof=1)) if len(d) > 1 else 0.0
    return {"bias": bias, "sd": sd,
            "loa_lo": bias - 1.96 * sd, "loa_hi": bias + 1.96 * sd}


def cv_across_devices(proba_per_dev, class_idx=None):
    """For each subject, compute coefficient of variation of the
    predicted probability of its argmax class across devices.
    Returns per-subject CV array and the mean CV."""
    devs = list(proba_per_dev.keys())
    P = np.stack([proba_per_dev[d] for d in devs])     # (K, N, C)
    if class_idx is None:
        class_idx = P.mean(0).argmax(-1)
    N = P.shape[1]
    cv = np.zeros(N)
    for i in range(N):
        vals = P[:, i, class_idx[i]]
        m = vals.mean()
        cv[i] = vals.std(ddof=1) / max(abs(m), 1e-6) if len(vals) > 1 else 0
    return cv, float(cv.mean())


def paired_consistency_metrics(pred_per_dev, proba_per_dev):
    """Aggregate all metrology metrics from paired predictions.

    Returns nested dict with:
      icc_argmax    : ICC(3,1) of predicted-class index across K devices
      icc_proba_dom : ICC(3,1) of dominant-class probability across K devices
      kappa_pairs   : Cohen kappa between every pair of devices
      ba_pairs      : Bland-Altman {bias, sd, loa} between every pair on dom-prob
      cv_mean       : mean per-subject CV of dom-prob
    """
    devs = sorted(pred_per_dev.keys())
    K = len(devs); N = len(pred_per_dev[devs[0]])
    pred_M = np.stack([pred_per_dev[d] for d in devs], axis=1)   # (N, K)
    proba = np.stack([proba_per_dev[d] for d in devs], axis=0)   # (K, N, C)
    dom = proba.mean(0).argmax(-1)
    proba_dom = np.stack([proba[k, np.arange(N), dom] for k in range(K)],
                          axis=1)                                  # (N, K)

    out = {}
    out["icc_argmax"] = icc_3_1(pred_M.astype(np.float64))
    out["icc_proba_dom"] = icc_3_1(proba_dom)
    out["kappa_pairs"] = {f"{devs[i]}-{devs[j]}":
                          cohen_kappa(pred_per_dev[devs[i]],
                                      pred_per_dev[devs[j]])
                          for i in range(K) for j in range(i + 1, K)}
    out["ba_pairs"] = {f"{devs[i]}-{devs[j]}":
                       bland_altman(proba_dom[:, i], proba_dom[:, j])
                       for i in range(K) for j in range(i + 1, K)}
    cv_arr, cv_mean = cv_across_devices(proba_per_dev, dom)
    out["cv_mean"] = cv_mean
    return out
