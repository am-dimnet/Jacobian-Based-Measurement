"""V23: Hutchinson-based R across all 4 architectures + the trained
ours-encoder, on both datasets, with 3 random initialisations each.

Provides a single CLEAN table of R per (architecture, dataset, seed)
with no s_small probe artefact.
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch

from data_real import load_ptbxl, load_chapman
from multi_encoder_sigma_map import ENCODERS
from models import ECGEncoder
from hutchinson_R import hutchinson_F2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper20_TIM/results/hutchinson_multi.json")
    ap.add_argument("--n-batch", type=int, default=32)
    ap.add_argument("--K", type=int, default=8)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--trained-ckpt",
                    default="/root/autodl-tmp/Paper20_TIM/results/ckpts/ours_s20260601.pt")
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load data
    p = load_ptbxl(); X_p = p["X"][:args.n_batch].astype(np.float32)
    c = load_chapman(); X_c = c["X"][:args.n_batch].astype(np.float32)
    Xt_p = torch.from_numpy(X_p).to(device); Xt_p = (Xt_p - Xt_p.mean(-1, keepdim=True)) / (Xt_p.std(-1, keepdim=True) + 1e-6)
    Xt_c = torch.from_numpy(X_c).to(device); Xt_c = (Xt_c - Xt_c.mean(-1, keepdim=True)) / (Xt_c.std(-1, keepdim=True) + 1e-6)

    summary = {"config": vars(args), "encoders": {}}

    for arch_name, EncCls in ENCODERS.items():
        summary["encoders"][arch_name] = {}
        for ds_name, Xt in [("ptbxl", Xt_p), ("chapman", Xt_c)]:
            entries = []
            for seed in args.seeds:
                torch.manual_seed(seed)
                enc = EncCls(in_ch=12).to(device).eval()
                t0 = time.time()
                F2_th = hutchinson_F2(enc, Xt, target="theta", K=args.K)
                F2_x  = hutchinson_F2(enc, Xt, target="x",     K=args.K)
                R = float(np.sqrt(F2_th / max(F2_x, 1e-12)))
                entries.append({"seed": seed, "F2_theta": F2_th,
                                 "F2_x": F2_x, "R": R})
                print(f"{arch_name:14s} {ds_name:8s} seed={seed} R={R:.2f} "
                      f"({time.time()-t0:.0f}s)", flush=True)
            summary["encoders"][arch_name][ds_name] = entries
        with open(args.out, "w") as f:
            json.dump(summary, f, indent=2)

    # also the trained ours-encoder
    summary["encoders"]["ours_trained"] = {}
    for ds_name, Xt in [("ptbxl", Xt_p), ("chapman", Xt_c)]:
        enc = ECGEncoder().to(device).eval()
        enc.load_state_dict(torch.load(args.trained_ckpt, map_location=device), strict=False)
        F2_th = hutchinson_F2(enc, Xt, target="theta", K=args.K)
        F2_x  = hutchinson_F2(enc, Xt, target="x",     K=args.K)
        R = float(np.sqrt(F2_th / max(F2_x, 1e-12)))
        summary["encoders"]["ours_trained"][ds_name] = [
            {"seed": 0, "F2_theta": F2_th, "F2_x": F2_x, "R": R}
        ]
        print(f"ours_trained   {ds_name:8s} R={R:.2f}", flush=True)

    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)
    print("saved", args.out)


if __name__ == "__main__":
    main()
