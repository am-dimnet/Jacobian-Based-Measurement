"""
Real ECG data loader: PTB-XL site partition + Chapman-Shaoxing as the four
acquisition nodes of the distributed measurement federation.

- PTB-XL is loaded from /root/autodl-tmp/Dataset/Dataset1/ptbxl_proc.npz
  (preprocessed: X=(N,12,1000) float16, y int SCP-code index, patient,
   fold, site, device, age, sex, bmi, hrv, spec, ecg_id) + SQI from
   ptbxl_sqi.npz (feats 6-d + scalar q).
- Chapman from chapman_proc.npz + chapman_sqi.npz.

Labels are mapped to PTB-XL 5 diagnostic superclasses
  {NORM, MI, STTC, CD, HYP}
via scp_statements.csv (PTB-XL) and a documented Chapman-condition mapping
(see CHAPMAN_TO_SUPER below). Records that map to none are excluded.
Patient-level splits are honoured on PTB-XL; Chapman has no patient_id
in the preprocessed cache so a record-level stratified split is used and
the limitation is reported.
"""
from __future__ import annotations
import os
import json
import csv
import numpy as np

DATA_ROOT = "/root/autodl-tmp/Dataset"
PTBXL_DIR = os.path.join(DATA_ROOT, "Dataset1")
META_DIR  = os.path.join(DATA_ROOT, "meta")

SUPERCLASSES = ["NORM", "MI", "STTC", "CD", "HYP"]
N_CLASSES = 5

# ---------------------------------------------------------------------------
# Chapman acronym -> PTB-XL superclass mapping.
# Built from chapman_condition_names.csv combined with the standard
# Chapman/Shaoxing diagnostic taxonomy. Records whose only labels are
# "other / sinus-only / non-mappable" are placed under NORM if SR-related,
# otherwise excluded (None).
# ---------------------------------------------------------------------------
CHAPMAN_TO_SUPER = {
    # ----- Normal sinus family -> NORM ---------------------------------
    "SR": "NORM", "SB": "NORM", "ST": "NORM", "SA": "NORM",
    "ERV": "NORM",  # early repolarisation variant (usually benign)
    # ----- Conduction disturbance (CD) ---------------------------------
    "1AVB": "CD", "2AVB": "CD", "2AVB1": "CD", "2AVB2": "CD", "3AVB": "CD",
    "AVB": "CD", "IVB": "CD",
    "LBBB": "CD", "RBBB": "CD", "ILBBB": "CD", "IRBBB": "CD",
    "LFBBB": "CD", "LAFB": "CD", "RAFB": "CD",
    "ALS": "CD", "ARS": "CD",  # axis shifts
    "WPW": "CD", "AVRT": "CD", "AVNRT": "CD",
    "CCR": "CD", "CR": "CD",
    # ----- Hypertrophy (HYP) -------------------------------------------
    "LVH": "HYP", "RVH": "HYP", "LVQRSAL": "HYP", "LVQRSCL": "HYP",
    "LAE": "HYP", "RAE": "HYP",
    # ----- Myocardial infarction (MI) ----------------------------------
    "AQW": "MI", "MI": "MI", "AMI": "MI", "ALMI": "MI", "IMI": "MI",
    "ASMI": "MI", "ILMI": "MI", "INJ": "MI", "IPMI": "MI", "IPLMI": "MI",
    # ----- ST-T changes (STTC) -----------------------------------------
    "STD": "STTC", "STE": "STTC", "STDD": "STTC", "STTC": "STTC",
    "TWO": "STTC", "TWC": "STTC", "TIN": "STTC", "MISW": "STTC",
    "QTIE": "STTC", "PRIE": "STTC", "PWC": "STTC", "FQRS": "STTC",
    "ABI": "STTC",  # atrial bigeminy presents with abnormal P-T pattern
    # ----- Atrial arrhythmias often dominate ST-T -> STTC --------------
    "AF": "STTC", "AFIB": "STTC", "AFLT": "STTC", "AT": "STTC",
    "APB": "STTC", "PVC": "STTC", "VPB": "STTC", "JPT": "STTC",
    "JEB": "STTC", "LFPR": "STTC", "VFL": "STTC", "VT": "STTC",
}


def _load_npz(path):
    return np.load(path, allow_pickle=True)


def _build_ptbxl_scp_to_super():
    """Read scp_statements.csv and build SCP code -> superclass map."""
    p = os.path.join(META_DIR, "scp_statements.csv")
    code_to_super = {}
    with open(p) as f:
        rdr = csv.reader(f)
        header = next(rdr)
        # 'diagnostic_class' is column index 5
        DC = header.index("diagnostic_class")
        for row in rdr:
            if not row:
                continue
            code = row[0].strip()
            dc = row[DC].strip() if DC < len(row) else ""
            if dc in SUPERCLASSES:
                code_to_super[code] = dc
    return code_to_super


def _ptbxl_label_to_super(y_idx_arr, scp_names, scp_to_super):
    """Map each PTB-XL record's y to a 5-superclass index.
    If names already equal SUPERCLASSES (preprocess wrote superclass ids
    directly), y is already in [0,5) and we just pass it through."""
    if list(scp_names) == list(SUPERCLASSES):
        y = np.asarray(y_idx_arr, dtype=np.int64)
        out = np.where((y >= 0) & (y < N_CLASSES), y, -1)
        return out.astype(np.int64)
    out = np.full(len(y_idx_arr), -1, dtype=np.int64)
    for i, yi in enumerate(y_idx_arr):
        if 0 <= yi < len(scp_names):
            code = scp_names[int(yi)]
            sc = scp_to_super.get(code)
            if sc is not None:
                out[i] = SUPERCLASSES.index(sc)
    return out


def _chapman_label_to_super(y_idx_arr, ch_names):
    if list(ch_names) == list(SUPERCLASSES):
        y = np.asarray(y_idx_arr, dtype=np.int64)
        out = np.where((y >= 0) & (y < N_CLASSES), y, -1)
        return out.astype(np.int64)
    out = np.full(len(y_idx_arr), -1, dtype=np.int64)
    for i, yi in enumerate(y_idx_arr):
        if 0 <= yi < len(ch_names):
            code = ch_names[int(yi)]
            sc = CHAPMAN_TO_SUPER.get(code)
            if sc is not None:
                out[i] = SUPERCLASSES.index(sc)
    return out


# ---------------------------------------------------------------------------
def load_ptbxl():
    proc = _load_npz(os.path.join(PTBXL_DIR, "ptbxl_proc.npz"))
    sqi  = _load_npz(os.path.join(PTBXL_DIR, "ptbxl_sqi.npz"))
    with open(os.path.join(PTBXL_DIR, "ptbxl_labels.json")) as f:
        names = json.load(f)["names"]
    scp_to_super = _build_ptbxl_scp_to_super()
    y_super = _ptbxl_label_to_super(proc["y"], names, scp_to_super)
    keep = y_super >= 0
    N = int(keep.sum())
    def _get(name, default=None):
        try:
            return proc[name][keep]
        except (KeyError, ValueError):
            if default is None:
                default = np.zeros(N, dtype=np.float32)
            return default
    return {
        "X": proc["X"][keep],          # (N,12,1000) float16
        "y": y_super[keep],            # superclass id
        "patient": _get("patient"),
        "fold": _get("fold"),
        "site": _get("site"),
        "device": _get("device", np.full(N, "unknown", dtype=object)),
        "age": _get("age"),
        "sex": _get("sex"),
        "sqi_q": sqi["q"][keep],
        "sqi_feats": sqi["feats"][keep],
        "ecg_id": _get("ecg_id"),
        "name": "PTB-XL",
    }


def load_chapman():
    proc = _load_npz(os.path.join(PTBXL_DIR, "chapman_proc.npz"))
    sqi  = _load_npz(os.path.join(PTBXL_DIR, "chapman_sqi.npz"))
    with open(os.path.join(PTBXL_DIR, "chapman_labels.json")) as f:
        names = json.load(f)["names"]
    y_super = _chapman_label_to_super(proc["y"], names)
    keep = y_super >= 0
    N = int(keep.sum())
    # synthetic patient: use record index (one record == one "patient" surrogate)
    return {
        "X": proc["X"][keep],
        "y": y_super[keep],
        "patient": np.arange(N, dtype=np.int64),
        "fold": np.full(N, -1, dtype=np.int64),  # no native fold
        "sqi_q": sqi["q"][keep],
        "sqi_feats": sqi["feats"][keep],
        "name": "Chapman-Shaoxing",
    }


# ---------------------------------------------------------------------------
# 4-node federation
# ---------------------------------------------------------------------------
def build_nodes(ptbxl: dict, chapman: dict, max_chapman_n: int = 12000,
                max_per_node: int = 0, seed: int = 0):
    """N1=PTBXL site 0, N2=site 1, N3=site 2, N4=Chapman (subsampled).
    If max_per_node>0, every node is randomly subsampled to that size."""
    rng = np.random.default_rng(seed)
    nodes = {}
    for name, target_site in [("N1", 0.0), ("N2", 1.0), ("N3", 2.0)]:
        m = np.isclose(ptbxl["site"], target_site)
        nodes[name] = {k: (v[m] if isinstance(v, np.ndarray) and len(v) == len(m) else v)
                       for k, v in ptbxl.items()}
        nodes[name]["source"] = "PTB-XL"

    nch = len(chapman["X"])
    keep_idx = rng.permutation(nch)[:min(nch, max_chapman_n)]
    nodes["N4"] = {k: (v[keep_idx] if isinstance(v, np.ndarray) and len(v) == nch else v)
                   for k, v in chapman.items()}
    nodes["N4"]["source"] = "Chapman-Shaoxing"

    if max_per_node > 0:
        for nk in list(nodes.keys()):
            n_here = len(nodes[nk]["X"])
            if n_here > max_per_node:
                idx = np.random.default_rng(seed * 1000 + hash(nk) % 100).permutation(n_here)[:max_per_node]
                for f in list(nodes[nk].keys()):
                    v = nodes[nk][f]
                    if isinstance(v, np.ndarray) and len(v) == n_here:
                        nodes[nk][f] = v[idx]
    return nodes


def patient_split(node: dict, train_frac=0.8, val_frac=0.1, seed=0):
    """Patient-disjoint train/val/test split."""
    pid = node["patient"]
    upid = np.unique(pid)
    rng = np.random.default_rng(seed)
    rng.shuffle(upid)
    n = len(upid)
    n_tr = int(n * train_frac); n_va = int(n * val_frac)
    tr_p, va_p, te_p = upid[:n_tr], upid[n_tr:n_tr + n_va], upid[n_tr + n_va:]
    tr = np.isin(pid, tr_p); va = np.isin(pid, va_p); te = np.isin(pid, te_p)
    return tr, va, te


def class_prior(y):
    counts = np.bincount(y, minlength=N_CLASSES).astype(np.float64)
    return counts / max(counts.sum(), 1)


def class_entropy(p):
    p = np.asarray(p) + 1e-12
    return float(-(p * np.log(p)).sum() / np.log(N_CLASSES))


if __name__ == "__main__":
    p = load_ptbxl(); c = load_chapman()
    print(f"PTB-XL kept {len(p['y'])}/{len(p['y'])} records, class dist:",
          np.bincount(p['y'], minlength=5))
    print(f"Chapman kept {len(c['y'])} records, class dist:",
          np.bincount(c['y'], minlength=5))
    nodes = build_nodes(p, c)
    for k, v in nodes.items():
        prior = class_prior(v["y"])
        print(f"  {k} ({v['source']}) n={len(v['y'])} prior={prior.round(3)}  "
              f"entropy={class_entropy(prior):.3f}  "
              f"SQI mean={v['sqi_q'].mean():.3f}")
