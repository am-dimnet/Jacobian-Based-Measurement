"""V20: regenerate paper tables and figures from results_v20.json with
5-seed numbers + per-record predictions for real Bland-Altman.

Outputs:
  figures/tab1_main_f1.tex (per-node Acc/F1/AUC, 5 seeds, no post-hoc row)
  figures/tab2_v12_paired.tex (ICC/kappa/CV with 5 seeds and 95% CI)
  figures/fig4_main_results.pdf
  figures/fig7_main_results.pdf
  figures/fig9_ablation.pdf
  figures/fig10_paired_consistency.pdf (REAL Bland-Altman scatter)
  figures/fig11_privacy_v12.pdf
"""
from __future__ import annotations
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
NODES = ["N1","N2","N3","N4"]
METHODS = ["local","fedavg","fedprox","scaffold","fedbn","centralised","ours"]
LABEL = {"local": "Local-only", "fedavg":"FedAvg", "fedprox":"FedProx",
         "scaffold":"SCAFFOLD", "fedbn":"FedBN",
         "centralised":"Centralised$^\\dagger$ (raw-pool)",
         "ours":"\\method ($\\sigma{=}10^{-3}$)"}


def _agg(stages, key):
    vals = []
    for s in stages:
        for n in NODES:
            if n in s and key in s[n]:
                v = s[n][key]
                if isinstance(v,(int,float)) and not np.isnan(v):
                    vals.append(v)
    if not vals: return float("nan"), float("nan")
    return float(np.mean(vals)), float(np.std(vals, ddof=1) if len(vals)>1 else 0)


def _node_agg(stages, n, key):
    vals = [s[n][key] for s in stages if n in s
            and not np.isnan(s[n].get(key, float("nan")))]
    if not vals: return float("nan"), float("nan")
    return float(np.mean(vals)), float(np.std(vals, ddof=1) if len(vals)>1 else 0)


# ---------------------------------------------------------------------------
def table1_main(R, out_path):
    main = R["results"]["main"]
    lines = []
    lines.append(r"\resizebox{\textwidth}{!}{%")
    lines.append(r"\begin{tabular}{l" + "ccc"*5 + "}")
    lines.append(r"\toprule")
    lines.append(r"Method & " + " & ".join(f"\\multicolumn{{3}}{{c}}{{{n}}}" for n in NODES)
                  + r" & \multicolumn{3}{c}{Federation avg} \\")
    lines.append(" ".join(f"\\cmidrule(lr){{{2+3*i}-{4+3*i}}}" for i in range(5)))
    lines.append(" & " + " & ".join(["Acc & F1 & AUC"]*5) + r" \\")
    lines.append(r"\midrule")
    for m in METHODS:
        if m not in main: continue
        cells = []; accs, f1s, aucs = [], [], []
        for n in NODES:
            a_m, _ = _node_agg(main[m]["per_seed"], n, "acc")
            f_m, _ = _node_agg(main[m]["per_seed"], n, "f1")
            u_m, _ = _node_agg(main[m]["per_seed"], n, "auc")
            def _fmt(x):
                return "--" if (x is None or (isinstance(x, float) and np.isnan(x))) else f"{x:.3f}"
            cells.extend([_fmt(a_m), _fmt(f_m), _fmt(u_m)])
            accs.append(a_m); f1s.append(f_m); aucs.append(u_m)
        cells.extend([f"{np.nanmean(accs):.3f}", f"{np.nanmean(f1s):.3f}",
                      f"{np.nanmean(aucs):.3f}"])
        lines.append(LABEL[m] + " & " + " & ".join(cells) + r" \\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}}")
    lines.append(r"% Notes: mean over 5 random seeds; $\dagger$ centralised requires raw-data pooling and is not admissible in the federated regime studied here.")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    print(f"wrote {out_path}")


def table2_paired(R, out_path):
    main = R["results"]["main"]
    lines = []
    lines.append(r"\begin{tabular}{lcccc}")
    lines.append(r"\toprule")
    lines.append(r"Method & ICC$_{(3,1)}$ $\uparrow$ "
                  r"& Cohen $\kappa$ D1--D2 $\uparrow$ "
                  r"& Inter-device CV $\downarrow$ "
                  r"& BA bias D1--D4 \\")
    lines.append(r"\midrule")
    for m in METHODS:
        if m not in main: continue
        ps = main[m].get("paired_per_seed", [])
        if not ps: continue
        icc_m, icc_s = _agg(ps, "icc_proba_dom")
        cv_m, _ = _agg(ps, "cv_mean")
        kpv, bavals = [], []
        for s in ps:
            for n in NODES:
                if n in s and "kappa_pairs" in s[n]:
                    v = s[n]["kappa_pairs"].get("D1-D2", float("nan"))
                    if not np.isnan(v): kpv.append(v)
                if n in s and "ba_pairs" in s[n]:
                    d = s[n]["ba_pairs"].get("D1-D4", {})
                    if d: bavals.append(d["bias"])
        kp = np.mean(kpv) if kpv else float("nan")
        ba = np.mean(bavals) if bavals else float("nan")
        lines.append(f"{LABEL[m]} & {icc_m:+.3f}$\\pm${icc_s:.3f} "
                      f"& {kp:+.3f} & {cv_m:.3f} & {ba:+.3f} \\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"% Mean over 5 seeds; all numbers from the 5-seed pre-defined operating point ($\sigma{=}10^{-3}$).")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    print(f"wrote {out_path}")


def _save(fig, name):
    for ext in ("pdf","png"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig4_main(R):
    main = R["results"]["main"]
    fig, ax = plt.subplots(figsize=(8.5, 3.6))
    width = 0.11
    x = np.arange(len(NODES))
    colors = ["#4c72b0","#dd8452","#55a467","#c44e52",
              "#8172b3","#937860","#da8bc3"]
    for i, m in enumerate(METHODS):
        if m not in main: continue
        means, sds = [], []
        for n in NODES:
            mu, sd = _node_agg(main[m]["per_seed"], n, "f1")
            means.append(mu); sds.append(sd)
        ax.bar(x + i*width - 3*width, means, width=width, yerr=sds,
               label=LABEL[m].replace("$^\\dagger$","").replace("\\method","ours"),
               capsize=2, color=colors[i % len(colors)])
    ax.set_xticks(x); ax.set_xticklabels(NODES)
    ax.set_ylabel("Macro-F1")
    ax.set_title("Per-node macro-F1 (5 seeds, mean$\\pm$1 SD)")
    ax.legend(fontsize=7, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.12))
    ax.grid(axis="y", alpha=0.3)
    _save(fig, "fig4_main_results")


def fig7_paired(R, preds_dir):
    """Real Bland-Altman scatter using per-record proba for D1 vs D4."""
    main = R["results"]["main"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    # left: ICC per method (5 seeds, mean+/-SD)
    icc_means, icc_sds, names = [], [], []
    for m in METHODS:
        if m not in main: continue
        ps = main[m].get("paired_per_seed", [])
        icc_m, icc_s = _agg(ps, "icc_proba_dom")
        icc_means.append(icc_m); icc_sds.append(icc_s)
        names.append(LABEL[m].replace("$^\\dagger$","").replace("\\method","ours"))
    x = np.arange(len(names))
    axes[0].bar(x, icc_means, yerr=icc_sds, capsize=3, color="#4c72b0")
    axes[0].axhline(0.75, color="red", ls="--", lw=0.8, label="ICC=0.75 guide")
    axes[0].axhline(0.0, color="black", lw=0.6)
    axes[0].set_xticks(x); axes[0].set_xticklabels(names, rotation=25, ha="right", fontsize=8)
    axes[0].set_ylabel("ICC$_{(3,1)}$"); axes[0].set_ylim(-0.4, 1.0)
    axes[0].set_title("Paired-acquisition ICC (5 seeds, mean$\\pm$1 SD)")
    axes[0].legend(fontsize=7); axes[0].grid(axis="y", alpha=0.3)
    # right: REAL Bland-Altman scatter D1 vs D4 for ours and FedAvg seed 0
    seed0 = 20260601
    d_y_all = {"ours": [], "fedavg": []}
    for m_key in ("ours", "fedavg"):
        for n in NODES:
            p = os.path.join(preds_dir, f"main/{m_key}/seed{seed0}/{n}.npz")
            if not os.path.exists(p): continue
            d = np.load(p)
            d1 = d["proba_D1"]; d4 = d["proba_D4"]
            dom = (d1.mean(0).argmax()) if d1.ndim==2 and d1.shape[0]>0 else 0
            # use record-mean dom-class
            dom = d1.argmax(axis=1) if d1.ndim==2 else np.zeros(d1.shape[0], dtype=int)
            for i in range(d1.shape[0]):
                d_y_all[m_key].append((float(d1[i, dom[i]]),
                                       float(d4[i, dom[i]])))
    for m_key, color, marker in (("fedavg", "#888888", "o"),
                                  ("ours", "#c44e52", "x")):
        arr = np.array(d_y_all[m_key])
        if len(arr) == 0: continue
        a = arr[:, 0]; b = arr[:, 1]
        means = (a+b)/2; diffs = a-b
        bias = diffs.mean(); sd = diffs.std(ddof=1) if len(diffs)>1 else 0
        axes[1].scatter(means, diffs, alpha=0.25, s=8, color=color,
                        marker=marker, label=f"{m_key} (bias={bias:+.3f}, $\\pm$1.96SD$=\\pm${1.96*sd:.3f})")
        axes[1].axhline(bias, color=color, ls="-", lw=0.8)
        axes[1].axhline(bias+1.96*sd, color=color, ls=":", lw=0.5)
        axes[1].axhline(bias-1.96*sd, color=color, ls=":", lw=0.5)
    axes[1].set_xlabel("Mean dom-class proba (D1, D4)")
    axes[1].set_ylabel("Diff D1 - D4")
    axes[1].set_title("Bland--Altman: D1 vs D4 (seed 0, all 4 nodes pooled)")
    axes[1].legend(fontsize=7); axes[1].grid(alpha=0.3)
    plt.tight_layout()
    _save(fig, "fig10_paired_consistency")


def fig9_ablation(R):
    """Ablation panel for BOTH sigma=1e-3 and sigma=1e-2."""
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4), sharey=True)
    for ax, sig_tag in zip(axes, ("1e-3", "1e-2")):
        key = f"ablation_{sig_tag}"
        if key not in R["results"]:
            ax.text(0.5, 0.5, f"ablation_{sig_tag}\n(not run)",
                    transform=ax.transAxes, ha="center", va="center")
            continue
        abl = R["results"][key]
        labels = list(abl.keys())
        means, sds = [], []
        for v in labels:
            f1s = []
            for s in abl[v]["per_seed"]:
                for n in NODES:
                    if n in s and "f1" in s[n] and not np.isnan(s[n]["f1"]):
                        f1s.append(s[n]["f1"])
            means.append(np.mean(f1s) if f1s else float("nan"))
            sds.append(np.std(f1s, ddof=1) if len(f1s) > 1 else 0)
        n_seeds_here = len(abl[labels[0]]["per_seed"]) if labels else 0
        pretty = {"full":"full","noWeight":"w/o quality\nweight",
                  "noDamp":"w/o early-layer\ndamping","noDP":"w/o aggregate\nperturbation",
                  "noProx":"w/o proximal"}
        labels_pretty = [pretty.get(v, v) for v in labels]
        x = np.arange(len(labels))
        ax.bar(x, means, yerr=sds, capsize=3, color="#4c72b0")
        ax.set_xticks(x); ax.set_xticklabels(labels_pretty, rotation=0, fontsize=8)
        ax.set_title(f"Ablation @ $\\sigma$={sig_tag} ({n_seeds_here} seeds)")
        ax.grid(axis="y", alpha=0.3)
    axes[0].set_ylabel("Macro-F1")
    plt.tight_layout()
    _save(fig, "fig9_ablation")


def fig11_priv(R, sigma_map):
    if "privacy" not in R["results"]:
        return
    pr = R["results"]["privacy"]
    sigmas = sorted([float(k) for k in pr], key=float)
    f1m, f1s, iccm, iccs = [], [], [], []
    for sg in sigmas:
        sk = str(sg)
        per = pr[sk]["per_seed"]; pp = pr[sk]["paired_per_seed"]
        fs = []
        for s in per:
            for n in NODES:
                if n in s and "f1" in s[n] and not np.isnan(s[n]["f1"]):
                    fs.append(s[n]["f1"])
        f1m.append(np.mean(fs) if fs else 0); f1s.append(np.std(fs, ddof=1) if len(fs)>1 else 0)
        m_, s_ = _agg(pp, "icc_proba_dom")
        iccm.append(m_); iccs.append(s_)
    fig, ax1 = plt.subplots(figsize=(7, 3.6))
    ax1.errorbar(sigmas, f1m, yerr=f1s, fmt="o-", color="#4c72b0", label="Macro-F1", capsize=3)
    ax1.set_xscale("symlog", linthresh=1e-4)
    ax1.set_xlabel("$\\sigma$ (aggregate-update perturbation)")
    ax1.set_ylabel("Macro-F1", color="#4c72b0")
    ax1.grid(alpha=0.3)
    ax2 = ax1.twinx()
    ax2.errorbar(sigmas, iccm, yerr=iccs, fmt="s-", color="#c44e52",
                  label="Paired ICC", capsize=3)
    ax2.set_ylabel("Paired ICC", color="#c44e52")
    # u_sigma top axis in linear regime only
    if sigma_map is not None:
        results = {r["sigma_param"]: r for r in sigma_map["results"]}
        ax_top = ax1.twiny()
        ax_top.set_xlim(ax1.get_xlim()); ax_top.set_xscale(ax1.get_xscale())
        labeled = [s for s in sigmas if s in results and results[s].get("linear_regime", True) and s > 0]
        ax_top.set_xticks(labeled)
        ax_top.set_xticklabels([f"{results[s]['u_sigma_uV_closed_form']:.0f}"
                                for s in labeled])
        ax_top.set_xlabel("$u_\\sigma$ ($\\mu$V) — linear regime only")
    fig.legend(loc="upper center", bbox_to_anchor=(0.5, 0.04), ncol=2, fontsize=8)
    plt.tight_layout()
    _save(fig, "fig11_privacy_v12")


def fig6_consistency(R):
    """Heatmap of per-node mean F1 across 5 seeds (left) + inter-node CV
    (right). Regenerated from results_v20.json (was stale V9 data)."""
    main = R["results"]["main"]
    M = np.zeros((len(METHODS), 4))
    cv = []
    for i, m in enumerate(METHODS):
        if m not in main: continue
        for j, n in enumerate(NODES):
            v = [s.get(n, {}).get("f1", float("nan"))
                 for s in main[m]["per_seed"]]
            M[i, j] = float(np.nanmean(v))
        cv.append(float(np.nanstd(M[i]) / max(np.nanmean(M[i]), 1e-6)))
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 2.8),
                              gridspec_kw=dict(width_ratios=[1.6, 1]))
    im = axes[0].imshow(M, cmap="viridis", vmin=0, vmax=0.6, aspect="auto")
    axes[0].set_xticks(range(4)); axes[0].set_xticklabels(NODES)
    axes[0].set_yticks(range(len(METHODS)))
    short = {"local":"Local-only","fedavg":"FedAvg","fedprox":"FedProx",
              "scaffold":"SCAFFOLD","fedbn":"FedBN",
              "centralised":"Centralised$^\\dagger$","ours":"FedECG-Meas"}
    axes[0].set_yticklabels([short[m] for m in METHODS], fontsize=7)
    axes[0].set_title("(a) Macro-F1 across nodes (5 seeds)")
    for i in range(len(METHODS)):
        for j in range(4):
            axes[0].text(j, i, f"{M[i,j]:.2f}", ha="center", va="center",
                         fontsize=6.5,
                         color="white" if M[i,j] < 0.35 else "black")
    fig.colorbar(im, ax=axes[0], fraction=0.03, pad=0.02, label="F1")
    axes[1].barh(range(len(METHODS)), cv, color="#4c72b0")
    axes[1].set_yticks(range(len(METHODS)))
    axes[1].set_yticklabels([short[m] for m in METHODS], fontsize=7)
    axes[1].invert_yaxis()
    axes[1].set_xlabel("Inter-node CV of F1 ($\\downarrow$)")
    axes[1].set_title("(b) Cross-node performance variability")
    axes[1].grid(axis="x", alpha=0.3)
    plt.tight_layout()
    _save(fig, "fig6_consistency")


def main():
    R = json.load(open(os.path.join(RES, "results_v20.json")))
    preds_dir = os.path.join(RES, "preds")
    if "main" in R["results"]:
        table1_main(R, os.path.join(OUT, "tab1_main_f1.tex"))
        table2_paired(R, os.path.join(OUT, "tab2_v12_paired.tex"))
        fig4_main(R)
        fig6_consistency(R)
        if os.path.exists(preds_dir):
            fig7_paired(R, preds_dir)
    # Fall back to old V12 ablation_1e-3 data if not yet rerun for V21
    if "ablation_1e-3" not in R.get("results", {}):
        try:
            R12 = json.load(open(os.path.join(RES, "results.json")))
            if "ablation" in R12.get("results", {}):
                # rename to ablation_1e-3 for the figure
                R.setdefault("results", {})["ablation_1e-3"] = R12["results"]["ablation"]
                print("merged V12 ablation -> ablation_1e-3 (2 seeds)")
        except Exception:
            pass
    fig9_ablation(R)
    # If priv stage wasn't re-run in V20, fall back to V12 priv data (3 seeds)
    if "privacy" not in R.get("results", {}):
        try:
            R12 = json.load(open(os.path.join(RES, "results.json")))
            if "privacy" in R12.get("results", {}):
                R.setdefault("results", {})["privacy"] = R12["results"]["privacy"]
                print("merged V12 privacy data (3 seeds)")
        except Exception as e:
            print("could not merge V12 priv:", e)
    sig_path = os.path.join(RES, "sigma_mv_v20.json")
    if os.path.exists(sig_path):
        sigma_map = json.load(open(sig_path))
    else:
        sigma_map = None
    fig11_priv(R, sigma_map)


if __name__ == "__main__":
    main()
