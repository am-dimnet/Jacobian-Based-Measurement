"""V23 Fig 9: clean cross-architecture R using Hutchinson estimator
(no probe-scale artefact), plus MC vs CF using Hutchinson R."""
from __future__ import annotations
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")

d = json.load(open(os.path.join(RES, "hutchinson_multi.json")))
# Trained-encoder R from hutchinson_R.py earlier run:
TRAINED_R_PTB = 276.55
TRAINED_R_CHAP = 269.0  # estimated similarly from earlier; we keep within ~3% of PTB

ENC_ORDER = ["small_BN", "base_BN", "base_noBN", "large_BN"]
ENC_LABEL = {"small_BN":"small_BN\n(pure conv)",
              "base_BN":"base_BN",
              "base_noBN":"base_noBN",
              "large_BN":"large_BN"}
DS_COLOR = {"ptbxl":"#4c72b0", "chapman":"#dd8452"}

fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.4))

# ---- Panel (a): R via Hutchinson across (arch, dataset, init) ----
ax = axes[0]
x = np.arange(len(ENC_ORDER))
w = 0.36
for i, ds in enumerate(["ptbxl", "chapman"]):
    means, sds = [], []
    for arch in ENC_ORDER:
        Rs = [r["R"] for r in d["encoders"][arch][ds]]
        means.append(np.mean(Rs))
        sds.append(np.std(Rs, ddof=1) if len(Rs)>1 else 0)
    ax.bar(x + (i - 0.5) * w, means, w, yerr=sds, capsize=3,
           color=DS_COLOR[ds], label=ds.upper())
# Trained ours-encoder reference (0.33M params, between small and base)
ax.axhline(TRAINED_R_PTB, color="black", ls="--", lw=1.0)
ax.text(0.0, TRAINED_R_PTB+50, f"ours trained, R$\\approx${TRAINED_R_PTB:.0f}",
        fontsize=7.5, color="black")
ax.set_xticks(x); ax.set_xticklabels([ENC_LABEL[a] for a in ENC_ORDER], fontsize=8)
ax.set_ylabel("Jacobian ratio  $R = \\|J_\\theta\\|_F / \\|J_x\\|_F$")
ax.set_ylim(0, 3700)
ax.grid(axis="y", alpha=0.3)
ax.legend(fontsize=8, loc="upper left")

# ---- Panel (b): MC vs CF using Hutchinson R for trained ours-encoder ----
# Load V20 sigma_mv (MC) and trained_encoder_R.json (matched CF)
ax = axes[1]
# Trained ours, on PTB, σ vs MC (from V20):
sm = json.load(open(os.path.join(RES, "sigma_mv_v20.json")))
sigmas_old = [r["sigma_param"] for r in sm["results"]]
MC_trained_old = [r["u_sigma_uV_MC"] for r in sm["results"]]
# CF from Hutchinson R: CF = sigma * R * 0.12 mV * 1000 µV
CF_hutch_trained = [s * TRAINED_R_PTB * 120 for s in sigmas_old]
ax.loglog(sigmas_old, MC_trained_old, "o-", color="#c44e52", lw=1.5, ms=6,
          label="Monte-Carlo (output-drift match)")
ax.loglog(sigmas_old, CF_hutch_trained, "s-", color="#4c72b0", lw=1.5, ms=6,
          label="Closed-form (Hutchinson $R\\!=\\!277$)")
# Reference: probe-based CF (the superseded estimate)
CF_probe = [r["u_sigma_uV_closed_form"] for r in sm["results"]]
ax.loglog(sigmas_old, CF_probe, ":", color="grey", lw=1.0,
          label="Closed-form (earlier probe-based, $R\\!=\\!88.5$)")
ax.set_xlabel("$\\sigma$ (aggregate-update perturbation)")
ax.set_ylabel("$u_\\sigma$ ($\\mu$V) — trained ours encoder")
ax.legend(fontsize=7.5)
ax.grid(alpha=0.3, which="both")

plt.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(os.path.join(OUT, f"fig12_jacobian_validation.{ext}"),
                 dpi=300, bbox_inches="tight")
plt.close(fig)
print("wrote", os.path.join(OUT, "fig12_jacobian_validation.pdf"))
