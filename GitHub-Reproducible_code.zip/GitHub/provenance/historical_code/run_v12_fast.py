"""V12 fast resumer: skips main (use prior results.json) and only re-runs
ablation + privacy with R=20 + 2 seeds to keep total wall-clock < 1h."""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch

from data_real import (load_ptbxl, load_chapman, build_nodes, patient_split,
                       class_prior)
from models import ECGEncoder, ProjHead
from fed_algos import FederatedTrainer, local_ssl
from paired_eval import (paired_predictions, paired_consistency_metrics,
                          DEVICE_CHAINS)
from run_v12 import (split_node, train_one, evaluate_full,
                      make_node_gpu_loaders)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper48_v12/results")
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=1024)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seeds", type=int, nargs="+",
                    default=[20260522, 20260523])
    ap.add_argument("--max-per-node", type=int, default=4000)
    ap.add_argument("--max-chapman", type=int, default=6000)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device, "rounds:", args.rounds, "seeds:", args.seeds)

    # load main results to preserve them
    summary_path = os.path.join(args.out, "results.json")
    if os.path.exists(summary_path):
        summary = json.load(open(summary_path))
    else:
        summary = {"config": vars(args), "results": {}}
    summary["results_fast_config"] = vars(args)

    p = load_ptbxl(); c = load_chapman()
    nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                         max_per_node=args.max_per_node)

    t0 = time.time()

    # ablation — skip "noWeight" which equals fedavg in main, and "full" which equals ours in main
    abl_out = summary["results"].get("ablation", {})
    variants = [
        ("full",   dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
        ("noDamp", dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=1.0)),
        ("noProx", dict(algo="ours",   prox_mu=0.00, dp_sigma=1e-3, damping_gamma=0.6)),
        ("noDP",   dict(algo="ours",   prox_mu=0.01, dp_sigma=0.00, damping_gamma=0.6)),
        ("noWeight",dict(algo="fedavg", prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
    ]
    for vname, kw in variants:
        algo = kw.pop("algo")
        abl_out[vname] = {"per_seed": [], "paired_per_seed": []}
        for seed in args.seeds:
            torch.manual_seed(seed); np.random.seed(seed)
            print(f"\n>>> ABL {vname} seed={seed}")
            nodes_split = {nk: split_node(n, seed)
                            for nk, n in nodes.items()}
            enc = train_one(algo, nodes_split, args, device, print, **kw)
            per_node, paired = evaluate_full(enc, nodes_split, device, vname)
            abl_out[vname]["per_seed"].append(per_node)
            abl_out[vname]["paired_per_seed"].append(paired)
            kw["algo"] = algo
            f1m = np.mean([per_node[n]["f1"] for n in per_node])
            icc = np.mean([paired[n]["icc_proba_dom"] for n in paired])
            print(f"  F1={f1m:.3f}  ICC={icc:.3f}")
    summary["results"]["ablation"] = abl_out
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    # privacy
    pr_out = summary["results"].get("privacy", {})
    for sigma in [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]:
        pr_out[str(sigma)] = {"per_seed": [], "paired_per_seed": []}
        for seed in args.seeds:
            torch.manual_seed(seed); np.random.seed(seed)
            print(f"\n>>> PRIV sigma={sigma} seed={seed}")
            nodes_split = {nk: split_node(n, seed)
                            for nk, n in nodes.items()}
            enc = train_one("ours", nodes_split, args, device, print,
                             prox_mu=0.01, dp_sigma=sigma,
                             damping_gamma=0.6)
            per_node, paired = evaluate_full(enc, nodes_split, device,
                                              f"sigma{sigma}")
            pr_out[str(sigma)]["per_seed"].append(per_node)
            pr_out[str(sigma)]["paired_per_seed"].append(paired)
            f1m = np.mean([per_node[n]["f1"] for n in per_node])
            icc = np.mean([paired[n]["icc_proba_dom"] for n in paired])
            print(f"  F1={f1m:.3f}  ICC={icc:.3f}")
    summary["results"]["privacy"] = pr_out

    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nTOTAL TIME: {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
