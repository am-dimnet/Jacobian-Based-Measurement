"""
Sigma -> mV mapping: convert the server-side aggregate Gaussian noise
multiplier sigma into an equivalent input-signal measurement
uncertainty u_sigma in mV.

Method: encoder forward Jacobian + Monte-Carlo back-projection.

  Given parameter perturbation     dtheta ~ N(0, sigma^2 I),
  the induced output perturbation  dz approx J_theta(x) * dtheta.
  We want the equivalent input perturbation                        dx
  such that  J_x * dx ~ dz, i.e. the smallest input nudge that the
  encoder *cannot distinguish* from the parameter noise.

  We estimate ||dx||_2 by a MC procedure: sample sigma-scaled
  parameter noise N times, push x through the perturbed encoder, get
  the per-batch RMS output drift; convert that drift into the input-
  side noise level that would produce the same RMS output drift by a
  linear-search (or, more practically, by reading off the empirical
  noise-vs-perturbation curve we calibrate once).

  Reported as u_sigma in mV at the standard 12-lead amplitude of
  ~1 mV per LSB calibration (the ECG digitization convention).
"""
from __future__ import annotations
import argparse, json, os, time
import copy
import numpy as np
import torch

from data_real import load_ptbxl, build_nodes
from models import ECGEncoder


@torch.no_grad()
def output_rms_drift(enc, x_gpu, sigma_param, n_mc=8):
    """Average RMS output drift induced by parameter perturbation of size
    sigma_param applied to the encoder once.  RMS measured against the
    unperturbed encoder."""
    z0 = enc(x_gpu).cpu().numpy()
    drifts = []
    state0 = {k: v.detach().clone() for k, v in enc.state_dict().items()}
    for m in range(n_mc):
        perturbed = {}
        for k, v in state0.items():
            if v.dtype.is_floating_point:
                perturbed[k] = v + torch.randn_like(v) * sigma_param
            else:
                perturbed[k] = v
        enc.load_state_dict(perturbed)
        z = enc(x_gpu).cpu().numpy()
        drifts.append(np.sqrt(((z - z0) ** 2).mean()))
        enc.load_state_dict(state0)
    return float(np.mean(drifts))


@torch.no_grad()
def output_rms_drift_input_noise(enc, x_gpu, sigma_input, n_mc=8):
    z0 = enc(x_gpu).cpu().numpy()
    drifts = []
    for m in range(n_mc):
        xn = x_gpu + torch.randn_like(x_gpu) * sigma_input
        z = enc(xn).cpu().numpy()
        drifts.append(np.sqrt(((z - z0) ** 2).mean()))
    return float(np.mean(drifts))


def sigma_to_mv(sigma_param, enc, x_gpu, n_mc=8, n_search=10):
    """Linear-search for the input-side noise sigma_input that produces
    the same RMS output drift as the given sigma_param."""
    target = output_rms_drift(enc, x_gpu, sigma_param, n_mc=n_mc)
    # binary-search over sigma_input in [1e-5, 1.0]
    lo, hi = 1e-5, 1.0
    for _ in range(n_search):
        mid = np.sqrt(lo * hi)
        d = output_rms_drift_input_noise(enc, x_gpu, mid, n_mc=n_mc)
        if d < target:
            lo = mid
        else:
            hi = mid
    sigma_input = float(np.sqrt(lo * hi))
    # input is in z-score-normalised units; multiply by per-channel STD
    # of raw ECG amplitude in mV to map back to physical scale.
    # PTB-XL stores in 4.88 µV per LSB at 16-bit; the typical lead-II
    # peak-to-peak is ~1.5 mV. Empirical per-channel STD ~ 0.12 mV.
    std_mv = 0.12
    u_mv = sigma_input * std_mv
    return {"sigma_param": sigma_param,
            "target_rms_drift": target,
            "sigma_input_zscore": sigma_input,
            "u_sigma_mV": u_mv,
            "u_sigma_uV": u_mv * 1000.0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper48_v12/results/sigma_mv.json")
    ap.add_argument("--n-test", type=int, default=256)
    ap.add_argument("--sigmas", type=float, nargs="+",
                     default=[1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2])
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    p = load_ptbxl()
    X = p["X"][:args.n_test].astype(np.float32)
    Xt = torch.from_numpy(X).to(device)
    Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)

    enc = ECGEncoder().to(device)
    enc.eval()

    summary = {"chains": "MC param-vs-input-noise mapping",
                "n_test": args.n_test, "results": []}
    for s in args.sigmas:
        r = sigma_to_mv(s, enc, Xt, n_mc=8)
        print(r)
        summary["results"].append(r)
    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)
    print("saved", args.out)


if __name__ == "__main__":
    main()
