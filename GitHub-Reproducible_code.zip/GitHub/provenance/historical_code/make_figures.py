"""
TIM-style publication figures for the resubmitted manuscript.

Generates ~9-10 figures + 2-3 tables (well under the 12-item budget).
All vector PDF, colorblind-safe (Wong 2011), single-column ~3.4" or
two-column ~7" widths. No raster-only figures, no 3-D shadows.
"""
from __future__ import annotations
import json
import os
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

mpl.rcParams.update({
    "font.family": "serif", "font.size": 8,
    "axes.titlesize": 9, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
})

PAL = {
    "local":       "#999999",
    "fedavg":      "#0072B2",
    "fedprox":     "#56B4E9",
    "scaffold":    "#E69F00",
    "fedbn":       "#CC79A7",
    "centralised": "#009E73",
    "ours":        "#D55E00",
}
NODE_PAL = ["#0072B2", "#D55E00", "#009E73", "#CC79A7"]
CLASS_NAMES = ["NORM", "MI", "STTC", "CD", "HYP"]

HERE = os.path.dirname(__file__)
ROOT = os.path.dirname(HERE)
RES  = os.path.join(ROOT, "results")
OUT  = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)


def _save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, name + ".png"),
                bbox_inches="tight", dpi=220)
    plt.close(fig)
    print("wrote", name)


def load():
    with open(os.path.join(RES, "results.json")) as f:
        return json.load(f)


# =========================================================================
# Fig 1: system architecture
# =========================================================================
def fig_system():
    fig, ax = plt.subplots(figsize=(7.0, 3.4))
    ax.set_xlim(0, 14); ax.set_ylim(0, 5); ax.axis("off")

    # Acquisition nodes (left)
    nodes = [
        ("N1 PTB-XL site 0\n12-lead, 500 Hz", 0),
        ("N2 PTB-XL site 1\n12-lead, 500 Hz", 1),
        ("N3 PTB-XL site 2\n12-lead, 500 Hz", 2),
        ("N4 Chapman-Shaoxing\n12-lead, 500 Hz", 3),
    ]
    for i, (label, idx) in enumerate(nodes):
        y = 4.3 - i * 1.05
        # acquisition module
        ax.add_patch(FancyBboxPatch((0.1, y - 0.25), 1.8, 0.6,
            boxstyle="round,pad=0.04", fc=NODE_PAL[idx],
            ec="black", alpha=0.9))
        ax.text(1.0, y + 0.05, label, ha="center", va="center",
                fontsize=6.8, color="white", weight="bold")
        # sensor -> ADC -> conditioning chain
        ax.add_patch(FancyBboxPatch((2.0, y - 0.18), 1.4, 0.45,
            boxstyle="round,pad=0.03", fc="#FFFFFF", ec="black"))
        ax.text(2.7, y + 0.05, "ADC + SQI",
                ha="center", va="center", fontsize=6.5)
        # local feature measurement
        ax.add_patch(FancyBboxPatch((3.6, y - 0.18), 1.7, 0.45,
            boxstyle="round,pad=0.03", fc="#EFEFEF", ec="black"))
        ax.text(4.45, y + 0.05, "Local SSL feature\nmeasurement",
                ha="center", va="center", fontsize=6.2)
        # arrows
        ax.add_patch(FancyArrowPatch((5.3, y), (7.0, 2.6),
            arrowstyle="->", mutation_scale=8, color="grey", lw=0.8))

    # Server / calibration
    ax.add_patch(FancyBboxPatch((7.0, 1.7), 4.2, 1.8,
        boxstyle="round,pad=0.05", fc="#FBE4D5", ec="black"))
    ax.text(9.1, 3.2, "Server-side measurement coordinator",
            ha="center", va="center", fontsize=7.5, weight="bold")
    ax.text(9.1, 2.7, "(i) Quality-aware fusion weight $\\tilde n_k$",
            ha="center", va="center", fontsize=6.5)
    ax.text(9.1, 2.35, "(ii) Acquisition-sensitive layer calibration",
            ha="center", va="center", fontsize=6.5)
    ax.text(9.1, 2.0, "(iii) Measurement-uncertainty injection",
            ha="center", va="center", fontsize=6.5)

    # Broadcast back
    ax.add_patch(FancyArrowPatch((11.2, 2.6), (12.2, 2.6),
        arrowstyle="->", mutation_scale=10, color="black", lw=1.0))
    ax.add_patch(FancyBboxPatch((12.2, 1.7), 1.7, 1.8,
        boxstyle="round,pad=0.05", fc="#D6E8D5", ec="black"))
    ax.text(13.05, 2.6, "Shared\nencoder\n$f_{\\theta^{(r)}}$",
            ha="center", va="center", fontsize=7, weight="bold")

    # privacy boundary
    ax.add_patch(plt.Rectangle((0.0, 0.0), 6.2, 5.0, fill=False,
        ls="--", ec="#888888", lw=0.8))
    ax.text(0.1, 4.85,
            "Privacy boundary -- raw ECG never leaves the acquisition node",
            fontsize=6.5, style="italic", color="#444444")
    _save(fig, "fig1_system_overview")


# =========================================================================
# Fig 2: measurement pipeline
# =========================================================================
def fig_pipeline():
    fig, ax = plt.subplots(figsize=(7.0, 1.5))
    ax.set_xlim(0, 14); ax.set_ylim(0, 1); ax.axis("off")
    steps = ["Sensor /\nelectrode", "Anti-alias\nfilter", "ADC\n(125-500 Hz)",
             "Lead\nselect", "Z-score\nnorm.", "Encoder\n$f_\\theta$",
             "Calibrated\nupdate $\\Delta_k$", "Server\nfusion + $\\xi$",
             "Shared $f_{\\theta^{(r)}}$"]
    n = len(steps)
    w = 14.0 / n - 0.1
    for i, s in enumerate(steps):
        ax.add_patch(FancyBboxPatch((i * (w + 0.1) + 0.05, 0.2), w, 0.6,
            boxstyle="round,pad=0.04",
            fc="#F4F4F4", ec="black"))
        ax.text(i * (w + 0.1) + 0.05 + w / 2, 0.5, s,
                ha="center", va="center", fontsize=6.5)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch(
                (i * (w + 0.1) + 0.05 + w, 0.5),
                ((i + 1) * (w + 0.1) + 0.05, 0.5),
                arrowstyle="->", mutation_scale=6, color="black", lw=0.5))
    _save(fig, "fig2_measurement_pipeline")


# =========================================================================
# Fig 3: cross-node heterogeneity
# =========================================================================
def fig_heterogeneity(R):
    nodes_info = R["nodes"]
    nks = list(nodes_info.keys())
    M = np.array([nodes_info[k]["prior"] for k in nks])
    sqi = [nodes_info[k]["sqi_mean"] for k in nks]
    ns = [nodes_info[k]["n"] for k in nks]

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.4),
                             gridspec_kw=dict(width_ratios=[1.4, 1]))
    im = axes[0].imshow(M, cmap="YlOrRd", aspect="auto", vmin=0, vmax=0.7)
    axes[0].set_xticks(range(5)); axes[0].set_xticklabels(CLASS_NAMES)
    axes[0].set_yticks(range(len(nks))); axes[0].set_yticklabels(
        [f"{k}\n({nodes_info[k]['source']})" for k in nks])
    axes[0].set_title("(a) Class prior across acquisition nodes")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            axes[0].text(j, i, f"{M[i,j]:.2f}", ha="center", va="center",
                fontsize=6, color="white" if M[i,j] > 0.3 else "black")
    fig.colorbar(im, ax=axes[0], fraction=0.04, pad=0.02, label="prob.")

    # SQI / size bars
    x = np.arange(len(nks))
    ax2 = axes[1]; ax2b = ax2.twinx()
    ax2.bar(x - 0.18, sqi, width=0.36, color="#0072B2", label="mean SQI")
    ax2b.bar(x + 0.18, ns, width=0.36, color="#D55E00", label="n records")
    ax2.set_xticks(x); ax2.set_xticklabels(nks)
    ax2.set_ylabel("mean SQI", color="#0072B2"); ax2b.set_ylabel("n records", color="#D55E00")
    ax2.set_title("(b) Signal quality and node size")
    ax2.set_ylim(0, 1.0)
    ax2.spines["right"].set_visible(True); ax2b.spines["right"].set_visible(True)
    _save(fig, "fig3_heterogeneity")


# =========================================================================
# Fig 4: main results (per-node macro-F1, mean ± 95% CI over seeds)
# =========================================================================
def _gather_main(R):
    main = R["results"]["main"]
    methods = ["local", "fedavg", "fedprox", "scaffold", "fedbn",
               "centralised", "ours"]
    nks = list(R["nodes"].keys())
    f1 = {m: {nk: [] for nk in nks} for m in methods}
    acc = {m: {nk: [] for nk in nks} for m in methods}
    auc = {m: {nk: [] for nk in nks} for m in methods}
    for m in methods:
        for per_seed in main[m]["per_seed"]:
            for nk in nks:
                f1[m][nk].append(per_seed[nk]["f1"])
                acc[m][nk].append(per_seed[nk]["acc"])
                if not np.isnan(per_seed[nk]["auc"]):
                    auc[m][nk].append(per_seed[nk]["auc"])
    return methods, nks, f1, acc, auc


def fig_main(R):
    methods, nks, f1, acc, auc = _gather_main(R)
    fig, ax = plt.subplots(figsize=(7.0, 3.0))
    x = np.arange(len(nks)); w = 0.11
    for i, m in enumerate(methods):
        means = [np.mean(f1[m][nk]) for nk in nks]
        sds   = [np.std(f1[m][nk], ddof=1) if len(f1[m][nk]) > 1 else 0 for nk in nks]
        ax.bar(x + (i - 3) * w, means, width=w, color=PAL[m],
               yerr=sds, capsize=2, label=m.replace("_","-"),
               error_kw=dict(lw=0.6, ecolor="black"))
    ax.set_xticks(x); ax.set_xticklabels(nks)
    ax.set_ylabel("Macro-F1 (mean over 3 seeds, $\\pm$1 SD)")
    ax.set_title("Per-node downstream classification performance")
    ax.legend(ncol=4, frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.13))
    ax.set_ylim(0, 1.0)
    ax.grid(axis="y", alpha=0.3)
    _save(fig, "fig4_main_results")


# =========================================================================
# Fig 5: convergence (loss vs round)
# =========================================================================
def fig_convergence(R):
    main = R["results"]["main"]
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    for m in ["fedavg", "fedprox", "scaffold", "fedbn", "ours"]:
        h = main.get(m, {}).get("history_last_seed")
        if h is None: continue
        ax.plot(h["round"], h["avg_loss"], "-o", ms=3, lw=1.2,
                color=PAL[m], label=m.replace("_", "-"))
    ax.set_xlabel("Communication round")
    ax.set_ylabel("Avg. contrastive loss")
    ax.set_title("Federated pretraining convergence")
    ax.grid(alpha=0.3); ax.legend(frameon=False)
    _save(fig, "fig5_convergence")


# =========================================================================
# Fig 6: cross-node measurement consistency (ICC + Bland-Altman pieces)
# =========================================================================
def fig_consistency(R):
    """Per-method ICC, kappa, BA-LoA across the 4 nodes.
    We compute these from per-node accuracy across seeds."""
    methods, nks, f1, acc, auc = _gather_main(R)
    from metrics import icc_3_1, bland_altman, coefficient_of_variation

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.6))
    # ICC: rows=seeds, cols=nodes -> ICC across nodes per method
    iccs = {}; cvs = {}
    for m in methods:
        # measurement matrix: rows = "subjects" = nodes, cols = "raters" = seeds
        rows = []
        for nk in nks:
            rows.append(acc[m][nk])
        M = np.array(rows)
        if M.shape[1] >= 2:
            iccs[m] = icc_3_1(M)
        else:
            iccs[m] = float("nan")
        cvs[m] = coefficient_of_variation([np.mean(acc[m][nk]) for nk in nks])
    xs = list(iccs.keys()); ys = [iccs[m] for m in xs]
    axes[0].bar(range(len(xs)), ys, color=[PAL[m] for m in xs])
    axes[0].set_xticks(range(len(xs)))
    axes[0].set_xticklabels([m.replace("_","-") for m in xs],
                             rotation=30, ha="right")
    axes[0].set_ylabel("ICC$_{(3,1)}$ across seeds at each node")
    axes[0].set_title("(a) Cross-seed measurement consistency")
    axes[0].set_ylim(-0.2, 1.0)
    axes[0].grid(axis="y", alpha=0.3)

    ys2 = [cvs[m] * 100 for m in xs]
    axes[1].bar(range(len(xs)), ys2, color=[PAL[m] for m in xs])
    axes[1].set_xticks(range(len(xs)))
    axes[1].set_xticklabels([m.replace("_","-") for m in xs],
                             rotation=30, ha="right")
    axes[1].set_ylabel("Inter-node CV (%) of accuracy")
    axes[1].set_title("(b) Inter-node measurement variability")
    axes[1].grid(axis="y", alpha=0.3)
    _save(fig, "fig6_consistency")


# =========================================================================
# Fig 7: robustness to fs + leads + SNR
# =========================================================================
def fig_robust(R):
    rob = R["results"].get("robust")
    if rob is None:
        return
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.4))
    for which, ax, label in [("fs", axes[0], "Sampling rate (Hz)"),
                              ("leads", axes[1], "# leads"),
                              ("snr", axes[2], "Test SNR (dB)")]:
        for algo in ["fedavg", "ours"]:
            data = rob.get(which, {}).get(algo, {})
            if not data: continue
            seed = list(data.keys())[0]
            curve = data[seed]["curve"]
            xs = sorted([float(k) for k in curve.keys()])
            ys = [np.mean([curve[str(int(x) if which != "fs" else int(x))][nk]["f1"]
                            for nk in curve[str(int(x))].keys()]) for x in xs]
            ax.plot(xs, ys, "-o", color=PAL[algo], lw=1.2, ms=3,
                    label=algo.replace("_","-"))
        ax.set_xlabel(label); ax.set_ylabel("Macro-F1")
        ax.legend(frameon=False); ax.grid(alpha=0.3)
    axes[0].set_title("(a) Sampling-rate robustness")
    axes[1].set_title("(b) Lead-configuration robustness")
    axes[2].set_title("(c) Sensor-noise tolerance")
    _save(fig, "fig7_robustness")


# =========================================================================
# Fig 8: privacy / measurement uncertainty
# =========================================================================
def fig_privacy(R):
    pri = R["results"].get("privacy")
    if not pri: return
    sigmas = sorted([float(k) for k in pri.keys()])
    f1_means = []; acc_means = []
    for s in sigmas:
        s_key = str(s)
        f1_means.append(np.mean([v["f1"] for v in pri[s_key].values()]))
        acc_means.append(np.mean([v["acc"] for v in pri[s_key].values()]))
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    ax.plot(sigmas, f1_means, "-s", color=PAL["fedavg"], label="Macro-F1")
    ax.plot(sigmas, acc_means, "-o", color=PAL["ours"], label="Accuracy")
    ax.set_xscale("symlog", linthresh=1e-4)
    ax.set_xlabel(r"DP noise multiplier $\sigma$  "
                   r"($\propto$ measurement uncertainty)")
    ax.set_ylabel("Score")
    ax.set_title("Privacy-utility / uncertainty trade-off")
    ax.legend(frameon=False); ax.grid(alpha=0.3)
    _save(fig, "fig8_privacy")


# =========================================================================
# Fig 9: ablation
# =========================================================================
def fig_ablation(R):
    abl = R["results"].get("ablation")
    if not abl: return
    order = ["full", "noWeight", "noDamp", "noProx", "noDP"]
    labels = ["FedECG-Meas\n(full)", "w/o quality\nweight",
              "w/o calib.\ndamping", "w/o prox.\nterm",
              "w/o uncertainty\ninjection"]
    f1s = [np.mean([abl[v][nk]["f1"] for nk in abl[v].keys()]) for v in order]
    accs = [np.mean([abl[v][nk]["acc"] for nk in abl[v].keys()]) for v in order]
    x = np.arange(len(order)); w = 0.35
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    ax.bar(x - w / 2, accs, width=w, color=PAL["ours"], label="Acc")
    ax.bar(x + w / 2, f1s, width=w, color=PAL["fedavg"], label="F1")
    ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=6.5)
    ax.set_ylabel("Macro score (test)"); ax.legend(frameon=False, ncol=2)
    ax.set_title("Component ablation"); ax.grid(axis="y", alpha=0.3)
    _save(fig, "fig9_ablation")


# =========================================================================
# Table 1: main scores LaTeX dump
# =========================================================================
def table_main(R):
    methods, nks, f1, acc, auc = _gather_main(R)
    names = {"local":"Local-only","fedavg":"FedAvg","fedprox":"FedProx",
             "scaffold":"SCAFFOLD","fedbn":"FedBN",
             "centralised":"Centralised$^\\dagger$",
             "ours":"\\method"}
    lines = [r"\begin{tabular}{l" + ("c" * (len(nks) + 1)) + "}", r"\toprule"]
    lines.append("Method & " + " & ".join(nks) + " & Macro \\\\")
    lines.append(r"\midrule")
    for m in methods:
        cells = []
        for nk in nks:
            mu = np.mean(f1[m][nk]); sd = np.std(f1[m][nk], ddof=1) if len(f1[m][nk]) > 1 else 0
            cells.append(f"{mu:.3f}$\\pm${sd:.3f}")
        macro = np.mean([np.mean(f1[m][nk]) for nk in nks])
        cells.append(f"{macro:.3f}")
        lines.append(f"{names[m]} & " + " & ".join(cells) + r" \\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    with open(os.path.join(OUT, "tab1_main_f1.tex"), "w") as f:
        f.write("\n".join(lines))
    print("wrote tab1_main_f1.tex")


# =========================================================================
def main():
    R = load()
    fig_system()
    fig_pipeline()
    fig_heterogeneity(R)
    fig_main(R)
    fig_convergence(R)
    fig_consistency(R)
    fig_robust(R)
    fig_privacy(R)
    fig_ablation(R)
    table_main(R)


if __name__ == "__main__":
    main()
