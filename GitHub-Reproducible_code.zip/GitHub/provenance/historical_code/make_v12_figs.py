"""V12 figure + table generation from results_v12.json + sigma_mv.json."""
from __future__ import annotations
import json, os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)

mpl.rcParams.update({
    "font.family": "serif", "font.size": 8,
    "axes.titlesize": 9, "axes.labelsize": 8,
    "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
})

PAL = {
    "local": "#CC79A7", "fedavg": "#0072B2", "fedprox": "#56B4E9",
    "scaffold": "#E69F00", "fedbn": "#999999",
    "centralised": "#009E73", "ours": "#D55E00",
}
LABEL = {"local": "Local-only", "fedavg": "FedAvg", "fedprox": "FedProx",
          "scaffold": "SCAFFOLD", "fedbn": "FedBN",
          "centralised": "Centralised", "ours": "FedECG-Meas (ours)"}
METHODS = ["local", "fedavg", "fedprox", "scaffold", "fedbn",
            "centralised", "ours"]
NODES = ["N1", "N2", "N3", "N4"]


def _save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, name + ".png"), bbox_inches="tight", dpi=220)
    plt.close(fig); print("wrote", name + ".pdf")


def _agg_metric(per_seed_paired, metric):
    """per_seed_paired: list of {node: {metric: value}}."""
    vals = []
    for s in per_seed_paired:
        for n in NODES:
            if n in s and metric in s[n]:
                v = s[n][metric]
                if isinstance(v, (int, float)) and not np.isnan(v):
                    vals.append(v)
    if not vals: return (float("nan"), float("nan"))
    return float(np.mean(vals)), float(np.std(vals))


def fig10_paired_consistency(R):
    main = R["results"]["main"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8),
                              gridspec_kw=dict(width_ratios=[1.1, 1]))

    # Panel (a): bar plot of ICC(proba_dom) per method
    icc_mean = []; icc_std = []; cv_mean = []
    for m in METHODS:
        if m not in main or not main[m].get("paired_per_seed"):
            icc_mean.append(np.nan); icc_std.append(0)
            cv_mean.append(np.nan); continue
        mu, sd = _agg_metric(main[m]["paired_per_seed"], "icc_proba_dom")
        icc_mean.append(mu); icc_std.append(sd)
        mu_cv, _ = _agg_metric(main[m]["paired_per_seed"], "cv_mean")
        cv_mean.append(mu_cv)
    x = np.arange(len(METHODS))
    axes[0].bar(x, icc_mean, yerr=icc_std, capsize=2,
                 color=[PAL[m] for m in METHODS])
    axes[0].set_xticks(x); axes[0].set_xticklabels(
        [LABEL[m].split(" ")[0] for m in METHODS], rotation=20, ha="right")
    axes[0].set_ylabel("ICC$_{(3,1)}$ of dom-class prob.\nacross 4 devices")
    axes[0].set_ylim(0, 1.0)
    axes[0].axhline(0.75, ls=":", color="grey", lw=0.7)
    axes[0].text(0.05, 0.76, "0.75 (good agreement)", fontsize=6, color="grey")
    axes[0].set_title("(a) Cross-acquisition ICC$_{(3,1)}$ (3 seeds)")
    axes[0].grid(axis="y", alpha=0.3)

    # Panel (b): Bland-Altman of D1 vs D4 for ours vs fedavg
    ba_data = {}
    for m in ["fedavg", "ours"]:
        if m not in main or not main[m].get("paired_per_seed"):
            continue
        biases = []; sds = []
        for s in main[m]["paired_per_seed"]:
            for n in NODES:
                if n in s and "ba_pairs" in s[n] and "D1-D4" in s[n]["ba_pairs"]:
                    biases.append(s[n]["ba_pairs"]["D1-D4"]["bias"])
                    sds.append(s[n]["ba_pairs"]["D1-D4"]["sd"])
        if biases:
            ba_data[m] = (float(np.mean(biases)), float(np.mean(sds)))

    # Bland-Altman summary (bias and +/- 1.96 SD lines). The per-record
    # scatter is not persisted in the cached predictions; this panel
    # reports the summary statistic only and is labelled as such.
    for i, (m, (bias, sd)) in enumerate(ba_data.items()):
        axes[1].axhline(bias, ls="-", color=PAL[m], lw=1.4,
                         label=f"{LABEL[m]}\n  bias={bias:+.3f}, SD={sd:.3f}")
        axes[1].axhline(bias + 1.96 * sd, ls="--", color=PAL[m], lw=0.8,
                         alpha=0.6)
        axes[1].axhline(bias - 1.96 * sd, ls="--", color=PAL[m], lw=0.8,
                         alpha=0.6)
        axes[1].fill_between([0, 1], bias - 1.96 * sd, bias + 1.96 * sd,
                              color=PAL[m], alpha=0.07)
    axes[1].set_xlim(0, 1); axes[1].set_ylim(-1.0, 1.0)
    axes[1].set_xlabel("Reference probability mean (arb.)")
    axes[1].set_ylabel(r"$p_{D_1}-p_{D_4}$ (dom-class probability)")
    axes[1].set_title("(b) $D_1\\!-\\!D_4$ difference summary")
    axes[1].axhline(0, ls=":", color="black", lw=0.5)
    axes[1].legend(frameon=False, fontsize=5.8, loc="upper right")
    axes[1].grid(alpha=0.3)
    axes[1].text(0.5, -0.93,
                 "Summary only; per-record paired-probability scatter\n"
                 "was not persisted in the cached predictions.",
                 ha="center", fontsize=5.5, style="italic", color="#555")
    _save(fig, "fig10_paired_consistency")


def fig11_privacy_v12(R, sigma_mv=None):
    pr = R["results"].get("privacy", {})
    if not pr:
        print("no privacy results yet"); return
    sigmas = sorted([float(k) for k in pr.keys()])
    mean_f1 = []; std_f1 = []
    mean_icc = []; std_icc = []
    for s in sigmas:
        v = pr[str(s)]
        seeds_f1 = []
        for ps in v["per_seed"]:
            seeds_f1.append(np.mean([ps[n]["f1"] for n in NODES]))
        mean_f1.append(np.mean(seeds_f1))
        std_f1.append(np.std(seeds_f1) if len(seeds_f1) > 1 else 0)
        mu, sd = _agg_metric(v.get("paired_per_seed", []), "icc_proba_dom")
        mean_icc.append(mu); std_icc.append(sd)

    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    sigmas_safe = [max(s, 1e-5) for s in sigmas]
    ax.errorbar(sigmas_safe, mean_f1, yerr=std_f1, fmt="-o",
                 color=PAL["ours"], lw=1.3, label="Macro-F1")
    if not all(np.isnan(mean_icc)):
        ax.errorbar(sigmas_safe, mean_icc, yerr=std_icc, fmt="--s",
                     color=PAL["fedavg"], lw=1.2, label="Paired ICC")
    ax.set_xscale("symlog", linthresh=1e-4)
    ax.set_xlabel("$\\sigma$ (server-side noise multiplier)")
    ax.set_ylabel("Score (mean across 2 seeds, $\\pm$1 SD)")
    ax.set_title(r"Aggregate-update perturbation $\sigma$ vs. performance")
    ax.grid(alpha=0.3); ax.legend(frameon=False, fontsize=7)
    # add top axis with u_sigma (uV) if mapping available
    if sigma_mv is not None:
        mp = {r["sigma_param"]: r["u_sigma_uV"] for r in sigma_mv["results"]}
        ax2 = ax.twiny(); ax2.set_xscale("symlog", linthresh=1e-4)
        ax2.set_xlim(ax.get_xlim())
        # include all sigma points; sigma=0 corresponds to u_sigma=0 by definition
        ticks = sigmas_safe
        labels = []
        for t, raw_t in zip(ticks, sigmas):
            if raw_t == 0.0:
                labels.append("0")
            else:
                v = mp.get(raw_t, 0)
                labels.append(f"{v:.0f}" if v > 0 else "")
        ax2.set_xticks(ticks)
        ax2.set_xticklabels(labels, fontsize=6)
        ax2.set_xlabel(r"$u_\sigma$ ($\mu$V) on input", fontsize=7)
    _save(fig, "fig11_privacy_v12")


def table_v12(R):
    main = R["results"]["main"]
    lines = []
    lines.append(r"\begin{tabular}{lccc}")
    lines.append(r"\toprule")
    lines.append(r"Method & ICC$_{(3,1)}$ $\uparrow$ & CV $\downarrow$ "
                  r"& BA $|$bias$|$+SD $\downarrow$ \\")
    lines.append(r"\midrule")
    for m in METHODS:
        if m not in main or not main[m].get("paired_per_seed"):
            continue
        icc, icc_sd = _agg_metric(main[m]["paired_per_seed"], "icc_proba_dom")
        cv, cv_sd   = _agg_metric(main[m]["paired_per_seed"], "cv_mean")
        # for BA, average |bias|+sd across pairs and seeds
        ba_vals = []
        for s in main[m]["paired_per_seed"]:
            for n in NODES:
                if n in s and "ba_pairs" in s[n]:
                    for k, d in s[n]["ba_pairs"].items():
                        ba_vals.append(abs(d["bias"]) + d["sd"])
        ba = float(np.mean(ba_vals)) if ba_vals else float("nan")
        lines.append(f"{LABEL[m]} & {icc:.3f}$\\pm${icc_sd:.3f} "
                      f"& {cv:.3f}$\\pm${cv_sd:.3f} & {ba:.3f} \\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    with open(os.path.join(OUT, "tab2_v12_paired.tex"), "w") as f:
        f.write("\n".join(lines))
    print("wrote tab2_v12_paired.tex")


def fig9_ablation_v12(R):
    abl = R["results"].get("ablation", {})
    if not abl: return
    order = ["full", "noWeight", "noDamp", "noDP"]
    labels = ["Full",
              "w/o quality\nweight",
              "w/o early-layer\ndamping",
              "w/o aggregate\nperturbation"]
    f1_means = []; f1_stds = []
    icc_means = []
    for v in order:
        if v not in abl: continue
        f1s = []
        for ps in abl[v]['per_seed']:
            f1s.append(np.mean([ps[n]['f1'] for n in NODES]))
        f1_means.append(np.mean(f1s))
        f1_stds.append(np.std(f1s))
        iccs = []
        for ps in abl[v].get('paired_per_seed', []):
            for n in NODES:
                iccs.append(ps[n].get('icc_proba_dom', float('nan')))
        icc_means.append(np.nanmean(iccs))
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    x = np.arange(len(order))
    bars = ax.bar(x, f1_means, yerr=f1_stds, capsize=2,
                   color=PAL["ours"], edgecolor="black", linewidth=0.5)
    ax.set_xticks(x); ax.set_xticklabels(labels[:len(f1_means)], fontsize=6.5)
    ax.set_ylabel("Federation-wide macro-F1 (2 seeds)")
    ax.set_title("Component ablation at $\\sigma{=}10^{-3}$ default (2 seeds)")
    ax.grid(axis="y", alpha=0.3)
    # annotate ICC on top
    for i, (b, icc) in enumerate(zip(bars, icc_means)):
        ax.text(b.get_x() + b.get_width()/2,
                 b.get_height() + (f1_stds[i] if i < len(f1_stds) else 0) + 0.005,
                 f"ICC={icc:+.3f}", ha="center", fontsize=6, color="black")
    _save(fig, "fig9_ablation")


def main():
    R = json.load(open(os.path.join(RES, "results.json")))
    sigma_mv = None
    smv_path = os.path.join(RES, "sigma_mv.json")
    if os.path.exists(smv_path):
        sigma_mv = json.load(open(smv_path))
    fig10_paired_consistency(R)
    if "privacy" in R.get("results", {}):
        fig11_privacy_v12(R, sigma_mv)
    if "ablation" in R.get("results", {}):
        fig9_ablation_v12(R)
    table_v12(R)
    print("V12 figures + table written to", OUT)


if __name__ == "__main__":
    main()
