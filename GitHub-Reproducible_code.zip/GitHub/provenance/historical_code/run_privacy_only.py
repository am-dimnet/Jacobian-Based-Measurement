"""Standalone privacy-sweep runner. Saves to results_privacy.json."""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch

from data_real import load_ptbxl, load_chapman, build_nodes
from run_v12 import split_node, train_one, evaluate_full


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper48_v12/results/results_privacy.json")
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=1024)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seeds", type=int, nargs="+",
                    default=[20260522, 20260523])
    ap.add_argument("--max-per-node", type=int, default=6000)
    ap.add_argument("--max-chapman", type=int, default=8000)
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("PRIVACY device:", device, "rounds:", args.rounds, "seeds:", args.seeds)
    p = load_ptbxl(); c = load_chapman()
    nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                         max_per_node=args.max_per_node)

    out = {}
    t0 = time.time()
    for sigma in [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]:
        out[str(sigma)] = {"per_seed": [], "paired_per_seed": []}
        for seed in args.seeds:
            torch.manual_seed(seed); np.random.seed(seed)
            print(f"\n>>> PRIV sigma={sigma} seed={seed}")
            nodes_split = {nk: split_node(n, seed)
                            for nk, n in nodes.items()}
            enc = train_one("ours", nodes_split, args, device, print,
                             prox_mu=0.01, dp_sigma=sigma,
                             damping_gamma=0.6)
            per_node, paired = evaluate_full(enc, nodes_split, device,
                                              f"sigma{sigma}")
            out[str(sigma)]["per_seed"].append(per_node)
            out[str(sigma)]["paired_per_seed"].append(paired)
            f1m = np.mean([per_node[n]["f1"] for n in per_node])
            icc = np.mean([paired[n]["icc_proba_dom"] for n in paired])
            print(f"  F1={f1m:.3f}  ICC={icc:.3f}")
        with open(args.out, "w") as f:
            json.dump(out, f, indent=2)
    print(f"\nPRIVACY TOTAL TIME: {time.time() - t0:.1f}s -> {args.out}")


if __name__ == "__main__":
    main()
