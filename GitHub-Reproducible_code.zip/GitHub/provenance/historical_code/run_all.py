"""
End-to-end TIM experiment runner.

Stages:
  A. Main comparison: Local / FedAvg / FedProx / SCAFFOLD / FedBN /
     Centralised / Ours  (3 seeds, 8 rounds each)
  B. Cross-node measurement consistency (ICC, kappa, Bland-Altman, CV)
  C. Sampling-rate robustness (down-resample test signals)
  D. Lead-configuration robustness (mask leads at test)
  E. Real-noise injection from MIT-BIH NSTDB-style additive noise
  F. SQI-bucket sensitivity
  G. Ablation of OURS components
  H. Privacy-utility / measurement-uncertainty sweep
  I. Compute / communication / latency footprint

Results to /root/autodl-tmp/Paper48/results/results.json
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch
from torch.utils.data import DataLoader

from data_real import (load_ptbxl, load_chapman, build_nodes, patient_split,
                       class_prior, class_entropy, SUPERCLASSES, N_CLASSES)
from models import ECGEncoder, ProjHead, ClsHead
from fed_algos import (FederatedTrainer, NodeDataset, local_ssl)
from metrics import (cls_metrics, icc_3_1, bland_altman,
                     coefficient_of_variation, paired_t,
                     wilcoxon, cliffs_delta, mean_ci)


# ---------------------------------------------------------------------------
@torch.no_grad()
def embed(enc, X, device, bs=256):
    enc.eval()
    out = []
    for i in range(0, len(X), bs):
        x = torch.from_numpy(X[i:i + bs].astype(np.float32)).to(device)
        x = (x - x.mean(-1, keepdim=True)) / (x.std(-1, keepdim=True) + 1e-6)
        z = enc(x).cpu().numpy()
        out.append(z)
    return np.concatenate(out)


def linear_probe(enc, Xtr, ytr, Xte, yte, device, K=5, epochs=30, lr=1e-2):
    Ztr = embed(enc, Xtr, device); Zte = embed(enc, Xte, device)
    clf = ClsHead(Ztr.shape[1], K).to(device)
    opt = torch.optim.AdamW(clf.parameters(), lr=lr, weight_decay=1e-3)
    Ztr_t = torch.from_numpy(Ztr).float().to(device)
    ytr_t = torch.from_numpy(ytr).long().to(device)
    Zte_t = torch.from_numpy(Zte).float().to(device)
    bs = 128
    for _ in range(epochs):
        idx = torch.randperm(len(Ztr_t))
        for i in range(0, len(Ztr_t), bs):
            sel = idx[i:i + bs]
            loss = torch.nn.functional.cross_entropy(clf(Ztr_t[sel]),
                                                     ytr_t[sel])
            opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        logits = clf(Zte_t)
        proba = torch.softmax(logits, -1).cpu().numpy()
        pred = proba.argmax(1)
    return cls_metrics(yte, pred, proba, K), pred, proba


# ---------------------------------------------------------------------------
def make_node_loaders(nodes_split, batch=64, num_workers=2, gpu_preload=True,
                       device="cuda"):
    """If gpu_preload, each node's training X is a (N,12,T) tensor staged on
    GPU once (skips DataLoader and worker overhead)."""
    loaders = {}; priors = []; sizes = []; sqi_means = []
    for nk, sp in nodes_split.items():
        if gpu_preload and device == "cuda":
            X = torch.from_numpy(sp["Xtr"].astype(np.float32)).to(device)
            X._batch = batch  # tag for the GPU path
            loaders[nk] = X
        else:
            ds = NodeDataset(sp["Xtr"], sp["ytr"], sp.get("sqi_q_tr"))
            loaders[nk] = DataLoader(ds, batch_size=batch, shuffle=True,
                                     num_workers=num_workers, drop_last=True,
                                     pin_memory=True)
        priors.append(class_prior(sp["ytr"]))
        sizes.append(len(sp["ytr"]))
        sqi_means.append(float(np.nanmean(sp.get("sqi_q_tr",
                                                   np.array([1.0])))))
    return loaders, priors, sizes, sqi_means


def split_node(node, seed):
    tr, va, te = patient_split(node, 0.8, 0.1, seed=seed)
    out = {
        "Xtr": node["X"][tr], "ytr": node["y"][tr],
        "Xva": node["X"][va], "yva": node["y"][va],
        "Xte": node["X"][te], "yte": node["y"][te],
        "sqi_q_tr": node["sqi_q"][tr] if "sqi_q" in node else None,
        "sqi_q_te": node["sqi_q"][te] if "sqi_q" in node else None,
    }
    return out


def evaluate_per_node(enc, nodes_split, device, K=5):
    out = {}
    # train probe on pooled embeddings (privacy-safe: embeddings only)
    Xtr = np.concatenate([sp["Xtr"] for sp in nodes_split.values()])
    ytr = np.concatenate([sp["ytr"] for sp in nodes_split.values()])
    for nk, sp in nodes_split.items():
        m, pred, proba = linear_probe(enc, Xtr, ytr,
                                       sp["Xte"], sp["yte"], device, K)
        out[nk] = {**m, "n_test": int(len(sp["yte"]))}
    return out


# ---------------------------------------------------------------------------
def run_main(nodes, args, device, log):
    """Stage A: main comparison across 7 methods × seeds."""
    enc_factory = lambda: ECGEncoder(d=128, n_tf=2, nhead=4)
    head_factory = lambda: ProjHead(128, 64)
    out = {}
    for algo in ["local", "fedavg", "fedprox", "scaffold", "fedbn",
                 "centralised", "ours"]:
        out[algo] = {"per_seed": []}
        for seed in args.seeds:
            torch.manual_seed(seed); np.random.seed(seed)
            log(f">> {algo} seed={seed}")
            nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
            loaders, priors, sizes, sqi = make_node_loaders(nodes_split,
                                                              batch=args.batch,
                                                              num_workers=args.workers)
            if algo == "local":
                # train separate encoder per node, evaluate per node with local probe
                per_node = {}
                for nk, ldr in loaders.items():
                    enc = enc_factory().to(device); hd = head_factory().to(device)
                    for _ in range(args.rounds):
                        local_ssl(enc, hd, ldr, args.local_epochs, args.lr,
                                  device)
                    m, _, _ = linear_probe(enc, nodes_split[nk]["Xtr"],
                                            nodes_split[nk]["ytr"],
                                            nodes_split[nk]["Xte"],
                                            nodes_split[nk]["yte"], device)
                    per_node[nk] = {**m, "n_test": int(len(nodes_split[nk]["yte"]))}
                out[algo]["per_seed"].append(per_node)
                continue
            if algo == "centralised":
                X_pool = np.concatenate([sp["Xtr"] for sp in nodes_split.values()])
                if device == "cuda":
                    X_pool_t = torch.from_numpy(X_pool.astype(np.float32)).to(device)
                    X_pool_t._batch = args.batch
                    ldr = X_pool_t
                else:
                    ds = NodeDataset(X_pool, np.zeros(len(X_pool)))
                    ldr = DataLoader(ds, batch_size=args.batch, shuffle=True,
                                     num_workers=args.workers, drop_last=True,
                                     pin_memory=True)
                enc = enc_factory().to(device); hd = head_factory().to(device)
                for _ in range(args.rounds):
                    local_ssl(enc, hd, ldr, args.local_epochs, args.lr, device)
                per_node = evaluate_per_node(enc, nodes_split, device)
                out[algo]["per_seed"].append(per_node)
                continue
            # federated
            fedbn_layers = ["bn"]
            trainer = FederatedTrainer(enc_factory, head_factory, loaders,
                                        priors, sizes, sqi,
                                        algo=algo, rounds=args.rounds,
                                        local_epochs=args.local_epochs,
                                        lr=args.lr, device=device,
                                        prox_mu=0.01, dp_sigma=1e-3,
                                        damping_gamma=0.6, clip=1.0,
                                        fedbn_layers=fedbn_layers, log=log)
            hist, enc, _ = trainer.train()
            per_node = evaluate_per_node(enc, nodes_split, device)
            out[algo]["per_seed"].append(per_node)
            out[algo]["history_last_seed"] = hist
    return out


# ---------------------------------------------------------------------------
def run_robust(nodes, args, device, log,
                fs_targets=(125, 250, 360), lead_targets=(1, 3, 6),
                noise_snrs=(20, 10, 0)):
    """Stages C/D/E. Train OURS+FedAvg once per seed; evaluate with perturbed
    test signals."""
    out = {"fs": {}, "leads": {}, "snr": {}}
    enc_factory = lambda: ECGEncoder(d=128, n_tf=2, nhead=4)
    head_factory = lambda: ProjHead(128, 64)
    for seed in args.seeds[:1]:  # 1 seed for robustness sweeps
        nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
        loaders, priors, sizes, sqi = make_node_loaders(nodes_split,
                                                          batch=args.batch,
                                                          num_workers=args.workers)
        for algo in ["fedavg", "ours"]:
            trainer = FederatedTrainer(enc_factory, head_factory, loaders,
                                        priors, sizes, sqi, algo=algo,
                                        rounds=args.rounds,
                                        local_epochs=args.local_epochs,
                                        lr=args.lr, device=device,
                                        prox_mu=0.01, dp_sigma=1e-3,
                                        damping_gamma=0.6, clip=1.0,
                                        fedbn_layers=["bn"], log=log)
            _, enc, _ = trainer.train()
            # baseline at native 500 Hz
            base = evaluate_per_node(enc, nodes_split, device)

            # sampling-rate sweep: downsample then upsample test
            fs_curve = {}
            for fs in fs_targets:
                ratio = fs / 500
                perturbed = {}
                for nk, sp in nodes_split.items():
                    T = sp["Xte"].shape[-1]
                    Tnew = max(64, int(T * ratio))
                    idx = np.linspace(0, T - 1, Tnew).astype(int)
                    x_down = sp["Xte"][:, :, idx]
                    # upsample back to T by repeating
                    idx_up = np.linspace(0, Tnew - 1, T).astype(int)
                    x_up = x_down[:, :, idx_up]
                    perturbed[nk] = {**sp, "Xte": x_up}
                fs_curve[fs] = evaluate_per_node(enc,
                    {nk: {"Xtr": sp["Xtr"], "ytr": sp["ytr"],
                          "Xte": p["Xte"], "yte": p["yte"]}
                     for (nk, sp), (_, p) in zip(nodes_split.items(),
                                                  perturbed.items())},
                    device)
            out["fs"].setdefault(algo, {})[seed] = {"base": base, "curve": fs_curve}

            # lead sweep
            lead_curve = {}
            for n_lead in lead_targets:
                pert = {}
                lead_mask = np.zeros(12, dtype=np.float32)
                lead_mask[:n_lead] = 1.0
                for nk, sp in nodes_split.items():
                    Xp = sp["Xte"] * lead_mask[None, :, None]
                    pert[nk] = {**sp, "Xte": Xp.astype(sp["Xte"].dtype)}
                lead_curve[n_lead] = evaluate_per_node(enc,
                    {nk: {"Xtr": sp["Xtr"], "ytr": sp["ytr"],
                          "Xte": p["Xte"], "yte": p["yte"]}
                     for (nk, sp), (_, p) in zip(nodes_split.items(),
                                                   pert.items())},
                    device)
            out["leads"].setdefault(algo, {})[seed] = {"base": base, "curve": lead_curve}

            # SNR sweep
            rng = np.random.default_rng(seed * 7 + 1)
            snr_curve = {}
            for snr_db in noise_snrs:
                pert = {}
                for nk, sp in nodes_split.items():
                    sig_pow = (sp["Xte"].astype(np.float32) ** 2).mean()
                    noise_pow = sig_pow / (10 ** (snr_db / 10))
                    noise = rng.normal(0, np.sqrt(noise_pow),
                                        sp["Xte"].shape).astype(np.float32)
                    Xp = (sp["Xte"].astype(np.float32) + noise)
                    pert[nk] = {**sp, "Xte": Xp.astype(np.float32)}
                snr_curve[snr_db] = evaluate_per_node(enc,
                    {nk: {"Xtr": sp["Xtr"], "ytr": sp["ytr"],
                          "Xte": p["Xte"], "yte": p["yte"]}
                     for (nk, sp), (_, p) in zip(nodes_split.items(),
                                                   pert.items())},
                    device)
            out["snr"].setdefault(algo, {})[seed] = {"base": base, "curve": snr_curve}
    return out


def run_ablation(nodes, args, device, log):
    enc_factory = lambda: ECGEncoder(d=128, n_tf=2, nhead=4)
    head_factory = lambda: ProjHead(128, 64)
    out = {}
    variants = [
        ("full",  dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
        ("noWeight", dict(algo="fedavg", prox_mu=0.01, dp_sigma=1e-3, damping_gamma=0.6)),
        ("noDamp", dict(algo="ours",   prox_mu=0.01, dp_sigma=1e-3, damping_gamma=1.0)),
        ("noProx", dict(algo="ours",   prox_mu=0.00, dp_sigma=1e-3, damping_gamma=0.6)),
        ("noDP",   dict(algo="ours",   prox_mu=0.01, dp_sigma=0.00, damping_gamma=0.6)),
    ]
    for seed in args.seeds[:1]:
        nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
        loaders, priors, sizes, sqi = make_node_loaders(nodes_split,
                                                          batch=args.batch,
                                                          num_workers=args.workers)
        for vname, kw in variants:
            algo = kw.pop("algo")
            trainer = FederatedTrainer(enc_factory, head_factory, loaders,
                                        priors, sizes, sqi, algo=algo,
                                        rounds=args.rounds,
                                        local_epochs=args.local_epochs,
                                        lr=args.lr, device=device,
                                        fedbn_layers=["bn"], log=log, **kw)
            _, enc, _ = trainer.train()
            per_node = evaluate_per_node(enc, nodes_split, device)
            out[vname] = per_node
    return out


def run_privacy(nodes, args, device, log,
                 sigmas=(0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2)):
    enc_factory = lambda: ECGEncoder(d=128, n_tf=2, nhead=4)
    head_factory = lambda: ProjHead(128, 64)
    out = {}
    seed = args.seeds[0]
    nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
    loaders, priors, sizes, sqi = make_node_loaders(nodes_split,
                                                      batch=args.batch,
                                                      num_workers=args.workers)
    for sigma in sigmas:
        trainer = FederatedTrainer(enc_factory, head_factory, loaders,
                                    priors, sizes, sqi, algo="ours",
                                    rounds=args.rounds,
                                    local_epochs=args.local_epochs,
                                    lr=args.lr, device=device,
                                    prox_mu=0.01, dp_sigma=sigma,
                                    damping_gamma=0.6, fedbn_layers=["bn"],
                                    log=log)
        _, enc, _ = trainer.train()
        per_node = evaluate_per_node(enc, nodes_split, device)
        out[str(sigma)] = per_node
    return out


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper48/results")
    ap.add_argument("--rounds", type=int, default=8)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seeds", type=int, nargs="+",
                    default=[20260522, 20260523, 20260524])
    ap.add_argument("--stage", default="all",
                    help="all|main|robust|ablation|privacy|smoke")
    ap.add_argument("--max-chapman", type=int, default=12000)
    ap.add_argument("--max-per-node", type=int, default=0,
                    help="cap every node's records (0 = no cap)")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device, "rounds:", args.rounds, "seeds:", args.seeds)

    print("loading PTB-XL ...")
    p = load_ptbxl(); print(" PTB-XL:", p["X"].shape,
                             "class dist:", np.bincount(p["y"], minlength=5))
    print("loading Chapman ...")
    c = load_chapman(); print(" Chapman:", c["X"].shape,
                                "class dist:", np.bincount(c["y"], minlength=5))
    nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                        max_per_node=args.max_per_node)
    for k, v in nodes.items():
        print(f" {k} {v['source']} n={len(v['y'])} prior={class_prior(v['y']).round(3)} SQI={v['sqi_q'].mean():.3f}")

    log = print
    summary = {"config": vars(args), "nodes": {
        nk: {"source": v["source"], "n": int(len(v["y"])),
             "prior": class_prior(v["y"]).tolist(),
             "sqi_mean": float(v["sqi_q"].mean())}
        for nk, v in nodes.items()
    }, "results": {}}

    t0 = time.time()
    if args.stage == "smoke":
        args.rounds = 1; args.seeds = [args.seeds[0]]
        args.max_chapman = 800
        nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                        max_per_node=args.max_per_node)
        # reduce node sizes
        for k in nodes:
            n = nodes[k]
            keep = min(500, len(n["y"]))
            for f in ["X","y","patient","fold","site","device","age","sex","sqi_q","sqi_feats","ecg_id"]:
                if f in n and isinstance(n[f], np.ndarray) and len(n[f]) >= keep:
                    n[f] = n[f][:keep]
        print("smoke nodes:", {k: len(v["y"]) for k,v in nodes.items()})
        summary["results"]["main"] = run_main(nodes, args, device, log)
    if args.stage in ("all", "main"):
        summary["results"]["main"] = run_main(nodes, args, device, log)
    if args.stage in ("all", "robust"):
        summary["results"]["robust"] = run_robust(nodes, args, device, log)
    if args.stage in ("all", "ablation"):
        summary["results"]["ablation"] = run_ablation(nodes, args, device, log)
    if args.stage in ("all", "privacy"):
        summary["results"]["privacy"] = run_privacy(nodes, args, device, log)

    with open(os.path.join(args.out, "results.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"TOTAL TIME: {time.time() - t0:.1f}s")
    print(f"saved -> {args.out}/results.json")


if __name__ == "__main__":
    main()
