"""V13 tables: Table I (per-node Acc/F1/AUC) and Table II (paired-device
consistency) regenerated from the merged results.json with σ=1e-3 default
+ σ=1e-2 calibrated rows for ours, avoiding column truncation."""
from __future__ import annotations
import json, os
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
NODES = ["N1","N2","N3","N4"]
METHODS = ["local","fedavg","fedprox","scaffold","fedbn","centralised","ours"]
LABEL = {"local": "Local-only", "fedavg":"FedAvg", "fedprox":"FedProx",
         "scaffold":"SCAFFOLD", "fedbn":"FedBN", "centralised":"Centralised$^\\dagger$ (raw-pool)",
         "ours":"\\method ($\\sigma{=}10^{-3}$)"}


def _agg(stages, key):
    """For one method's per_seed list, mean and std of key over all nodes×seeds."""
    vals = []
    for s in stages:
        for n in NODES:
            if n in s and key in s[n]:
                v = s[n][key]
                if isinstance(v,(int,float)) and not np.isnan(v):
                    vals.append(v)
    return (np.mean(vals), np.std(vals)) if vals else (float('nan'), float('nan'))


def _node_agg(stages, n, key):
    vals = [s[n][key] for s in stages if n in s and not np.isnan(s[n].get(key, float('nan')))]
    return (np.mean(vals), np.std(vals)) if vals else (float('nan'), float('nan'))


def table1_main(R, out_path):
    """Per-node Acc / F1 / AUC, mean ± SD over 3 seeds; macro avg column.
    Compact column format using resizebox for full-width without truncation."""
    main = R['results']['main']
    privacy = R['results'].get('privacy', {})
    lines = []
    lines.append(r"\resizebox{\textwidth}{!}{%")
    lines.append(r"\begin{tabular}{l" + "ccc"*5 + "}")
    lines.append(r"\toprule")
    lines.append(r"Method & " + " & ".join(f"\\multicolumn{{3}}{{c}}{{{n}}}" for n in NODES)
                  + r" & \multicolumn{3}{c}{Federation avg} \\")
    lines.append(" ".join(f"\\cmidrule(lr){{{2+3*i}-{4+3*i}}}" for i in range(5)))
    lines.append(" & " + " & ".join(["Acc & F1 & AUC"]*5) + r" \\")
    lines.append(r"\midrule")
    for m in METHODS:
        if m not in main: continue
        cells = []
        accs, f1s, aucs = [], [], []
        for n in NODES:
            a_m, a_s = _node_agg(main[m]['per_seed'], n, 'acc')
            f_m, f_s = _node_agg(main[m]['per_seed'], n, 'f1')
            u_m, u_s = _node_agg(main[m]['per_seed'], n, 'auc')
            cells.extend([f"{a_m:.3f}", f"{f_m:.3f}", f"{u_m:.3f}"])
            accs.append(a_m); f1s.append(f_m); aucs.append(u_m)
        cells.extend([f"{np.mean(accs):.3f}", f"{np.mean(f1s):.3f}",
                      f"{np.nanmean(aucs):.3f}"])
        lines.append(LABEL[m] + " & " + " & ".join(cells) + r" \\")
    # extra row: ours @ sigma=1e-2 from privacy sweep
    if "0.01" in privacy:
        cells = []; accs, f1s, aucs = [], [], []
        for n in NODES:
            a_m,_ = _node_agg(privacy["0.01"]['per_seed'], n, 'acc')
            f_m,_ = _node_agg(privacy["0.01"]['per_seed'], n, 'f1')
            u_m,_ = _node_agg(privacy["0.01"]['per_seed'], n, 'auc')
            cells.extend([f"{a_m:.3f}", f"{f_m:.3f}", f"{u_m:.3f}"])
            accs.append(a_m); f1s.append(f_m); aucs.append(u_m)
        cells.extend([f"{np.mean(accs):.3f}", f"{np.mean(f1s):.3f}",
                      f"{np.nanmean(aucs):.3f}"])
        lines.append(r"\method ($\sigma{=}10^{-2}$, post-hoc) & "
                      + " & ".join(cells) + r" \\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}}")
    lines.append(r"% Notes: mean across 3 seeds; $\dagger$ centralised requires raw-data pooling and is not admissible in a federated deployment.")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    print(f"wrote {out_path}")


def table2_paired(R, out_path):
    """Paired-device consistency per method, with explicit σ row for ours."""
    main = R['results']['main']
    privacy = R['results'].get('privacy', {})
    lines = []
    lines.append(r"\begin{tabular}{lcccc}")
    lines.append(r"\toprule")
    lines.append(r"Method & ICC$_{(3,1)}$ $\uparrow$ "
                  r"& Cohen $\kappa$ D1--D2 $\uparrow$ "
                  r"& Inter-device CV $\downarrow$ "
                  r"& \multicolumn{1}{c}{BA bias D1--D4} \\")
    lines.append(r"\midrule")
    rows = [(m, main[m].get('paired_per_seed', [])) for m in METHODS if m in main]
    if "0.01" in privacy:
        rows.append(("ours_s102", privacy["0.01"].get('paired_per_seed', [])))
    for m, ps in rows:
        if not ps: continue
        icc_m, icc_s = _agg(ps, 'icc_proba_dom')
        cv_m, _ = _agg(ps, 'cv_mean')
        kpv = []; bavals = []
        for s in ps:
            for n in NODES:
                if n in s and 'kappa_pairs' in s[n]:
                    v = s[n]['kappa_pairs'].get('D1-D2', float('nan'))
                    if not np.isnan(v): kpv.append(v)
                if n in s and 'ba_pairs' in s[n]:
                    d = s[n]['ba_pairs'].get('D1-D4', {})
                    if d: bavals.append(d['bias'])
        kp = np.mean(kpv) if kpv else float('nan')
        ba = np.mean(bavals) if bavals else float('nan')
        label = (r"\method ($\sigma{=}10^{-2}$, post-hoc)" if m == "ours_s102"
                  else LABEL[m])
        lines.append(f"{label} & {icc_m:+.3f}$\\pm${icc_s:.3f} "
                      f"& {kp:+.3f} & {cv_m:.3f} & {ba:+.3f} \\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"% mean over 3 seeds (2 seeds for $\sigma{=}10^{-2}$ from privacy sweep); ICC $\in[-1,1]$, $\ge 0.75$ indicates good agreement, $<0$ indicates worse-than-chance pairing.")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    print(f"wrote {out_path}")


def main():
    R = json.load(open(os.path.join(RES, "results.json")))
    table1_main(R,  os.path.join(OUT, "tab1_main_f1.tex"))
    table2_paired(R, os.path.join(OUT, "tab2_v12_paired.tex"))


if __name__ == "__main__":
    main()
