"""Merge main + per-seed ablation + per-seed privacy + sigma_mv into one
results_v12_final.json with the structure expected by make_v12_figs.py."""
from __future__ import annotations
import json, os

RES = "/Users/josan/Desktop/Article/Paper20_TIM/results"


def _merge_seed_lists(a: dict, b: dict, key="per_seed") -> dict:
    """For each variant, concatenate per_seed and paired_per_seed."""
    out = {}
    keys = set(a.keys()) | set(b.keys())
    for k in keys:
        out[k] = {"per_seed": [], "paired_per_seed": []}
        if k in a:
            out[k]["per_seed"].extend(a[k].get("per_seed", []))
            out[k]["paired_per_seed"].extend(a[k].get("paired_per_seed", []))
        if k in b:
            out[k]["per_seed"].extend(b[k].get("per_seed", []))
            out[k]["paired_per_seed"].extend(b[k].get("paired_per_seed", []))
    return out


def main():
    main_path = os.path.join(RES, "results_v12_main.json")
    sigma_mv_path = os.path.join(RES, "sigma_mv.json")
    abl0_path = os.path.join(RES, "results_abl_s0.json")
    abl1_path = os.path.join(RES, "results_abl_s1.json")
    pr0_path = os.path.join(RES, "results_priv_s0.json")
    pr1_path = os.path.join(RES, "results_priv_s1.json")

    with open(main_path) as f:
        R = json.load(f)

    # ablation
    if os.path.exists(abl0_path) and os.path.exists(abl1_path):
        a0 = json.load(open(abl0_path)); a1 = json.load(open(abl1_path))
        R["results"]["ablation"] = _merge_seed_lists(a0, a1)
        print(f"merged ablation: {sorted(R['results']['ablation'].keys())}")

    # privacy
    if os.path.exists(pr0_path) and os.path.exists(pr1_path):
        p0 = json.load(open(pr0_path)); p1 = json.load(open(pr1_path))
        R["results"]["privacy"] = _merge_seed_lists(p0, p1)
        print(f"merged privacy sigmas: {sorted(R['results']['privacy'].keys(), key=float)}")

    # sigma_mv
    if os.path.exists(sigma_mv_path):
        R["sigma_mv"] = json.load(open(sigma_mv_path))
        print(f"included sigma_mv mapping with {len(R['sigma_mv']['results'])} points")

    out = os.path.join(RES, "results.json")
    with open(out, "w") as f:
        json.dump(R, f, indent=2)
    print(f"wrote merged -> {out} ({os.path.getsize(out)//1024} KB)")


if __name__ == "__main__":
    main()
