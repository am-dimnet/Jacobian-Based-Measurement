"""Multi-architecture, multi-dataset σ→u_σ validation.

For each (encoder, dataset, sigma):
  - compute closed-form u_σ from Jacobian ratio R = ||J_θ||_F / ||J_x||_F
  - compute MC u_σ via output-drift matching
  - characterise CF/MC discrepancy and locate the "linear regime edge" σ*

Produces results/multi_encoder_sigma_map.json which the figure script
turns into a 2D characterisation plot of the sensitivity-map tool.
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from data_real import load_ptbxl, load_chapman


# ---------------------------------------------------------------------------
# Four encoder variants for the cross-architecture validation
# ---------------------------------------------------------------------------
class _ConvBlock(nn.Module):
    def __init__(self, c_in, c_out, k, s, use_bn=True):
        super().__init__()
        self.conv = nn.Conv1d(c_in, c_out, k, s, k//2)
        self.bn = nn.BatchNorm1d(c_out) if use_bn else nn.Identity()
        self.use_bn = use_bn
    def forward(self, x):
        return F.silu(self.bn(self.conv(x)))


class EncoderSmall(nn.Module):
    """~0.10 M params: 3 conv blocks, no transformer, BN on."""
    def __init__(self, d=64, in_ch=12):
        super().__init__()
        self.in_ch = in_ch
        self.stem = _ConvBlock(in_ch, 24, 25, 2, True)
        self.b1 = _ConvBlock(24, 40, 11, 2, True)
        self.b2 = _ConvBlock(40, d, 7, 2, True)
        self.d = d
    def forward(self, x):
        h = self.stem(x); h = self.b1(h); h = self.b2(h)
        return h.mean(-1)


class EncoderBase(nn.Module):
    """~0.33 M params: 4 conv blocks + 2 transformer layers, BN on.
    Mirrors models.ECGEncoder."""
    def __init__(self, d=128, in_ch=12):
        super().__init__()
        self.in_ch = in_ch
        self.stem = _ConvBlock(in_ch, 32, 25, 2, True)
        self.b1 = _ConvBlock(32, 48, 15, 2, True)
        self.b2 = _ConvBlock(48, 64, 11, 2, True)
        self.b3 = _ConvBlock(64, 96, 9, 2, True)
        self.b4 = _ConvBlock(96, d, 7, 2, True)
        layer = nn.TransformerEncoderLayer(d_model=d, nhead=4,
                  dim_feedforward=256, batch_first=True,
                  dropout=0.0, activation="gelu")
        self.tf = nn.TransformerEncoder(layer, 2)
        self.norm = nn.LayerNorm(d)
        self.d = d
    def forward(self, x):
        h = self.stem(x); h = self.b1(h); h = self.b2(h); h = self.b3(h); h = self.b4(h)
        h = h.transpose(1, 2)
        h = self.tf(h)
        h = self.norm(h)
        return h.mean(1)


class EncoderLarge(nn.Module):
    """~1 M params: 5 conv blocks + 4 transformer layers, BN on."""
    def __init__(self, d=192, in_ch=12):
        super().__init__()
        self.in_ch = in_ch
        self.stem = _ConvBlock(in_ch, 48, 25, 2, True)
        self.b1 = _ConvBlock(48, 64, 15, 2, True)
        self.b2 = _ConvBlock(64, 96, 11, 2, True)
        self.b3 = _ConvBlock(96, 128, 9, 2, True)
        self.b4 = _ConvBlock(128, d, 7, 2, True)
        layer = nn.TransformerEncoderLayer(d_model=d, nhead=6,
                  dim_feedforward=384, batch_first=True,
                  dropout=0.0, activation="gelu")
        self.tf = nn.TransformerEncoder(layer, 4)
        self.norm = nn.LayerNorm(d)
        self.d = d
    def forward(self, x):
        h = self.stem(x); h = self.b1(h); h = self.b2(h); h = self.b3(h); h = self.b4(h)
        h = h.transpose(1, 2)
        h = self.tf(h)
        h = self.norm(h)
        return h.mean(1)


class EncoderBaseNoBN(nn.Module):
    """Same shape as EncoderBase but WITHOUT BatchNorm — tests whether the
    CF/MC discrepancy is BN-driven."""
    def __init__(self, d=128, in_ch=12):
        super().__init__()
        self.in_ch = in_ch
        self.stem = _ConvBlock(in_ch, 32, 25, 2, False)
        self.b1 = _ConvBlock(32, 48, 15, 2, False)
        self.b2 = _ConvBlock(48, 64, 11, 2, False)
        self.b3 = _ConvBlock(64, 96, 9, 2, False)
        self.b4 = _ConvBlock(96, d, 7, 2, False)
        layer = nn.TransformerEncoderLayer(d_model=d, nhead=4,
                  dim_feedforward=256, batch_first=True,
                  dropout=0.0, activation="gelu")
        self.tf = nn.TransformerEncoder(layer, 2)
        self.norm = nn.LayerNorm(d)
        self.d = d
    def forward(self, x):
        h = self.stem(x); h = self.b1(h); h = self.b2(h); h = self.b3(h); h = self.b4(h)
        h = h.transpose(1, 2)
        h = self.tf(h)
        h = self.norm(h)
        return h.mean(1)


ENCODERS = {
    "small_BN": EncoderSmall,
    "base_BN":  EncoderBase,
    "base_noBN": EncoderBaseNoBN,
    "large_BN": EncoderLarge,
}


# ---------------------------------------------------------------------------
# Drift estimators (param-only perturbation; BN running stats kept fixed)
# ---------------------------------------------------------------------------
@torch.no_grad()
def _drift_param(enc, x, sigma, n_mc=16):
    """RMS output drift from per-parameter Gaussian noise of std sigma."""
    z0 = enc(x)
    param_names = {n for n, _ in enc.named_parameters()}
    state0 = {k: v.detach().clone() for k, v in enc.state_dict().items()}
    drifts = []
    for _ in range(n_mc):
        perturbed = {k: (v + torch.randn_like(v) * sigma if (k in param_names and v.dtype.is_floating_point) else v)
                     for k, v in state0.items()}
        enc.load_state_dict(perturbed)
        z = enc(x)
        drifts.append(((z - z0) ** 2).mean().sqrt().item())
    enc.load_state_dict(state0)
    return float(np.mean(drifts)), float(np.std(drifts))


@torch.no_grad()
def _drift_input(enc, x, sigma_in, n_mc=16):
    z0 = enc(x)
    drifts = []
    for _ in range(n_mc):
        xn = x + torch.randn_like(x) * sigma_in
        drifts.append(((enc(xn) - z0) ** 2).mean().sqrt().item())
    return float(np.mean(drifts)), float(np.std(drifts))


def jacobian_ratio(enc, x, n_mc=16, s_small=1e-5):
    """Estimate R = ||J_theta||_F / ||J_x||_F via slopes at very small noise.

    Using s_small=1e-5 (10x smaller than the previous value) to stay
    deeper inside the linear regime, which is one of the reasons the V20
    MC vs CF ratio was off."""
    d_param, _ = _drift_param(enc, x, s_small, n_mc=n_mc)
    d_input, _ = _drift_input(enc, x, s_small, n_mc=n_mc)
    return d_param / max(d_input, 1e-12)


@torch.no_grad()
def mc_match(enc, x, sigma_param, n_mc=16, lo=1e-7, hi=50.0, n_iter=30):
    """Find sigma_x such that input-noise output drift == param-noise output
    drift at sigma_param. EXTENDED bracket vs V20 (1e-7 lower bound)."""
    target, _ = _drift_param(enc, x, sigma_param, n_mc=n_mc)
    for _ in range(n_iter):
        mid = np.sqrt(lo * hi)
        d, _ = _drift_input(enc, x, mid, n_mc=n_mc)
        if d < target:
            lo = mid
        else:
            hi = mid
    return float(np.sqrt(lo * hi)), float(target)


def _load_data(name, n_test=256, device="cuda"):
    if name == "ptbxl":
        p = load_ptbxl(); X = p["X"][:n_test].astype(np.float32)
        std_mV = 0.12
    elif name == "chapman":
        c = load_chapman(); X = c["X"][:n_test].astype(np.float32)
        std_mV = 0.15  # Chapman has slightly higher amplitude variance
    else:
        raise ValueError(name)
    Xt = torch.from_numpy(X).to(device)
    Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)
    return Xt, std_mV


def _count_params(enc):
    return sum(p.numel() for p in enc.parameters())


# ---------------------------------------------------------------------------
def evaluate_one(enc, x, std_mV, sigmas, n_mc=16, s_small=1e-5):
    """Closed-form + MC for each sigma, plus the per-encoder R."""
    R = jacobian_ratio(enc, x, n_mc=n_mc, s_small=s_small)
    out = {"R": R, "n_params": _count_params(enc),
           "ecg_std_mV": std_mV, "results": []}
    for s in sigmas:
        # closed-form: u_σ_z = σ × R, in mV multiply by std_mV
        u_z_cf = s * R
        u_mV_cf = u_z_cf * std_mV
        u_z_mc, target = mc_match(enc, x, s, n_mc=n_mc)
        u_mV_mc = u_z_mc * std_mV
        rel = abs(u_z_mc - u_z_cf) / max(u_z_cf, 1e-12)
        out["results"].append({
            "sigma": s,
            "u_sigma_zscore_CF": u_z_cf,
            "u_sigma_zscore_MC": u_z_mc,
            "u_sigma_uV_CF": u_mV_cf * 1000.0,
            "u_sigma_uV_MC": u_mV_mc * 1000.0,
            "target_drift": target,
            "rel_err": rel,
        })
    return out


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper20_TIM/results/multi_encoder_sigma_map.json")
    ap.add_argument("--n-test", type=int, default=256)
    ap.add_argument("--n-mc", type=int, default=24)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])  # 3 inits per arch
    ap.add_argument("--sigmas", type=float, nargs="+",
                    default=[1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2])
    ap.add_argument("--datasets", nargs="+", default=["ptbxl", "chapman"])
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    summary = {"config": vars(args), "encoders": {}}
    for arch_name, EncCls in ENCODERS.items():
        summary["encoders"][arch_name] = {"per_seed": {}}
        for ds in args.datasets:
            print(f"\n=== {arch_name} / {ds} ===", flush=True)
            Xt, std_mV = _load_data(ds, n_test=args.n_test, device=device)
            ds_runs = []
            for seed in args.seeds:
                torch.manual_seed(seed)
                enc = EncCls(in_ch=12).to(device).eval()
                t0 = time.time()
                r = evaluate_one(enc, Xt, std_mV, args.sigmas,
                                  n_mc=args.n_mc, s_small=1e-5)
                r["seed"] = seed
                ds_runs.append(r)
                print(f"  seed={seed} R={r['R']:.2f} n_params={r['n_params']/1e6:.2f}M "
                      f"sigma=1e-3 CF={r['results'][4]['u_sigma_uV_CF']:.1f}uV "
                      f"MC={r['results'][4]['u_sigma_uV_MC']:.1f}uV "
                      f"({time.time()-t0:.0f}s)", flush=True)
            summary["encoders"][arch_name][ds] = ds_runs
        # save after each architecture so we don't lose progress
        with open(args.out, "w") as f:
            json.dump(summary, f, indent=2)
    print("\nsaved", args.out)


if __name__ == "__main__":
    main()
