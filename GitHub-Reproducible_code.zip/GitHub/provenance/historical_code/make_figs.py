"""TIM-style publication figures + Table I from results.json."""
from __future__ import annotations
import json, os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)

mpl.rcParams.update({
    "font.family": "serif", "font.size": 8,
    "axes.titlesize": 9, "axes.labelsize": 8,
    "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
})

PAL = {
    "local": "#CC79A7", "fedavg": "#0072B2", "fedprox": "#56B4E9",
    "scaffold": "#E69F00", "fedbn": "#999999",
    "centralised": "#009E73", "ours": "#D55E00",
}
NODE_PAL = ["#0072B2", "#D55E00", "#009E73", "#CC79A7"]
CLASS_PAL = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#F0E442"]
NODES = ["N1", "N2", "N3", "N4"]
CLASSES = ["NORM", "MI", "STTC", "CD", "HYP"]
METHODS = ["local", "fedavg", "fedprox", "scaffold", "fedbn",
            "centralised", "ours"]
LABEL = {"local": "Local-only", "fedavg": "FedAvg", "fedprox": "FedProx",
          "scaffold": "SCAFFOLD", "fedbn": "FedBN",
          "centralised": "Centralised", "ours": "FedECG-Meas (ours)"}


def _save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, name + ".png"), bbox_inches="tight", dpi=220)
    plt.close(fig)
    print("wrote", name + ".pdf")


def _load():
    with open(os.path.join(RES, "results.json")) as f:
        return json.load(f)


def _per_node_mean(per_seeds, key="f1"):
    """per_seeds: list[ {node: {acc/f1/auc/kappa, ...}} ]"""
    out = {}
    for n in NODES:
        vals = [s[n][key] for s in per_seeds if n in s]
        out[n] = (float(np.mean(vals)), float(np.std(vals)))
    return out


# ---------------------------------------------------------------------------
# Fig 1. System overview
# ---------------------------------------------------------------------------
def fig_system():
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    ax.set_xlim(0, 10.5); ax.set_ylim(0, 4); ax.axis("off")
    nodes = ["N1 — PTB-XL\nsite 0 (12-lead, 100 Hz)",
              "N2 — PTB-XL\nsite 1 (12-lead, 100 Hz)",
              "N3 — PTB-XL\nsite 2 (12-lead, 100 Hz)",
              "N4 — Chapman-Shaoxing\n(12-lead, 100 Hz)"]
    for i, h in enumerate(nodes):
        ax.add_patch(FancyBboxPatch((0.15, 3.3 - i * 0.85), 2.0, 0.65,
                                    boxstyle="round,pad=0.05",
                                    fc=NODE_PAL[i], ec="black", alpha=0.85))
        ax.text(1.15, 3.62 - i * 0.85, h, ha="center", va="center",
                fontsize=7, color="white", weight="bold")
        ax.add_patch(FancyArrowPatch((2.15, 3.62 - i * 0.85),
                                     (3.45, 3.62 - i * 0.85),
                                     arrowstyle="->", mutation_scale=10,
                                     color="black", lw=0.9))
    for i in range(4):
        ax.add_patch(FancyBboxPatch((3.55, 3.3 - i * 0.85), 1.6, 0.65,
                                    boxstyle="round,pad=0.04",
                                    fc="#EFEFEF", ec="black"))
        ax.text(4.35, 3.62 - i * 0.85,
                "Local SSL\n+ SQI estimate",
                ha="center", va="center", fontsize=6.5)
        ax.add_patch(FancyArrowPatch((5.15, 3.62 - i * 0.85),
                                     (6.55, 2.0),
                                     arrowstyle="->", mutation_scale=10,
                                     color="grey", lw=0.6))
    ax.add_patch(FancyBboxPatch((6.55, 1.4), 2.85, 1.25,
                                boxstyle="round,pad=0.06",
                                fc="#FBE4D5", ec="black"))
    ax.text(8.0, 2.0,
            "Server\nQuality-aware aggregation\n+ early-layer update damping\n+ aggregate-update perturbation",
            ha="center", va="center", fontsize=7, weight="bold")
    ax.add_patch(FancyArrowPatch((6.55, 2.1), (5.15, 3.05),
                                 arrowstyle="->", mutation_scale=10,
                                 color="black", lw=0.7, ls=":"))
    ax.text(5.6, 2.6, "damped\nupdate", fontsize=6,
            style="italic", ha="left")
    ax.add_patch(FancyBboxPatch((6.55, 0.1), 2.85, 1.1,
                                boxstyle="round,pad=0.06",
                                fc="#D6E8D5", ec="black"))
    ax.text(8.0, 0.55,
            "Downstream local linear probe\n5 super-classes\nNORM | MI | STTC | CD | HYP",
            ha="center", va="center", fontsize=7)
    ax.text(0.05, 3.97,
            "Raw-data locality boundary — raw ECG never leaves the acquisition node",
            fontsize=6.5, style="italic", color="#444444")
    ax.add_patch(plt.Rectangle((0.0, 0.0), 5.3, 4.0, fill=False,
                                ls="--", ec="#888888", lw=0.8))
    _save(fig, "fig1_system_overview")


# ---------------------------------------------------------------------------
# Fig 2. Measurement pipeline (signal flow)
# ---------------------------------------------------------------------------
def fig_pipeline():
    fig, ax = plt.subplots(figsize=(7.2, 1.4))
    ax.set_xlim(0, 12); ax.set_ylim(0, 1.6); ax.axis("off")
    boxes = ["ECG\nelectrodes",
             "Analog\nfront-end",
             "ADC\n(125–500 Hz)",
             "Filter +\nlead select",
             "Local SSL\nencoder $f_\\theta$",
             "SQI $q_k$\nestimator",
             "Federated\nserver",
             "Calibrated\nrepresentation"]
    n = len(boxes); w = 1.2; gap = (12 - n * w) / (n - 1)
    for i, b in enumerate(boxes):
        x = i * (w + gap)
        face = "#FBE4D5" if i in (4, 5, 6, 7) else "#E7F3FF"
        ax.add_patch(FancyBboxPatch((x, 0.4), w, 0.8,
                                    boxstyle="round,pad=0.04",
                                    fc=face, ec="black"))
        ax.text(x + w / 2, 0.8, b, ha="center", va="center", fontsize=7)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w, 0.8), (x + w + gap, 0.8),
                                          arrowstyle="->", mutation_scale=8,
                                          color="black", lw=0.7))
    ax.text(6, 0.05,
            "Local at acquisition node $\\longrightarrow$ shared at server boundary",
            ha="center", fontsize=7, style="italic", color="#444")
    _save(fig, "fig2_measurement_pipeline")


# ---------------------------------------------------------------------------
# Fig 3. Heterogeneity profile
# ---------------------------------------------------------------------------
def fig_heterogeneity(R):
    nodes = R["nodes"]
    pri = np.array([nodes[n]["prior"] for n in NODES])
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.4),
                              gridspec_kw=dict(width_ratios=[1.5, 1]))
    im = axes[0].imshow(pri, cmap="YlOrRd", vmin=0, vmax=0.7, aspect="auto")
    axes[0].set_xticks(range(5)); axes[0].set_xticklabels(CLASSES, rotation=10)
    axes[0].set_yticks(range(4)); axes[0].set_yticklabels(NODES)
    axes[0].set_title("(a) Class prevalence per node (PTB-XL super-classes)")
    for i in range(4):
        for j in range(5):
            axes[0].text(j, i, f"{pri[i,j]:.2f}", ha="center", va="center",
                          fontsize=6.5,
                          color="white" if pri[i,j] > 0.4 else "black")
    fig.colorbar(im, ax=axes[0], fraction=0.04, pad=0.02, label="prob.")
    sizes = [nodes[n]["n"] for n in NODES]
    sqis = [nodes[n]["sqi_mean"] for n in NODES]
    x = np.arange(4)
    ax2 = axes[1]; ax2b = ax2.twinx()
    ax2.bar(x - 0.18, sizes, 0.36, color="#0072B2", label="n")
    ax2b.bar(x + 0.18, sqis, 0.36, color="#D55E00", label="SQI")
    ax2.set_xticks(x); ax2.set_xticklabels(NODES)
    ax2.set_ylabel("Node size $n_k$", color="#0072B2")
    ax2b.set_ylabel("Mean SQI $\\bar{q}_k$", color="#D55E00")
    ax2.set_title("(b) Node size and mean signal quality")
    ax2.spines["right"].set_visible(True); ax2b.spines["right"].set_visible(True)
    ax2b.set_ylim(0, 1.0)
    _save(fig, "fig3_heterogeneity")


# ---------------------------------------------------------------------------
# Fig 4. Main results bar chart
# ---------------------------------------------------------------------------
def fig_main(R):
    main = R["results"]["main"]
    fig, ax = plt.subplots(figsize=(7.2, 2.8))
    x = np.arange(4); w = 0.12
    for i, m in enumerate(METHODS):
        if m not in main: continue
        means = []; stds = []
        for n in NODES:
            seeds = [s.get(n, {}).get("f1", float("nan")) for s in main[m]["per_seed"]]
            means.append(float(np.nanmean(seeds)))
            stds.append(float(np.nanstd(seeds)))
        ax.bar(x + (i - 3) * w, means, w, yerr=stds, capsize=2,
                color=PAL[m], label=LABEL[m])
    ax.set_xticks(x); ax.set_xticklabels(NODES)
    ax.set_ylabel("Macro-F1")
    ax.set_title("Diagnostic classification per acquisition node (3-seed mean $\\pm$ SD)")
    ax.set_ylim(0, 1.0)
    ax.grid(axis="y", alpha=0.3)
    ax.legend(ncol=4, frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.15), fontsize=6.5)
    _save(fig, "fig4_main_results")


# ---------------------------------------------------------------------------
# Fig 5. Convergence
# ---------------------------------------------------------------------------
def fig_conv(R):
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    main = R["results"]["main"]
    for m in ["fedavg", "fedprox", "scaffold", "fedbn", "ours"]:
        if m not in main or "history_last_seed" not in main[m]:
            continue
        h = main[m]["history_last_seed"]
        ax.plot(h["round"], h["avg_loss"], marker="o", ms=3, lw=1.2,
                label=LABEL[m], color=PAL[m])
    ax.set_xlabel("Communication round")
    ax.set_ylabel("Avg. contrastive loss")
    ax.set_title("Pretraining convergence")
    ax.grid(alpha=0.3); ax.legend(frameon=False, fontsize=6.5)
    _save(fig, "fig5_convergence")


# ---------------------------------------------------------------------------
# Fig 6. Cross-node consistency — heatmap + Bland-Altman style
# ---------------------------------------------------------------------------
def fig_consistency(R):
    """For each method, compute per-node mean F1 across seeds and treat
    seeds as raters → use ICC across nodes (handled in metrics.py).
    Display CV (coefficient of variation) of per-node F1 as a heatmap."""
    main = R["results"]["main"]
    M = np.zeros((len(METHODS), 4))
    cv = []
    for i, m in enumerate(METHODS):
        if m not in main: continue
        for j, n in enumerate(NODES):
            v = [s.get(n, {}).get("f1", float("nan"))
                 for s in main[m]["per_seed"]]
            M[i, j] = float(np.nanmean(v))
        cv.append(float(np.nanstd(M[i]) / max(np.nanmean(M[i]), 1e-6)))
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6),
                              gridspec_kw=dict(width_ratios=[1.7, 1]))
    im = axes[0].imshow(M, cmap="viridis", vmin=0, vmax=1, aspect="auto")
    axes[0].set_xticks(range(4)); axes[0].set_xticklabels(NODES)
    axes[0].set_yticks(range(len(METHODS)));
    axes[0].set_yticklabels([LABEL[m] for m in METHODS], fontsize=6.5)
    axes[0].set_title("(a) Macro-F1 across nodes")
    for i in range(len(METHODS)):
        for j in range(4):
            axes[0].text(j, i, f"{M[i,j]:.2f}", ha="center", va="center",
                         fontsize=6, color="white" if M[i,j] < 0.5 else "black")
    fig.colorbar(im, ax=axes[0], fraction=0.03, pad=0.02, label="F1")

    # right: inter-node CV
    axes[1].barh(range(len(METHODS)), cv, color=[PAL[m] for m in METHODS])
    axes[1].set_yticks(range(len(METHODS)))
    axes[1].set_yticklabels([LABEL[m] for m in METHODS], fontsize=6.5)
    axes[1].invert_yaxis()
    axes[1].set_xlabel("Inter-node CV of F1 ($\\downarrow$ better)")
    axes[1].set_title("(b) Cross-node consistency")
    axes[1].grid(axis="x", alpha=0.3)
    _save(fig, "fig6_consistency")


# ---------------------------------------------------------------------------
# Fig 7. Robustness (fs, leads, snr)
# ---------------------------------------------------------------------------
def fig_robust(R):
    rob = R["results"].get("robust", {})
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.4))
    titles = [("fs", "Sampling rate (Hz)"), ("leads", "# leads"),
              ("snr", "SNR (dB)")]
    for ax, (axis, xl) in zip(axes, titles):
        for algo in ("fedavg", "ours"):
            if algo not in rob.get(axis, {}): continue
            seed_data = list(rob[axis][algo].values())[0]
            curve = seed_data["curve"]
            xs = sorted(curve.keys(), key=lambda k: float(k))
            f1m = [float(np.mean([curve[k][n]["f1"] for n in NODES]))
                   for k in xs]
            ax.plot([float(k) for k in xs], f1m, "-o", ms=3, lw=1.2,
                     label=LABEL[algo], color=PAL[algo])
        ax.set_xlabel(xl); ax.set_ylabel("Macro-F1")
        ax.grid(alpha=0.3); ax.legend(frameon=False, fontsize=6.5)
    axes[0].set_title("(a) $f_s$ robustness")
    axes[1].set_title("(b) Lead robustness")
    axes[2].set_title("(c) SNR robustness")
    _save(fig, "fig7_robustness")


# ---------------------------------------------------------------------------
# Fig 8. Privacy-utility / measurement uncertainty
# ---------------------------------------------------------------------------
def fig_privacy(R):
    pr = R["results"].get("privacy", {})
    if not pr: return
    sigmas = sorted([float(k) for k in pr.keys()])
    f1m = []; acc = []
    for s in sigmas:
        d = pr[str(s)]
        f1m.append(float(np.mean([d[n]["f1"] for n in NODES])))
        acc.append(float(np.mean([d[n]["acc"] for n in NODES])))
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    ax.plot(sigmas, acc, "-o", color=PAL["fedavg"], lw=1.2, label="Accuracy")
    ax.plot(sigmas, f1m, "-s", color=PAL["ours"], lw=1.2, label="Macro-F1")
    ax.set_xscale("symlog", linthresh=1e-4)
    ax.set_xlabel(r"DP noise / uncertainty multiplier $\sigma$")
    ax.set_ylabel("Federation-wide score")
    ax.set_title("Privacy–utility / measurement-uncertainty trade-off")
    ax.grid(alpha=0.3); ax.legend(frameon=False, fontsize=7)
    _save(fig, "fig8_privacy")


# ---------------------------------------------------------------------------
# Fig 9. Ablation
# ---------------------------------------------------------------------------
def fig_ablation(R):
    abl = R["results"].get("ablation", {})
    if not abl: return
    order = ["full", "noWeight", "noDamp", "noProx", "noDP"]
    labels = ["Full", "w/o quality\nweight", "w/o early-layer\ncalibration",
              "w/o prox.\nterm", "w/o uncertainty\ninjection"]
    f1m = []
    for v in order:
        if v not in abl: continue
        d = abl[v]
        f1m.append(float(np.mean([d[n]["f1"] for n in NODES])))
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    ax.bar(range(len(f1m)), f1m, color=PAL["ours"])
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels[:len(f1m)], fontsize=6.5)
    ax.set_ylabel("Federation-wide macro-F1")
    ax.set_title("Component ablation")
    ax.grid(axis="y", alpha=0.3)
    _save(fig, "fig9_ablation")


# ---------------------------------------------------------------------------
# Table 1: per-method per-node Acc/F1/AUC mean ± SD
# ---------------------------------------------------------------------------
def table_main(R):
    main = R["results"]["main"]
    lines = []
    lines.append(r"\begin{tabular}{l" + "ccc" * 5 + "}")
    lines.append(r"\toprule")
    lines.append(r"Method & " + " & ".join(
        f"\\multicolumn{{3}}{{c}}{{{n}}}" for n in NODES) +
        r" & \multicolumn{3}{c}{Macro avg} \\")
    cmid = " ".join(f"\\cmidrule(lr){{{2+3*i}-{4+3*i}}}" for i in range(5))
    lines.append(cmid)
    lines.append(" & " + " & ".join(["Acc & F1 & AUC"] * 5) + r"\\")
    lines.append(r"\midrule")
    for m in METHODS:
        if m not in main: continue
        cells = []; accs = []; f1s = []; aucs = []
        for n in NODES:
            seeds = main[m]["per_seed"]
            a = [s.get(n, {}).get("acc", float("nan")) for s in seeds]
            f = [s.get(n, {}).get("f1",  float("nan")) for s in seeds]
            u = [s.get(n, {}).get("auc", float("nan")) for s in seeds]
            cells.extend([f"{np.nanmean(a):.3f}", f"{np.nanmean(f):.3f}",
                           f"{np.nanmean(u):.3f}"])
            accs.append(np.nanmean(a)); f1s.append(np.nanmean(f));
            aucs.append(np.nanmean(u))
        cells.extend([f"{np.nanmean(accs):.3f}", f"{np.nanmean(f1s):.3f}",
                      f"{np.nanmean(aucs):.3f}"])
        lines.append(LABEL[m].replace("&", r"\&") + " & " + " & ".join(cells) + r" \\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    with open(os.path.join(OUT, "tab1_main_f1.tex"), "w") as f:
        f.write("\n".join(lines))
    print("wrote tab1_main_f1.tex")


# ---------------------------------------------------------------------------
def main():
    R = _load()
    fig_system()
    fig_pipeline()
    fig_heterogeneity(R)
    fig_main(R)
    try:
        fig_conv(R)
    except Exception as e:
        print(f"  skip fig_conv (V11-only format): {e}")
    fig_consistency(R)
    fig_robust(R)
    # fig_privacy and fig_ablation now generated by make_v12_figs.py
    # (V12-format-compatible). Skip the V11-mode versions here to avoid
    # KeyError under the new results.json layout.
    print("All figures (V11-mode subset) written to", OUT)


if __name__ == "__main__":
    main()
