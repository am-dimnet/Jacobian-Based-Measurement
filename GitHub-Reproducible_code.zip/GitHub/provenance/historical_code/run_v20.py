"""V20 runner — reviewer-driven re-run.

Differences vs V12:
  * 5 random seeds (vs 3) on main + ablation + perturbation sweep
  * Per-record paired predictions persisted to .npz (enables real
    Bland-Altman scatter, full 4x4 kappa matrix, ICC CI, etc.)
  * Component ablation REPEATED at sigma=1e-2 (the operating point
    where ours matches FedAvg) — checks whether components help
    at the better operating point, not just at default sigma=1e-3
  * Saves trained encoder of seed-0 for later Jacobian closed-form
    sigma->u_sigma computation
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch
import torch.nn.functional as F

from data_real import (load_ptbxl, load_chapman, build_nodes, patient_split,
                       class_prior, SUPERCLASSES, N_CLASSES)
from models import ECGEncoder, ProjHead, ClsHead
from fed_algos import FederatedTrainer
from metrics import cls_metrics
from paired_eval import (paired_predictions, paired_consistency_metrics,
                          DEVICE_CHAINS)
from run_v12 import (embed_gpu, train_linear_probe, make_node_gpu_loaders,
                     train_one, split_node, evaluate_full)


def evaluate_full_with_preds(enc_or_dict, nodes_split, device, tag,
                             save_root=None):
    """Like run_v12.evaluate_full but ALSO saves per-record (pred,proba)
    on each device chain to .npz under save_root/<tag>/<node>.npz."""
    from run_v12 import embed_gpu, train_linear_probe
    per_node = {}
    paired = {}
    pred_records = {}
    for nk, sp in nodes_split.items():
        # local probe to align with the V12 per-method routing
        if isinstance(enc_or_dict, dict):
            enc = enc_or_dict[nk]
        else:
            enc = enc_or_dict
        Ztr = embed_gpu(enc, sp["Xtr"], device)
        Zte = embed_gpu(enc, sp["Xte"], device)
        clf = train_linear_probe(Ztr, sp["ytr"], K=N_CLASSES, device=device)
        Zte_t = torch.from_numpy(Zte).float().to(device)
        with torch.no_grad():
            logits = clf(Zte_t)
            proba = torch.softmax(logits, -1).cpu().numpy()
            pred = proba.argmax(-1)
        m = cls_metrics(sp["yte"], pred, proba, N_CLASSES)
        per_node[nk] = {**m, "n_test": int(len(sp["yte"]))}
        # paired predictions
        pred_d, proba_d, y = paired_predictions(
            enc, clf, sp["Xte"], sp["yte"], device, chains=DEVICE_CHAINS)
        paired[nk] = paired_consistency_metrics(pred_d, proba_d)
        # persist per-record
        pred_records[nk] = {"y": np.asarray(y, dtype=np.int8),
                            "proba_d": proba_d, "pred_d": pred_d,
                            "proba_clean": proba.astype(np.float32)}
    if save_root is not None:
        out_dir = os.path.join(save_root, tag)
        os.makedirs(out_dir, exist_ok=True)
        for nk, rec in pred_records.items():
            np.savez_compressed(os.path.join(out_dir, f"{nk}.npz"),
                                y=rec["y"], proba_clean=rec["proba_clean"],
                                **{f"proba_{cid}": rec["proba_d"][cid]
                                    for cid in rec["proba_d"]},
                                **{f"pred_{cid}":  rec["pred_d"][cid]
                                    for cid in rec["pred_d"]})
    return per_node, paired


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper20_TIM/results")
    ap.add_argument("--rounds", type=int, default=30)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=1024)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seeds", type=int, nargs="+",
                    default=[20260601, 20260602, 20260603, 20260604, 20260605])
    ap.add_argument("--max-per-node", type=int, default=4000)
    ap.add_argument("--max-chapman", type=int, default=6000)
    ap.add_argument("--stage", default="all",
                    help="all|main|ablation_1e3|ablation_1e2|priv|ckpt")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    preds_dir = os.path.join(args.out, "preds")
    ckpt_dir  = os.path.join(args.out, "ckpts")
    os.makedirs(preds_dir, exist_ok=True); os.makedirs(ckpt_dir, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device, "rounds:", args.rounds, "seeds:", args.seeds)

    p = load_ptbxl(); c = load_chapman()
    nodes = build_nodes(p, c, max_chapman_n=args.max_chapman,
                         max_per_node=args.max_per_node)
    # Load any existing results_v20.json so successive --stage invocations
    # merge rather than overwrite previous stages.
    summary_path = os.path.join(args.out, "results_v20.json")
    if os.path.exists(summary_path):
        try:
            summary = json.load(open(summary_path))
            summary.setdefault("results", {})
            print(f"merging into existing {summary_path} with keys {list(summary['results'].keys())}")
        except Exception:
            summary = None
    else:
        summary = None
    if summary is None:
        summary = {"config": vars(args),
                    "nodes": {nk: {"source": v["source"], "n": int(len(v["y"])),
                                    "prior": class_prior(v["y"]).tolist(),
                                    "sqi_mean": float(v["sqi_q"].mean())}
                               for nk, v in nodes.items()},
                    "results": {}}
    t0 = time.time()

    # ---- MAIN: 7 methods, 5 seeds, with per-record persistence ----
    if args.stage in ("all", "main"):
        out_main = {}
        for algo in ["local", "fedavg", "fedprox", "scaffold", "fedbn",
                     "centralised", "ours"]:
            out_main[algo] = {"per_seed": [], "paired_per_seed": []}
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                print(f"\n>>> MAIN {algo} seed={seed}")
                nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
                enc = train_one(algo, nodes_split, args, device, print)
                tag = f"main/{algo}/seed{seed}"
                per_node, paired = evaluate_full_with_preds(
                    enc, nodes_split, device, tag, save_root=preds_dir)
                out_main[algo]["per_seed"].append(per_node)
                out_main[algo]["paired_per_seed"].append(paired)
                for nk, m in per_node.items():
                    print(f"  {nk}: acc={m['acc']:.3f} f1={m['f1']:.3f} "
                           f"auc={m['auc']:.3f}")
                if seed == args.seeds[0] and not isinstance(enc, dict):
                    torch.save(enc.state_dict(),
                               os.path.join(ckpt_dir, f"{algo}_s{seed}.pt"))
        summary["results"]["main"] = out_main
        with open(os.path.join(args.out, "results_v20.json"), "w") as f:
            json.dump(summary, f, indent=2)
        print(f"main done {time.time()-t0:.0f}s")

    # ---- ABLATION at sigma=1e-3 (default) AND sigma=1e-2 (operating point) ----
    if args.stage in ("all", "ablation_1e3", "ablation_1e2"):
        for sig_tag, sigma_v in (("1e-3", 1e-3), ("1e-2", 1e-2)):
            if args.stage == "ablation_1e3" and sig_tag != "1e-3": continue
            if args.stage == "ablation_1e2" and sig_tag != "1e-2": continue
            abl = {}
            variants = [
                ("full",     dict(algo="ours",   prox_mu=0.01, dp_sigma=sigma_v, damping_gamma=0.6)),
                ("noWeight", dict(algo="fedavg", prox_mu=0.01, dp_sigma=sigma_v, damping_gamma=0.6)),
                ("noDamp",   dict(algo="ours",   prox_mu=0.01, dp_sigma=sigma_v, damping_gamma=1.0)),
                ("noDP",     dict(algo="ours",   prox_mu=0.01, dp_sigma=0.00,    damping_gamma=0.6)),
            ]
            for vname, kw in variants:
                kw_local = dict(kw)
                algo = kw_local.pop("algo")
                abl[vname] = {"per_seed": [], "paired_per_seed": []}
                for seed in args.seeds:
                    torch.manual_seed(seed); np.random.seed(seed)
                    print(f"\n>>> ABL[{sig_tag}] {vname} seed={seed}")
                    nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
                    enc = train_one(algo, nodes_split, args, device, print, **kw_local)
                    tag = f"abl_{sig_tag}/{vname}/seed{seed}"
                    per_node, paired = evaluate_full_with_preds(
                        enc, nodes_split, device, tag, save_root=preds_dir)
                    abl[vname]["per_seed"].append(per_node)
                    abl[vname]["paired_per_seed"].append(paired)
            summary["results"][f"ablation_{sig_tag}"] = abl
            with open(os.path.join(args.out, "results_v20.json"), "w") as f:
                json.dump(summary, f, indent=2)
            print(f"ablation@{sig_tag} done {time.time()-t0:.0f}s")

    # ---- Perturbation sweep, 5 seeds, with per-record persistence ----
    if args.stage in ("all", "priv"):
        pr = {}
        for sigma in [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]:
            pr[str(sigma)] = {"per_seed": [], "paired_per_seed": []}
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                print(f"\n>>> PRIV sigma={sigma} seed={seed}")
                nodes_split = {nk: split_node(n, seed) for nk, n in nodes.items()}
                enc = train_one("ours", nodes_split, args, device, print,
                                 prox_mu=0.01, dp_sigma=sigma,
                                 damping_gamma=0.6)
                tag = f"priv/sigma{sigma}/seed{seed}"
                per_node, paired = evaluate_full_with_preds(
                    enc, nodes_split, device, tag, save_root=preds_dir)
                pr[str(sigma)]["per_seed"].append(per_node)
                pr[str(sigma)]["paired_per_seed"].append(paired)
        summary["results"]["privacy"] = pr
        with open(os.path.join(args.out, "results_v20.json"), "w") as f:
            json.dump(summary, f, indent=2)

    with open(os.path.join(args.out, "results_v20.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nTOTAL TIME: {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
