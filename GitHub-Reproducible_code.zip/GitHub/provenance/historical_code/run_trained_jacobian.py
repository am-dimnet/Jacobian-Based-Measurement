"""V23 unification: re-measure the trained encoder's R using the SAME
methodology as the multi-architecture sweep (s_small=1e-5, n_mc=24),
so we can compare apples to apples and remove the V12 R=88.5 outlier."""
from __future__ import annotations
import argparse, json, os
import numpy as np
import torch

from data_real import load_ptbxl, load_chapman
from models import ECGEncoder
from multi_encoder_sigma_map import evaluate_one, _count_params


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="/root/autodl-tmp/Paper20_TIM/results/ckpts/ours_s20260601.pt")
    ap.add_argument("--out",  default="/root/autodl-tmp/Paper20_TIM/results/trained_encoder_R.json")
    ap.add_argument("--n-mc", type=int, default=24)
    ap.add_argument("--n-test", type=int, default=256)
    ap.add_argument("--sigmas", type=float, nargs="+",
                    default=[1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2])
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    summary = {"config": vars(args), "encoders": {}}

    for ds in ("ptbxl", "chapman"):
        if ds == "ptbxl":
            p = load_ptbxl(); X = p["X"][:args.n_test].astype(np.float32)
            std_mV = 0.12
        else:
            c = load_chapman(); X = c["X"][:args.n_test].astype(np.float32)
            std_mV = 0.15
        Xt = torch.from_numpy(X).to(device)
        Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)

        # Trained ours encoder (from V20 main run)
        enc = ECGEncoder().to(device)
        sd = torch.load(args.ckpt, map_location=device)
        enc.load_state_dict(sd, strict=False)
        enc.eval()
        r_tr = evaluate_one(enc, Xt, std_mV, args.sigmas,
                             n_mc=args.n_mc, s_small=1e-5)
        # Random init of same architecture for reference
        enc_rand = ECGEncoder().to(device); enc_rand.eval()
        torch.manual_seed(0)
        for m in enc_rand.modules():
            if isinstance(m, torch.nn.Conv1d) or isinstance(m, torch.nn.Linear):
                torch.nn.init.xavier_uniform_(m.weight)
                if m.bias is not None: torch.nn.init.zeros_(m.bias)
        r_ri = evaluate_one(enc_rand, Xt, std_mV, args.sigmas,
                             n_mc=args.n_mc, s_small=1e-5)
        n_params = _count_params(enc)
        summary["encoders"].setdefault("ours_trained", {})[ds] = [r_tr]
        summary["encoders"].setdefault("ours_random",  {})[ds] = [r_ri]
        summary["encoders"]["ours_trained"][ds][0]["n_params"] = n_params
        summary["encoders"]["ours_random" ][ds][0]["n_params"] = n_params
        print(f"{ds}: TRAINED R={r_tr['R']:.2f}   RANDOM R={r_ri['R']:.2f}   "
              f"n_params={n_params/1e6:.3f}M", flush=True)

    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)
    print("saved", args.out)


if __name__ == "__main__":
    main()
