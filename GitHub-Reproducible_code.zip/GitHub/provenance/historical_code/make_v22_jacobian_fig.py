"""Generate Fig 12 (V22): cross-architecture Jacobian-map validation.

Two-panel figure showing:
  (a) Jacobian ratio R per (architecture, dataset, seed), with seed
      error bars. R is reproducible across seeds, scales with
      architecture, and is dataset-independent.
  (b) MC/CF ratio vs σ for each architecture (PTB-XL, mean over 3
      seeds). The vertical axis is the multiplicative discrepancy
      between the closed-form sensitivity (Eq.7) and the Monte-Carlo
      output-drift estimate. We show the trained-encoder reference
      from V20 (R=88.5, ratio drops to ~3 at σ=1e-3) as a horizontal
      band to make explicit that training reduces this discrepancy.
"""
from __future__ import annotations
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")

d = json.load(open(os.path.join(RES, "multi_encoder_sigma_map.json")))
ENC_ORDER = ["small_BN", "base_BN", "base_noBN", "large_BN"]
ENC_LABEL = {"small_BN":"small\nBN", "base_BN":"base\nBN",
              "base_noBN":"base\nno-BN", "large_BN":"large\nBN"}
DATASETS = ["ptbxl", "chapman"]
DS_COLOR = {"ptbxl":"#4c72b0", "chapman":"#dd8452"}

fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.2))

# ---- Panel (a): R per architecture × dataset ----
ax = axes[0]
x = np.arange(len(ENC_ORDER))
w = 0.36
for i, ds in enumerate(DATASETS):
    means, sds, params = [], [], []
    for arch in ENC_ORDER:
        if ds not in d["encoders"][arch]:
            means.append(np.nan); sds.append(0); params.append(np.nan); continue
        Rs = [r["R"] for r in d["encoders"][arch][ds]]
        means.append(np.mean(Rs)); sds.append(np.std(Rs, ddof=1) if len(Rs)>1 else 0)
        params.append(d["encoders"][arch][ds][0]["n_params"] / 1e6)
    ax.bar(x + (i - 0.5) * w, means, w, yerr=sds, capsize=3,
           color=DS_COLOR[ds], label=ds.upper())
for j, arch in enumerate(ENC_ORDER):
    p = d["encoders"][arch]["ptbxl"][0]["n_params"] / 1e6
    ax.text(j, -8, f"{p:.2f}\,M", ha="center", fontsize=7, color="grey")
ax.set_xticks(x); ax.set_xticklabels([ENC_LABEL[a] for a in ENC_ORDER], fontsize=8)
ax.set_ylabel("$R = \\|J_\\theta\\|_F / \\|J_x\\|_F$")
ax.set_title("(a) Jacobian ratio $R$ across encoders and datasets")
ax.set_ylim(0, 100)
ax.grid(axis="y", alpha=0.3)
ax.legend(fontsize=8, loc="upper left")

# ---- Panel (b): MC/CF ratio vs σ (PTB-XL, mean over seeds) ----
ax = axes[1]
arch_colors = {"small_BN":"#1f77b4","base_BN":"#ff7f0e",
                "base_noBN":"#2ca02c","large_BN":"#d62728"}
for arch in ENC_ORDER:
    if "ptbxl" not in d["encoders"][arch]: continue
    sigmas = sorted(set(r["sigma"]
                          for s in d["encoders"][arch]["ptbxl"]
                          for r in s["results"]))
    ratios_mean, ratios_sd = [], []
    for sg in sigmas:
        vals = []
        for s in d["encoders"][arch]["ptbxl"]:
            for r in s["results"]:
                if r["sigma"] == sg:
                    vals.append(r["u_sigma_uV_MC"] /
                                  max(r["u_sigma_uV_CF"], 1e-12))
        ratios_mean.append(np.mean(vals))
        ratios_sd.append(np.std(vals, ddof=1) if len(vals)>1 else 0)
    ax.errorbar(sigmas, ratios_mean, yerr=ratios_sd, marker="o",
                 lw=1.5, ms=4, capsize=2,
                 color=arch_colors[arch], label=ENC_LABEL[arch].replace("\n"," "))
# Trained encoder reference (V20 sigma_mv_v20.json), if available
sm_path = os.path.join(RES, "sigma_mv_v20.json")
if os.path.exists(sm_path):
    sm = json.load(open(sm_path))
    s_tr = [r["sigma_param"] for r in sm["results"]]
    rt   = [r["u_sigma_uV_MC"] / max(r["u_sigma_uV_closed_form"], 1e-12)
             for r in sm["results"]]
    ax.plot(s_tr, rt, "k*-", ms=8, lw=1.4,
            label="base_BN (trained)")
ax.axhline(1.0, color="grey", ls=":", lw=0.8)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("$\\sigma$ (aggregate-update perturbation scale)")
ax.set_ylabel("MC $/$ closed-form ratio")
ax.set_title("(b) Discrepancy MC$/$CF vs $\\sigma$ (PTB-XL, 3 inits)")
ax.legend(fontsize=7.5)
ax.grid(alpha=0.3, which="both")

plt.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(os.path.join(OUT, f"fig12_jacobian_validation.{ext}"),
                 dpi=300, bbox_inches="tight")
plt.close(fig)
print("wrote", os.path.join(OUT, "fig12_jacobian_validation.pdf"))
