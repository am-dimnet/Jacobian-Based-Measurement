"""V23: Hutchinson-style direct estimation of ||J_θ||_F^2 and ||J_x||_F^2,
to give R a definition that does NOT depend on a finite-noise probe.

||J||_F^2 = E_v [||J^T v||_2^2] for v ~ N(0, I).

Implementation: for each input x_i and random output-direction v_k,
compute the Jacobian-vector product J^T v via a single backward pass on
<f_θ(x_i), v_k>, take the squared norm of the gradient.

We compare:
  - R_true   = sqrt( E[||J_θ||_F^2] / E[||J_x||_F^2] )   (Hutchinson)
  - R_probe  = d_param(s_small) / d_input(s_small)        (V22 approach)
"""
from __future__ import annotations
import argparse, json, os
import numpy as np
import torch

from data_real import load_ptbxl, load_chapman
from models import ECGEncoder


def hutchinson_F2(enc, x_batch, target="theta", K=24, device="cuda"):
    """Estimate ||J||_F^2 averaged over the input batch.

    target="theta": compute parameter Jacobian Frobenius norm squared.
    target="x":     compute input Jacobian Frobenius norm squared.
    """
    enc.eval()
    f2 = 0.0
    count = 0
    for x_i in x_batch:
        x_i = x_i.unsqueeze(0).requires_grad_(target == "x")
        for _ in range(K):
            z = enc(x_i)
            v = torch.randn_like(z); v = v / v.norm()  # unit-norm direction
            scalar = (z * v).sum()
            if target == "theta":
                grads = torch.autograd.grad(scalar, enc.parameters(),
                                              retain_graph=False, create_graph=False)
                g2 = sum(g.pow(2).sum().item() for g in grads)
            else:
                grad_x = torch.autograd.grad(scalar, x_i,
                                              retain_graph=False, create_graph=False)[0]
                g2 = grad_x.pow(2).sum().item()
            f2 += g2 * (z.numel())  # rescale: ||J^T v||^2 with v unit -> per output dim
            count += 1
    return f2 / count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="/root/autodl-tmp/Paper20_TIM/results/ckpts/ours_s20260601.pt")
    ap.add_argument("--out",  default="/root/autodl-tmp/Paper20_TIM/results/hutchinson_R.json")
    ap.add_argument("--n-batch", type=int, default=32)
    ap.add_argument("--K", type=int, default=12)
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    p = load_ptbxl()
    X = p["X"][:args.n_batch].astype(np.float32)
    Xt = torch.from_numpy(X).to(device)
    Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)

    # Trained ours-encoder
    enc_tr = ECGEncoder().to(device).eval()
    enc_tr.load_state_dict(torch.load(args.ckpt, map_location=device), strict=False)
    F2_theta_tr = hutchinson_F2(enc_tr, Xt, target="theta", K=args.K)
    F2_x_tr     = hutchinson_F2(enc_tr, Xt, target="x",     K=args.K)
    R_tr = float(np.sqrt(F2_theta_tr / max(F2_x_tr, 1e-12)))

    # Random init
    enc_ri = ECGEncoder().to(device).eval()
    F2_theta_ri = hutchinson_F2(enc_ri, Xt, target="theta", K=args.K)
    F2_x_ri     = hutchinson_F2(enc_ri, Xt, target="x",     K=args.K)
    R_ri = float(np.sqrt(F2_theta_ri / max(F2_x_ri, 1e-12)))

    print(f"Trained:   F2_theta={F2_theta_tr:.4e}  F2_x={F2_x_tr:.4e}  R_true={R_tr:.2f}")
    print(f"Rand init: F2_theta={F2_theta_ri:.4e}  F2_x={F2_x_ri:.4e}  R_true={R_ri:.2f}")

    json.dump({"trained": {"F2_theta": F2_theta_tr, "F2_x": F2_x_tr, "R_true": R_tr},
                "random":  {"F2_theta": F2_theta_ri, "F2_x": F2_x_ri, "R_true": R_ri},
                "config": vars(args)},
              open(args.out, "w"), indent=2)


if __name__ == "__main__":
    main()
