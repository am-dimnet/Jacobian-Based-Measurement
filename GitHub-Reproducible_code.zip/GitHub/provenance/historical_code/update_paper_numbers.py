"""Update specific numerical claims in main.tex from results_v20.json.

Reads:  results/results_v20.json
Writes: prints summary, optionally updates main.tex with --apply

Substitutions (V19 -> V20):
  Local-only F1            0.393 -> new
  Centralised F1           0.428 -> new
  FedAvg F1                0.316 -> new
  FedProx F1               0.315 -> new
  SCAFFOLD F1              0.287 -> new
  FedBN F1                 0.304 -> new
  ours @ sigma=1e-3 F1     0.274 -> new
  ours @ sigma=1e-2 F1     0.316 -> new
"""
from __future__ import annotations
import json, os, re, sys
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = json.load(open(os.path.join(ROOT, "results", "results_v20.json")))
NODES = ["N1","N2","N3","N4"]


def fed_avg(method_key, stages_list):
    """Federation-wide mean macro-F1 across all (seed, node) pairs."""
    vals = []
    for s in stages_list:
        for n in NODES:
            if n in s and "f1" in s[n] and not np.isnan(s[n]["f1"]):
                vals.append(s[n]["f1"])
    if not vals: return float("nan"), float("nan")
    return float(np.mean(vals)), float(np.std(vals, ddof=1))


main = R["results"]["main"]
print("=== Federation-average macro-F1 (5 seeds) ===")
for m in ["local","fedavg","fedprox","scaffold","fedbn","centralised","ours"]:
    if m not in main: continue
    mu, sd = fed_avg(m, main[m]["per_seed"])
    print(f"  {m:12s}  {mu:.3f} +/- {sd:.3f}")

priv = R["results"].get("privacy", {})
if "0.01" in priv:
    mu, sd = fed_avg("priv01", priv["0.01"]["per_seed"])
    print(f"  ours@sigma1e-2 {mu:.3f} +/- {sd:.3f}  (perturbation sweep)")

abl_1e2 = R["results"].get("ablation_1e-2", {})
if abl_1e2:
    print("\n=== Ablation at sigma=1e-2 (5 seeds) ===")
    for v in abl_1e2:
        mu, sd = fed_avg(v, abl_1e2[v]["per_seed"])
        print(f"  {v:12s}  {mu:.3f} +/- {sd:.3f}")

print("\n=== Paired ICC (5 seeds) ===")
for m in ["local","fedavg","fedprox","scaffold","fedbn","centralised","ours"]:
    if m not in main: continue
    iccs = []
    for s in main[m].get("paired_per_seed", []):
        for n in NODES:
            v = s.get(n, {}).get("icc_proba_dom")
            if v is not None and not np.isnan(v): iccs.append(v)
    if iccs:
        print(f"  {m:12s}  ICC = {np.mean(iccs):+.3f} +/- {np.std(iccs, ddof=1):.3f}")

# u_sigma values
sig_path = os.path.join(ROOT, "results", "sigma_mv_v20.json")
if os.path.exists(sig_path):
    sm = json.load(open(sig_path))
    print("\n=== u_sigma map (closed-form, linear regime delineated) ===")
    print(f"  Jacobian ratio R = {sm['jacobian_ratio_R']:.4f}")
    for r in sm["results"]:
        flag = "linear" if r.get("linear_regime", True) else "NON-LINEAR"
        print(f"  sigma={r['sigma_param']:.1e}: u_sigma = {r['u_sigma_uV_closed_form']:.2f} uV [{flag}]")
