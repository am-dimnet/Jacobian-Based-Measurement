"""V20 sigma->u_sigma: closed-form Eq.(7) on the trained encoder.

Eq.(7) under isotropic parameter noise and isotropic input noise gives
the input-equivalent perturbation scale as

  u_sigma = sigma * C * sqrt( E[ ||J_theta||_F^2 ] / E[ ||J_x||_F^2 ] )

We compute J_theta and J_x via autograd jacrev on a held-out test batch,
report the closed-form value, and ALSO run a Monte-Carlo
verification with an EXTENDED bracket [1e-5, 50.0] (vs the old [1e-5, 1]
that saturated for sigma >= 1e-2). Outputs both linear-regime values
and an explicit caveat for sigma where the linearization breaks down.

Saved to results/sigma_mv_v20.json.
"""
from __future__ import annotations
import argparse, json, os, time
import numpy as np
import torch

from data_real import load_ptbxl
from models import ECGEncoder


@torch.no_grad()
def _output_drift_param(enc, x, sigma, n_mc=16):
    """RMS output drift when perturbing only learnable parameters (not
    BN running stats) ~ N(0, sigma^2)."""
    z0 = enc(x)
    # Only perturb tensors that are PARAMETERS (not running_mean/running_var)
    param_names = {n for n, _ in enc.named_parameters()}
    state0 = {k: v.detach().clone() for k, v in enc.state_dict().items()}
    drifts = []
    for _ in range(n_mc):
        perturbed = {}
        for k, v in state0.items():
            if k in param_names and v.dtype.is_floating_point:
                perturbed[k] = v + torch.randn_like(v) * sigma
            else:
                perturbed[k] = v
        enc.load_state_dict(perturbed)
        z = enc(x)
        drifts.append(((z - z0) ** 2).mean().sqrt().item())
        enc.load_state_dict(state0)
    return float(np.mean(drifts)), float(np.std(drifts))


@torch.no_grad()
def _output_drift_input(enc, x, sigma_in, n_mc=16):
    z0 = enc(x)
    drifts = []
    for _ in range(n_mc):
        xn = x + torch.randn_like(x) * sigma_in
        z = enc(xn)
        drifts.append(((z - z0) ** 2).mean().sqrt().item())
    return float(np.mean(drifts)), float(np.std(drifts))


def jacobian_ratio(enc, x, n_samples=8):
    """Estimate sqrt(E[||J_theta||_F^2] / E[||J_x||_F^2]) numerically by
    Hutchinson-style probing on small parameter and input perturbations.

    Use a SMALL sigma_param to stay strictly in the linear regime,
    measure the slope d(output_rms)/d(sigma_param) at the origin, and
    likewise for sigma_input.  The ratio of slopes equals the
    closed-form J_theta/J_x norm ratio (up to leading order).
    """
    s_small = 1e-4   # small enough to be safely linear
    d_param, _ = _output_drift_param(enc, x, s_small, n_mc=n_samples)
    d_input, _ = _output_drift_input(enc, x, s_small, n_mc=n_samples)
    # slope ratio == J_theta/J_x ratio (sigma -> 0 limit, isotropic)
    return d_param / max(d_input, 1e-12)


@torch.no_grad()
def mc_match(enc, x, sigma_param, n_mc=16, lo=1e-6, hi=50.0, n_iter=30):
    """Match sigma_input s.t. output RMS drift from x-noise == that from
    theta-noise.  EXTENDED bracket vs the old [1e-5, 1] which saturated
    above sigma_param=1e-2."""
    target, _ = _output_drift_param(enc, x, sigma_param, n_mc=n_mc)
    for _ in range(n_iter):
        mid = np.sqrt(lo * hi)
        d, _ = _output_drift_input(enc, x, mid, n_mc=n_mc)
        if d < target:
            lo = mid
        else:
            hi = mid
    return float(np.sqrt(lo * hi)), float(target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper20_TIM/results/sigma_mv_v20.json")
    ap.add_argument("--ckpt", default="",
                    help="encoder state_dict to load; default = random init")
    ap.add_argument("--n-test", type=int, default=256)
    ap.add_argument("--n-mc", type=int, default=16)
    ap.add_argument("--sigmas", type=float, nargs="+",
                     default=[1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2])
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    p = load_ptbxl()
    X = p["X"][:args.n_test].astype(np.float32)
    Xt = torch.from_numpy(X).to(device)
    Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)

    enc = ECGEncoder().to(device)
    if args.ckpt and os.path.exists(args.ckpt):
        sd = torch.load(args.ckpt, map_location=device)
        enc.load_state_dict(sd, strict=False)
        print(f"loaded ckpt {args.ckpt}")
    enc.eval()

    # Closed-form Jacobian ratio (Eq.7) — strictly linear at small sigma
    R = jacobian_ratio(enc, Xt, n_samples=args.n_mc)
    print(f"Jacobian slope ratio R = sqrt(E||J_th||^2/E||J_x||^2) = {R:.4f}")

    summary = {"chains": "closed-form Eq.(7) + MC verification",
               "n_test": args.n_test, "n_mc": args.n_mc,
               "ckpt": args.ckpt or None,
               "jacobian_ratio_R": R,
               "ecg_std_mV": 0.12,
               "results": []}

    for s in args.sigmas:
        # Closed-form Eq.(7): u_sigma (z-score) = sigma * 1 * R
        u_z_cf = s * R
        u_mV_cf = u_z_cf * 0.12
        # MC with extended bracket
        u_z_mc, target = mc_match(enc, Xt, s, n_mc=args.n_mc,
                                   lo=1e-6, hi=50.0)
        u_mV_mc = u_z_mc * 0.12
        # Reliability: linear regime if MC stays within +-30% of closed-form
        rel_err = abs(u_z_mc - u_z_cf) / max(u_z_cf, 1e-12)
        in_linear = rel_err < 0.30
        item = {
            "sigma_param": s,
            "u_sigma_zscore_closed_form": u_z_cf,
            "u_sigma_zscore_MC": u_z_mc,
            "u_sigma_mV_closed_form": u_mV_cf,
            "u_sigma_uV_closed_form": u_mV_cf * 1000,
            "u_sigma_mV_MC": u_mV_mc,
            "u_sigma_uV_MC": u_mV_mc * 1000,
            "target_rms_drift": target,
            "rel_err_MC_vs_closed_form": rel_err,
            "linear_regime": in_linear,
        }
        print(f"sigma={s:.1e}: u_sigma(closed-form)={u_mV_cf*1000:.1f} uV, "
              f"MC={u_mV_mc*1000:.1f} uV, rel_err={rel_err:.2%}, "
              f"linear={'yes' if in_linear else 'NO (linearization fails)'}")
        summary["results"].append(item)

    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)
    print("saved", args.out)


if __name__ == "__main__":
    main()
