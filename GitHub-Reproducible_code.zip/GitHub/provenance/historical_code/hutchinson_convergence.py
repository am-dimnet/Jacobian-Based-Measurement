"""V24: Hutchinson convergence study. Sweep K=2,4,8,16,32 on the
trained ours-encoder and three random init architectures, to show
that R is converged at K=8 and is not an artefact of estimator
hyperparameters."""
from __future__ import annotations
import argparse, json, os
import numpy as np
import torch

from data_real import load_ptbxl
from models import ECGEncoder
from multi_encoder_sigma_map import ENCODERS
from hutchinson_R import hutchinson_F2


def R_at_K(enc, x, K, n_runs=3, device="cuda"):
    Rs = []
    for r in range(n_runs):
        torch.manual_seed(1000 + r)
        F2t = hutchinson_F2(enc, x, target="theta", K=K)
        F2x = hutchinson_F2(enc, x, target="x",     K=K)
        Rs.append(float(np.sqrt(F2t / max(F2x, 1e-12))))
    return Rs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/root/autodl-tmp/Paper20_TIM/results/hutchinson_convergence.json")
    ap.add_argument("--n-batch", type=int, default=32)
    ap.add_argument("--K-list", type=int, nargs="+", default=[2, 4, 8, 16, 32])
    ap.add_argument("--ckpt", default="/root/autodl-tmp/Paper20_TIM/results/ckpts/ours_s20260601.pt")
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"

    p = load_ptbxl(); X = p["X"][:args.n_batch].astype(np.float32)
    Xt = torch.from_numpy(X).to(device)
    Xt = (Xt - Xt.mean(-1, keepdim=True)) / (Xt.std(-1, keepdim=True) + 1e-6)

    targets = []
    # trained ours
    enc_tr = ECGEncoder().to(device).eval()
    enc_tr.load_state_dict(torch.load(args.ckpt, map_location=device), strict=False)
    targets.append(("ours_trained", enc_tr))
    # representative random architectures
    for name in ["small_BN", "base_BN", "large_BN"]:
        torch.manual_seed(0)
        enc = ENCODERS[name](in_ch=12).to(device).eval()
        targets.append((name, enc))

    summary = {"config": vars(args), "results": {}}
    for name, enc in targets:
        summary["results"][name] = {}
        for K in args.K_list:
            Rs = R_at_K(enc, Xt, K)
            summary["results"][name][str(K)] = {
                "R_mean": float(np.mean(Rs)),
                "R_sd":   float(np.std(Rs, ddof=1)),
                "R_runs": Rs,
            }
            print(f"{name:14s} K={K:2d}  R={np.mean(Rs):8.2f}+/-{np.std(Rs,ddof=1):.2f}",
                  flush=True)
    json.dump(summary, open(args.out, "w"), indent=2)
    print("saved", args.out)


if __name__ == "__main__":
    main()
