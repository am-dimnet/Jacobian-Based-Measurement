"""Two-GPU queue for the predeclared revision training matrix."""
import argparse,subprocess,os,json,time,threading,queue
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:raise SystemExit('Queue prepared, not started')
r=Path(a.repo);run=r/'runs';run.mkdir(exist_ok=True);logs=r/'logs';jobs=[]
# A common native partition supports E6 and three contemporary aggregation controls.
configs={'composite':['--sigma','.001','--prox-mu','.01','--quality-weight','--damping','.6'],'fedavg':['--sigma','0','--prox-mu','0'],'fedprox':['--sigma','0','--prox-mu','.01'],'noisy_fedavg':['--sigma','.001','--prox-mu','0']}
for method,flags in configs.items():
 for seed in [20260921,20260922,20260923]:jobs.append(dict(name=f'native_{method}_s{seed}',dataset='native.npz',alpha='native',seed=seed,flags=flags))
for alpha in ['0.1','0.5','1.0','iid']:
 for seed in [20260921,20260922,20260923]:jobs.append(dict(name=f'dirichlet_{alpha}_s{seed}',dataset='ptb.npz',alpha=alpha,seed=seed,flags=configs['composite']))
plan=r/'revision/training_matrix.json'
if plan.exists():raise RuntimeError('Matrix already dispatched; inspect rather than duplicate')
plan.write_text(json.dumps(jobs,indent=2));q=queue.Queue();[q.put(j) for j in jobs];lock=threading.Lock();state={j['name']:{'state':'queued'} for j in jobs};stop=threading.Event()
def record():
 tmp=r/'revision/queue_status.tmp';tmp.write_text(json.dumps(state,indent=2));tmp.replace(r/'revision/queue_status.json')
def worker(gpu):
 while not stop.is_set():
  try:j=q.get_nowait()
  except queue.Empty:return
  out=run/j['name'];cmd=['/root/miniconda3/bin/python','-u',str(r/'revision/server/train_controlled.py'),'--execute','--repo',str(r),'--data',str(r/'data/revision_v2'/j['dataset']),'--alpha',j['alpha'],'--partition-seed',str(j['seed']),'--seed',str(j['seed']),'--rounds','30','--batch','1024','--out',str(out)]+j['flags']
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',PYTHONHASHSEED=str(j['seed']))
  with open(logs/(j['name']+'.log'),'w') as f:
   pr=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   with lock:state[j['name']]={'state':'running','gpu':gpu,'pid':pr.pid,'start':time.time(),'command':cmd};record()
   code=pr.wait()
  with lock:state[j['name']].update(state='complete' if code==0 else 'failed',returncode=code,end=time.time());record()
  if code:stop.set()
  q.task_done()
threads=[threading.Thread(target=worker,args=(g,)) for g in [0,1]]
for t in threads:t.start()
for t in threads:t.join()
print('QUEUE FINISHED',json.dumps({s:sum(v['state']==s for v in state.values()) for s in ['complete','failed','queued']}),flush=True)
