"""Dispatch measurements after the declared training matrix completes, two GPU workers."""
import argparse,json,subprocess,os,time,threading,queue
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:raise SystemExit('explicit execute required')
r=Path(a.repo);plan=r/'revision/measurement_matrix.json';outroot=r/'measurements';outroot.mkdir(exist_ok=True)
state=json.loads((r/'revision/queue_status.json').read_text())
ref=r/'runs/native_composite_s20260921/reference.npz';main=r/'runs/native_composite_s20260921/round_030.pt';jobs=[]
def add(name,script,checkpoint=main,options=[]):jobs.append(dict(name=name,script=script,checkpoint=str(checkpoint),options=options))
add('E2_joint','evaluate.py',options=['hxv','--n','256','--Ks','8','--repeats','20'])
add('E1_white','joint_mc.py',options=['--kind','white'])
add('E2_K_sweep','evaluate.py',options=['hxv','--n','32','--Ks','2','4','8','16','32','--repeats','20'])
add('E4_baseline_MC','joint_mc.py',options=['--kind','baseline','--sigmas','.0001','.0003','.001'])
add('E4_narrow_MC','joint_mc.py',options=['--kind','narrow','--sigmas','.0001','.0003','.001'])
add('E4_structured','evaluate.py',options=['structured','--n','256','--K','8','--repeats','32'])
add('E5_normalization','evaluate.py',options=['normalization','--n','32','--K','8'])
add('E9_profile','evaluate.py',options=['profile','--n','32','--Ks','2','4','8','16','32','--warmup','5','--repeats','20'])
add('E0_precision','precision_check.py',options=['--n','32','--K','8'])
for name in state:
 add('model_'+name,'evaluate.py',r/'runs'/name/'round_030.pt',['hxv','--n','32','--Ks','8','--repeats','5'])
for seed in [20260921,20260922,20260923]:
 for rnd in [0,1,5,10,20]:add(f'trajectory_s{seed}_r{rnd:03d}','evaluate.py',r/'runs'/f'native_composite_s{seed}'/f'round_{rnd:03d}.pt',['hxv','--n','32','--Ks','8','--repeats','5'])
if plan.exists():raise RuntimeError('Measurement matrix already launched')
plan.write_text(json.dumps(jobs,indent=2));q=queue.Queue();[q.put(j) for j in jobs];lock=threading.Lock();status={j['name']:{'state':'queued'} for j in jobs};stop=threading.Event()
def record():
 tmp=r/'revision/measurement_status.tmp';tmp.write_text(json.dumps(status,indent=2));tmp.replace(r/'revision/measurement_status.json')
def worker(gpu):
 while not stop.is_set():
  try:j=q.get_nowait()
  except queue.Empty:return
  # Completed checkpoints can be measured while other independent training jobs run.
  # Timing experiments wait for all training to end to avoid GPU contention.
  while True:
   trainstate=json.loads((r/'revision/queue_status.json').read_text())
   if any(v['state']=='failed' for v in trainstate.values()):stop.set();raise RuntimeError('Training failure')
   if Path(j['checkpoint']).exists() and (j['name']!='E9_profile' or all(v['state']=='complete' for v in trainstate.values())):break
   time.sleep(15)
  opts=j['options'];cmd=['/root/miniconda3/bin/python','-u',str(r/'revision/server'/j['script'])]+opts+['--execute','--repo',str(r),'--checkpoint',j['checkpoint'],'--reference',str(ref),'--out',str(outroot/j['name'])]
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
  with open(r/'logs'/('measurement_'+j['name']+'.log'),'w') as f:
   pr=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   with lock:status[j['name']]=dict(state='running',gpu=gpu,pid=pr.pid,start=time.time(),command=cmd);record()
   code=pr.wait()
  with lock:status[j['name']].update(state='complete' if code==0 else 'failed',returncode=code,end=time.time());record()
  if code:stop.set()
  q.task_done()
threads=[threading.Thread(target=worker,args=(g,)) for g in [0,1]]
for t in threads:t.start()
for t in threads:t.join()
print('MEASUREMENTS FINISHED',flush=True)
