# External evidence assets

The GitHub tree contains source code, configurations, manifests and small summaries. 668 separately stored evidence files total 3.368 GiB. Every path, byte count and SHA-256 is recorded in `EXTERNAL_ASSETS.json`.

## Groups

- `data/`: exact processed cohort inputs.
- `runs/`: trained checkpoints and utility prediction arrays.
- `measurements/`: probe energies, drift curves, bootstrap arrays and profiler traces.
- `supplement_round2/`: physical-input reference arrays and additional evaluation outputs.
- `legacy/`: saved historical predictions.
- `analysis/`: joint uncertainty arrays.
- `provenance/`: selected raw waveforms and source-release metadata/checksums.

Public archive availability: **not yet published or verified**. No invented DOI or download URL is supplied. These files remain in the author's local evidence directory, using the same relative paths. Use `scripts/assemble_package.py --assets-dir PATH --check-only` to verify a local or downloaded evidence tree.

Before claiming complete public reproducibility, publish the required evidence through a suitable versioned archive (subject to source-data terms), add its genuine persistent URL to this file and `EXTERNAL_ASSETS.json`, and test assembly from a fresh download. Raw waveforms can instead be obtained from their original releases and reconstructed according to `docs/WORKFLOW.md`; exact record selection and checksums must match. If an asset is rebuilt instead of deposited, document and verify that replacement rather than pretending a missing array is available.

The assembly helper requires the listed full retained-evidence set. The fresh-training route may use fewer outputs, but this inventory supports complete retained-output verification. Local temporary files, operating-system metadata and historical audit receipts are not part of this external inventory.
