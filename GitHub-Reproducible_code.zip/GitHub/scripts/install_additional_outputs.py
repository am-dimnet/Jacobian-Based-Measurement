"""Install completed additional outputs into a prepared training workspace."""
import argparse
import json
from pathlib import Path
import shutil
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--workspace',type=Path,required=True)
p.add_argument('--source',type=Path,required=True)
a=p.parse_args();root=a.workspace.resolve();source=a.source.resolve()
if not (root/'WORKSPACE.json').is_file():p.error('A prepared workspace is required.')
state=json.loads((source/'status.json').read_text())
if len(state)!=18 or not all(v['state']=='complete' for v in state.values()):p.error('All 18 jobs must complete.')
if not (source/'additional_results.json').is_file():p.error('Analysis output is missing.')
target=root/'supplement_round2'
# Known immutable input copies already exist; exclude them from installation.
skip={'normalization_input.npz','interference_input.npz','interference_nonflat_input.npz','protocol.json'}
items=[f for f in source.iterdir() if f.name not in skip]
if any((target/f.name).exists() for f in items):p.error('Existing results would be overwritten; use a fresh training workspace.')
for f in items:
 if f.is_dir():shutil.copytree(f,target/f.name)
 else:shutil.copy2(f,target/f.name)
print('Installed completed additional outputs; no existing result was overwritten.')
