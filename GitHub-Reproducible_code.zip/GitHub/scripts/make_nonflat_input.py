"""Create the explicitly exploratory nonflat reference from the full saved input."""
import argparse
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--input',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
if a.out.exists():p.error('Output already exists; choose a fresh file.')
z=np.load(a.input,allow_pickle=False)
mask=(z['scale_V']>0).all(axis=1)
assert len(mask)==128 and mask.sum()==125
record_fields={'physical_500_V','physical_V','X','record_id','patient_id','scale_V'}
values={k:z[k][mask] if k in record_fields else z[k] for k in z.files}
np.savez_compressed(a.out,**values)
print('Created exploratory 125-record input. The full 128-record reference is unchanged.')
