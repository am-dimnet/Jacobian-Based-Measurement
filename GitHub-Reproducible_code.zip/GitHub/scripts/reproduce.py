"""Print or execute explicit reproduction stages in a prepared workspace."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def commands(root, stage, gpus, evaluation_out):
    python = sys.executable
    server = root / 'revision/server'
    if stage == 'validate':
        return [[python, str(root / 'validation' / name)]
                for name in ['numerical_audit.py', 'table_audit.py']]
    if stage == 'analysis':
        return [[python, str(server / 'analyse_new_results.py'), '--repo', str(root)],
                [python, str(root / 'supplement_round2/scripts/analyse_supplement.py'),
                 str(root), str(root / 'supplement_round2')]]
    if stage == 'figures':
        return [[python, str(root / 'manuscript_tools' / name)] for name in
                ['reanalyse_legacy.py', 'plot_new_results.py', 'plot_paired.py', 'plot_physical.py']]
    if stage in ['train', 'measure']:
        name = 'train_queue.py' if stage == 'train' else 'measurement_queue.py'
        return [[python, str(server / name), '--execute', '--repo', str(root), '--gpus', gpus]]
    if stage == 'additional':
        return [[python, str(root / 'supplement_round2/scripts/run_round2.py'),
                 '--repo', str(root), '--out', str(evaluation_out),
                 '--gpus', gpus, '--workers-per-gpu', '2', '--execute']]
    raise ValueError(stage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--stage', choices=['validate', 'analysis', 'figures', 'train', 'measure', 'additional'], required=True)
    parser.add_argument('--gpus', default='0,1')
    parser.add_argument('--evaluation-out', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    root = args.workspace.expanduser().resolve()
    if not all(v.isdigit() for v in args.gpus.split(',')):
        parser.error('GPU indices must be comma-separated nonnegative integers.')
    if args.stage == 'additional' and args.evaluation_out is None:
        parser.error('--evaluation-out is required for additional evaluations.')
    planned = commands(root, args.stage, args.gpus,
                       args.evaluation_out.resolve() if args.evaluation_out else None)
    print(json.dumps({'stage': args.stage, 'execute': args.execute, 'commands': planned}, indent=2), flush=True)
    if not args.execute:
        print('Plan only. Nothing was run.')
        return
    marker = root / 'WORKSPACE.json'
    if not marker.is_file():
        parser.error('Use prepare_reproduction.py first; the evidence package is not an execution workspace.')
    mode = json.loads(marker.read_text())['mode']
    if args.stage in ['train', 'measure'] and mode != 'training':
        parser.error('Training and initial measurements require a fresh training workspace.')
    if args.stage in ['train', 'measure', 'additional']:
        import torch
        if not torch.cuda.is_available():
            parser.error('CUDA is required. No automatic CPU evaluation fallback is permitted.')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for command in planned:
        subprocess.run(command, cwd=root, env=env, check=True)


if __name__ == '__main__':
    main()
