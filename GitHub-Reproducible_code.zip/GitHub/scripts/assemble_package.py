"""Verify external evidence and assemble a separate complete package; no experiments."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from prepare_reproduction import copy_file


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assets-dir', type=Path, required=True)
    parser.add_argument('--destination', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    asset_root = args.assets_dir.expanduser().resolve()
    if not asset_root.is_dir():
        parser.error('Asset directory does not exist.')
    if not args.check_only and args.destination is None:
        parser.error('--destination is required unless --check-only is selected.')
    target = args.destination.expanduser().resolve() if args.destination else None
    if target is not None and (target.exists() or ROOT in target.parents or asset_root in target.parents):
        parser.error('Choose a new destination outside the repository and asset directory.')
    manifests = [json.loads((ROOT / 'PACKAGE_MANIFEST.json').read_text())['files'],
                 json.loads((ROOT / 'EXTERNAL_ASSETS.json').read_text())['files']]
    if set(manifests[0]) & set(manifests[1]):
        parser.error('Repository and external inventories overlap.')
    sources = {}
    for base, files in zip([ROOT, asset_root], manifests):
        for relative, info in files.items():
            path = base / relative
            if Path(relative).is_absolute() or '..' in Path(relative).parts:
                parser.error('Unsafe manifest path: ' + relative)
            if not path.is_file() or path.is_symlink():
                parser.error('Missing or symbolic-link asset: ' + relative)
            if path.stat().st_size != info['bytes'] or digest(path) != info['sha256']:
                parser.error('Evidence integrity mismatch: ' + relative)
            sources[relative] = path
    result = {'repository_files': len(manifests[0]), 'external_files': len(manifests[1]),
              'hashes_verified': True, 'experiments_started': False, 'check_only': args.check_only}
    if not args.check_only:
        target.mkdir(parents=True)
        for relative, source in sources.items():
            destination = target / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            copy_file(source, destination)
        combined = dict(manifests[0], **manifests[1])
        (target / 'PACKAGE_MANIFEST.json').write_text(json.dumps({
            'distribution': 'assembled_evidence_package', 'files': combined,
            'excluded_generated_reports': ['PACKAGE_MANIFEST.json', 'validation/repository_verification.json']
        }, indent=2) + '\n')
        result['destination'] = str(target)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
