"""Verify source integrity, English text and Python syntax without experiments."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HAN = re.compile('[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U000323af]')
TEXT = {'.py', '.md', '.txt', '.json', '.csv', '.tex', '.bib', '.yml', '.yaml', '.sh'}


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-hashes', action='store_true')
    parser.add_argument('--require-assets', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'PACKAGE_MANIFEST.json').read_text())
    files = dict(manifest['files'])
    if args.require_assets:
        files.update(json.loads((ROOT / 'EXTERNAL_ASSETS.json').read_text())['files'])
    failures = []
    python_files = 0
    for relative, info in files.items():
        path = ROOT / relative
        if not path.is_file() or path.is_symlink():
            failures.append('Missing or symbolic-link resource: ' + relative)
            continue
        if path.stat().st_size != info['bytes']:
            failures.append('Size mismatch: ' + relative)
        if not args.skip_hashes and sha(path) != info['sha256']:
            failures.append('Hash mismatch: ' + relative)
        if HAN.search(relative):
            failures.append('CJK filename: ' + relative)
        if path.suffix in TEXT:
            text = path.read_text(errors='strict')
            if HAN.search(text):
                failures.append('CJK text: ' + relative)
            if path.suffix == '.json':
                try:
                    if HAN.search(json.dumps(json.loads(text), ensure_ascii=False)):
                        failures.append('Escaped CJK JSON: ' + relative)
                except ValueError:
                    failures.append('Invalid JSON: ' + relative)
            if path.suffix == '.py':
                try:
                    ast.parse(text, filename=relative)
                    python_files += 1
                except SyntaxError as exc:
                    failures.append(str(exc))
    for name in ['code/models.py', 'revision/server/train_controlled.py',
                 'revision/server/evaluate.py', 'supplement_round2/scripts/physical_eval.py',
                 'prepare_reproduction.py', 'requirements.txt', 'environment.yml']:
        if not (ROOT / name).is_file():
            failures.append('Required source missing: ' + name)
    for name in ['main.tex', 'supplementary.tex']:
        text = (ROOT / 'manuscript' / name).read_text()
        for resource in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}', text):
            if not (ROOT / 'manuscript' / resource).is_file():
                failures.append('Missing figure: ' + resource)
    result = {'passed': not failures, 'files_checked': len(files),
              'python_files_parsed': python_files, 'hashes_checked': not args.skip_hashes,
              'external_assets_required': args.require_assets,
              'experiments_started': False, 'failures': failures}
    (ROOT / 'validation').mkdir(exist_ok=True)
    (ROOT / 'validation/repository_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
