"""Verify package integrity, English text, required resources and Python syntax."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import tarfile
import zipfile

HAN = re.compile('[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U000323af]')
TEXT = {'.py','.md','.txt','.json','.csv','.tex','.bib','.yml','.yaml','.sh','.log','.hea'}


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-hashes',action='store_true')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
    failures=[];python_files=0;text_files=0;members=0
    for relative,info in manifest['files'].items():
        path=root/relative
        if not path.is_file():failures.append('Missing: '+relative);continue
        if path.is_symlink():failures.append('Unexpected symbolic link: '+relative)
        if path.stat().st_size!=info['bytes']:failures.append('Size mismatch: '+relative)
        if not args.skip_hashes and sha(path)!=info['sha256']:failures.append('Hash mismatch: '+relative)
    for path in root.rglob('*'):
        rel=str(path.relative_to(root))
        if HAN.search(rel):failures.append('Non-English filename: '+rel)
        if path.is_file() and path.suffix in TEXT:
            text=path.read_text(errors='replace');text_files+=1
            if HAN.search(text):failures.append('CJK text: '+rel)
            if path.suffix=='.json':
                try:
                    if HAN.search(json.dumps(json.loads(text),ensure_ascii=False)):
                        failures.append('Escaped CJK JSON: '+rel)
                except (ValueError,TypeError):failures.append('Invalid JSON: '+rel)
            if path.suffix=='.py':
                try:ast.parse(text,filename=rel);python_files+=1
                except SyntaxError as e:failures.append(str(e))
    # Inspect names and textual members inside the supplied selected raw archive.
    with tarfile.open(root/'provenance/selected_raw.tar.gz','r:gz') as archive:
        for member in archive:
            members+=1
            if HAN.search(member.name):failures.append('CJK raw archive name: '+member.name)
            if member.isfile() and Path(member.name).suffix in TEXT:
                if HAN.search(archive.extractfile(member).read().decode('utf-8',errors='replace')):
                    failures.append('CJK raw archive text: '+member.name)
    required=['code/models.py','code/fed_algos.py','data/revision_v2/native.npz',
              'data/revision_v2/ptb.npz','revision/server/train_queue.py',
              'revision/server/measurement_queue.py','supplement_round2/scripts/run_round2.py',
              'manuscript/main.tex','manuscript/supplementary.tex']
    for rel in required:
        if not (root/rel).is_file():failures.append('Required resource missing: '+rel)
    for tex in ['main.tex','supplementary.tex']:
        content=(root/'manuscript'/tex).read_text()
        for resource in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',content):
            if not (root/'manuscript'/resource).is_file():failures.append('Missing figure: '+resource)
    result={'passed':not failures,'manifest_files':len(manifest['files']),
            'python_files_parsed':python_files,'text_files_scanned':text_files,
            'raw_archive_members_scanned':members,'hashes_checked':not args.skip_hashes,
            'experiments_started':False,'failures':failures}
    (root/'validation/package_validation.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
